const require = (await import('node:module')).createRequire(import.meta.url); const __chunk_filename = (await import('node:url')).fileURLToPath(import.meta.url); const __chunk_dirname = (await import('node:path')).dirname(__chunk_filename);
import {
  coreEvents,
  debugLogger
} from "./chunk-IIKCGBA6.js";
import {
  wrapper_default
} from "./chunk-4DETJLW6.js";
import "./chunk-34MYV7JD.js";

// packages/cli/src/utils/activityLogger.ts
import http from "node:http";
import https from "node:https";
import zlib from "node:zlib";
import fs from "node:fs";
import path from "node:path";
import { EventEmitter } from "node:events";
var ACTIVITY_ID_HEADER = "x-activity-request-id";
var MAX_BUFFER_SIZE = 100;
function isHeaderRecord(h) {
  return !Array.isArray(h);
}
function isRequestOptions(value) {
  return typeof value === "object" && value !== null && !(value instanceof URL) && !Array.isArray(value);
}
function isIncomingMessageCallback(value) {
  return typeof value === "function";
}
function callHttpRequest(originalFn, args) {
  if (args.length === 0) {
    return originalFn({});
  }
  if (args.length === 1) {
    const first = args[0];
    if (typeof first === "string" || first instanceof URL) {
      return originalFn(first);
    }
    if (isRequestOptions(first)) {
      return originalFn(first);
    }
    return originalFn({});
  }
  if (args.length === 2) {
    const first = args[0];
    const second = args[1];
    if (typeof first === "string" || first instanceof URL) {
      if (isIncomingMessageCallback(second)) {
        return originalFn(first, second);
      }
      if (isRequestOptions(second)) {
        return originalFn(first, second);
      }
    }
    if (isRequestOptions(first) && isIncomingMessageCallback(second)) {
      return originalFn(first, second);
    }
  }
  if (args.length === 3) {
    const first = args[0];
    const second = args[1];
    const third = args[2];
    if ((typeof first === "string" || first instanceof URL) && isRequestOptions(second) && isIncomingMessageCallback(third)) {
      return originalFn(first, second, third);
    }
  }
  return originalFn({});
}
var ActivityLogger = class _ActivityLogger extends EventEmitter {
  static instance;
  isInterceptionEnabled = false;
  requestStartTimes = /* @__PURE__ */ new Map();
  networkLoggingEnabled = false;
  networkBufferMap = /* @__PURE__ */ new Map();
  networkBufferIds = [];
  consoleBuffer = [];
  bufferLimit = 10;
  static getInstance() {
    if (!_ActivityLogger.instance) {
      _ActivityLogger.instance = new _ActivityLogger();
    }
    return _ActivityLogger.instance;
  }
  enableNetworkLogging() {
    this.networkLoggingEnabled = true;
    this.emit("network-logging-enabled");
  }
  disableNetworkLogging() {
    this.networkLoggingEnabled = false;
  }
  isNetworkLoggingEnabled() {
    return this.networkLoggingEnabled;
  }
  /**
   * Atomically returns and clears all buffered logs.
   * Prevents data loss from events emitted between get and clear.
   */
  drainBufferedLogs() {
    const network = [];
    for (const id of this.networkBufferIds) {
      const events = this.networkBufferMap.get(id);
      if (events) network.push(...events);
    }
    const console = [...this.consoleBuffer];
    this.networkBufferMap.clear();
    this.networkBufferIds = [];
    this.consoleBuffer = [];
    return { network, console };
  }
  getBufferedLogs() {
    const network = [];
    for (const id of this.networkBufferIds) {
      const events = this.networkBufferMap.get(id);
      if (events) network.push(...events);
    }
    return {
      network,
      console: [...this.consoleBuffer]
    };
  }
  clearBufferedLogs() {
    this.networkBufferMap.clear();
    this.networkBufferIds = [];
    this.consoleBuffer = [];
  }
  stringifyHeaders(headers) {
    const result = {};
    if (!headers) return result;
    if (headers instanceof Headers) {
      headers.forEach((v, k) => {
        result[k.toLowerCase()] = v;
      });
    } else if (typeof headers === "object" && headers !== null) {
      for (const [key, val] of Object.entries(headers)) {
        result[key.toLowerCase()] = Array.isArray(val) ? val.join(", ") : String(val);
      }
    }
    return result;
  }
  sanitizeNetworkLog(log) {
    if (!log || typeof log !== "object") return log;
    const sanitized = { ...log };
    if ("headers" in sanitized && sanitized.headers) {
      const headers = { ...sanitized.headers };
      for (const key of Object.keys(headers)) {
        if (["authorization", "cookie", "x-goog-api-key"].includes(
          key.toLowerCase()
        )) {
          headers[key] = "[REDACTED]";
        }
      }
      sanitized.headers = headers;
    }
    if ("response" in sanitized && sanitized.response?.headers) {
      const resHeaders = { ...sanitized.response.headers };
      for (const key of Object.keys(resHeaders)) {
        if (["set-cookie"].includes(key.toLowerCase())) {
          resHeaders[key] = "[REDACTED]";
        }
      }
      sanitized.response = { ...sanitized.response, headers: resHeaders };
    }
    return sanitized;
  }
  /** @internal Emit a network event — public for testing only. */
  emitNetworkEvent(payload) {
    this.safeEmitNetwork(payload);
  }
  safeEmitNetwork(payload) {
    const sanitized = this.sanitizeNetworkLog(payload);
    const id = sanitized.id;
    if (!this.networkBufferMap.has(id)) {
      this.networkBufferIds.push(id);
      this.networkBufferMap.set(id, []);
      if (this.networkBufferIds.length > this.bufferLimit) {
        const evictId = this.networkBufferIds.shift();
        this.networkBufferMap.delete(evictId);
      }
    }
    this.networkBufferMap.get(id).push(sanitized);
    this.emit("network", sanitized);
  }
  enable() {
    if (this.isInterceptionEnabled) return;
    this.isInterceptionEnabled = true;
    this.patchGlobalFetch();
    this.patchNodeHttp();
  }
  patchGlobalFetch() {
    if (!global.fetch) return;
    const originalFetch = global.fetch;
    global.fetch = async (input, init) => {
      const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
      if (url.includes("127.0.0.1") || url.includes("localhost"))
        return originalFetch(input, init);
      const id = Math.random().toString(36).substring(7);
      const inputMethod = typeof input === "object" && "method" in input ? input.method : void 0;
      const inputHeaders = typeof input === "object" && "headers" in input ? input.headers : void 0;
      const method = (init?.method ?? inputMethod ?? "GET").toUpperCase();
      const headers = new Headers(init?.headers ?? inputHeaders ?? {});
      headers.set(ACTIVITY_ID_HEADER, id);
      const newInit = {
        ...init,
        method,
        headers
      };
      let reqBody = "";
      const body = newInit.body;
      if (body) {
        if (typeof body === "string") reqBody = body;
        else if (body instanceof URLSearchParams) reqBody = body.toString();
      }
      this.requestStartTimes.set(id, Date.now());
      this.safeEmitNetwork({
        id,
        timestamp: Date.now(),
        method,
        url,
        headers: this.stringifyHeaders(newInit.headers),
        body: reqBody,
        pending: true
      });
      try {
        const response = await originalFetch(input, newInit);
        const clonedRes = response.clone();
        if (clonedRes.body) {
          const reader = clonedRes.body.getReader();
          const decoder = new TextDecoder();
          const chunks = [];
          let chunkIndex = 0;
          const readStream = async () => {
            try {
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                const chunkData = decoder.decode(value, { stream: true });
                chunks.push(chunkData);
                this.safeEmitNetwork({
                  id,
                  pending: true,
                  chunk: {
                    index: chunkIndex++,
                    data: chunkData,
                    timestamp: Date.now()
                  }
                });
              }
              const startTime = this.requestStartTimes.get(id);
              const durationMs = startTime ? Date.now() - startTime : 0;
              this.requestStartTimes.delete(id);
              this.safeEmitNetwork({
                id,
                pending: false,
                response: {
                  status: response.status,
                  headers: this.stringifyHeaders(response.headers),
                  body: chunks.join(""),
                  durationMs
                }
              });
            } catch (err) {
              const message = err instanceof Error ? err.message : String(err);
              this.safeEmitNetwork({
                id,
                pending: false,
                error: `Failed to read response body: ${message}`
              });
            }
          };
          void readStream();
        } else {
          clonedRes.text().then((text) => {
            const startTime = this.requestStartTimes.get(id);
            const durationMs = startTime ? Date.now() - startTime : 0;
            this.requestStartTimes.delete(id);
            this.safeEmitNetwork({
              id,
              pending: false,
              response: {
                status: response.status,
                headers: this.stringifyHeaders(response.headers),
                body: text,
                durationMs
              }
            });
          }).catch((err) => {
            const message = err instanceof Error ? err.message : String(err);
            this.safeEmitNetwork({
              id,
              pending: false,
              error: `Failed to read response body: ${message}`
            });
          });
        }
        return response;
      } catch (err) {
        this.requestStartTimes.delete(id);
        const message = err instanceof Error ? err.message : String(err);
        this.safeEmitNetwork({ id, pending: false, error: message });
        throw err;
      }
    };
  }
  patchNodeHttp() {
    const self = this;
    const originalRequest = http.request;
    const originalHttpsRequest = https.request;
    const wrapRequest = (originalFn, args, protocol) => {
      const firstArg = args[0];
      let options;
      if (typeof firstArg === "string") {
        options = firstArg;
      } else if (firstArg instanceof URL) {
        options = firstArg;
      } else if (firstArg && typeof firstArg === "object") {
        options = isRequestOptions(firstArg) ? firstArg : {};
      } else {
        options = {};
      }
      let url = "";
      if (typeof options === "string") {
        url = options;
      } else if (options instanceof URL) {
        url = options.href;
      } else {
        const href = "href" in options && typeof options.href === "string" ? options.href : "";
        url = href || `${protocol}//${options.hostname || options.host || "localhost"}${options.path || "/"}`;
      }
      if (url.includes("127.0.0.1") || url.includes("localhost")) {
        return callHttpRequest(originalFn, args);
      }
      const rawHeaders = typeof options === "object" && options !== null && !(options instanceof URL) ? options.headers : void 0;
      let headers = {};
      if (rawHeaders && isHeaderRecord(rawHeaders)) {
        headers = rawHeaders;
      }
      if (headers[ACTIVITY_ID_HEADER]) {
        delete headers[ACTIVITY_ID_HEADER];
        return callHttpRequest(originalFn, args);
      }
      const id = Math.random().toString(36).substring(7);
      this.requestStartTimes.set(id, Date.now());
      const req = callHttpRequest(originalFn, args);
      const requestChunks = [];
      const oldWrite = req.write;
      const oldEnd = req.end;
      req.write = function(chunk, ...etc) {
        if (chunk) {
          const arg0 = etc[0];
          const encoding = typeof arg0 === "string" && Buffer.isEncoding(arg0) ? arg0 : void 0;
          requestChunks.push(
            Buffer.isBuffer(chunk) ? chunk : typeof chunk === "string" ? Buffer.from(chunk, encoding) : Buffer.from(
              chunk instanceof Uint8Array ? chunk : String(chunk)
            )
          );
        }
        return oldWrite.apply(this, [chunk, ...etc]);
      };
      req.end = function(chunkOrCb, ...etc) {
        const chunk = typeof chunkOrCb === "function" ? void 0 : chunkOrCb;
        if (chunk) {
          const arg0 = etc[0];
          const encoding = typeof arg0 === "string" && Buffer.isEncoding(arg0) ? arg0 : void 0;
          requestChunks.push(
            Buffer.isBuffer(chunk) ? chunk : typeof chunk === "string" ? Buffer.from(chunk, encoding) : Buffer.from(
              chunk instanceof Uint8Array ? chunk : String(chunk)
            )
          );
        }
        const body = Buffer.concat(requestChunks).toString("utf8");
        self.safeEmitNetwork({
          id,
          timestamp: Date.now(),
          method: req.method || "GET",
          url,
          headers: self.stringifyHeaders(req.getHeaders()),
          body,
          pending: true
        });
        return oldEnd.apply(this, [chunkOrCb, ...etc]);
      };
      req.on("response", (res) => {
        const responseChunks = [];
        let chunkIndex = 0;
        res.on("data", (chunk) => {
          const chunkBuffer = Buffer.from(chunk);
          responseChunks.push(chunkBuffer);
          self.safeEmitNetwork({
            id,
            pending: true,
            chunk: {
              index: chunkIndex++,
              data: chunkBuffer.toString("utf8"),
              timestamp: Date.now()
            }
          });
        });
        res.on("end", () => {
          const buffer = Buffer.concat(responseChunks);
          const encoding = res.headers["content-encoding"];
          const processBuffer = (finalBuffer) => {
            const resBody = finalBuffer.toString("utf8");
            const startTime = self.requestStartTimes.get(id);
            const durationMs = startTime ? Date.now() - startTime : 0;
            self.requestStartTimes.delete(id);
            self.safeEmitNetwork({
              id,
              pending: false,
              response: {
                status: res.statusCode || 0,
                headers: self.stringifyHeaders(res.headers),
                body: resBody,
                durationMs
              }
            });
          };
          if (encoding === "gzip") {
            zlib.gunzip(buffer, (err, decompressed) => {
              processBuffer(err ? buffer : decompressed);
            });
          } else if (encoding === "deflate") {
            zlib.inflate(buffer, (err, decompressed) => {
              processBuffer(err ? buffer : decompressed);
            });
          } else {
            processBuffer(buffer);
          }
        });
      });
      req.on("error", (err) => {
        self.requestStartTimes.delete(id);
        const message = err.message;
        self.safeEmitNetwork({
          id,
          pending: false,
          error: message
        });
      });
      return req;
    };
    Object.defineProperty(http, "request", {
      value: (url, options, callback) => {
        const args = callback !== void 0 ? [url, options, callback] : options !== void 0 ? [url, options] : [url];
        return wrapRequest(originalRequest, args, "http:");
      },
      writable: true,
      configurable: true
    });
    Object.defineProperty(https, "request", {
      value: (url, options, callback) => {
        const args = callback !== void 0 ? [url, options, callback] : options !== void 0 ? [url, options] : [url];
        return wrapRequest(
          originalHttpsRequest,
          args,
          "https:"
        );
      },
      writable: true,
      configurable: true
    });
  }
  logConsole(payload) {
    const enriched = { ...payload, timestamp: Date.now() };
    this.consoleBuffer.push(enriched);
    if (this.consoleBuffer.length > this.bufferLimit) {
      this.consoleBuffer.shift();
    }
    this.emit("console", enriched);
  }
};
function setupFileLogging(capture, config, customPath) {
  const logFile = customPath || (config.storage ? path.join(
    config.storage.getProjectTempLogsDir(),
    `session-${config.getSessionId()}.jsonl`
  ) : null);
  if (!logFile) return;
  const logsDir = path.dirname(logFile);
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  const writeToLog = (type, payload) => {
    try {
      const entry = JSON.stringify({
        type,
        payload,
        sessionId: config.getSessionId(),
        timestamp: Date.now()
      }) + "\n";
      fs.promises.appendFile(logFile, entry).catch((err) => {
        debugLogger.error("Failed to write to activity log:", err);
      });
    } catch (err) {
      debugLogger.error("Failed to prepare activity log entry:", err);
    }
  };
  capture.on("console", (payload) => writeToLog("console", payload));
  capture.on("network", (payload) => writeToLog("network", payload));
}
function setupNetworkLogging(capture, host, port, config, onReconnectFailed) {
  const transportBuffer = [];
  let ws = null;
  let reconnectTimer = null;
  let sessionId = null;
  let pingInterval = null;
  let reconnectAttempts = 0;
  const MAX_RECONNECT_ATTEMPTS = 2;
  const connect = () => {
    try {
      ws = new wrapper_default(`ws://${host}:${port}/ws`);
      ws.on("open", () => {
        debugLogger.debug(`WebSocket connected to ${host}:${port}`);
        reconnectAttempts = 0;
        sendMessage({
          type: "register",
          sessionId: config.getSessionId(),
          timestamp: Date.now()
        });
      });
      ws.on("message", (data) => {
        try {
          const parsed = JSON.parse(data.toString());
          if (typeof parsed === "object" && parsed !== null && "type" in parsed && typeof parsed.type === "string") {
            handleServerMessage({
              type: parsed.type,
              sessionId: "sessionId" in parsed && typeof parsed.sessionId === "string" ? parsed.sessionId : void 0
            });
          }
        } catch (err) {
          debugLogger.debug("Invalid WebSocket message:", err);
        }
      });
      ws.on("close", () => {
        debugLogger.debug(`WebSocket disconnected from ${host}:${port}`);
        cleanup();
        scheduleReconnect();
      });
      ws.on("error", (err) => {
        debugLogger.debug(`WebSocket error:`, err);
      });
    } catch (err) {
      debugLogger.debug(`Failed to connect WebSocket:`, err);
      scheduleReconnect();
    }
  };
  const handleServerMessage = (message) => {
    switch (message.type) {
      case "registered":
        sessionId = message.sessionId || null;
        debugLogger.debug(`WebSocket session registered: ${sessionId}`);
        if (pingInterval) clearInterval(pingInterval);
        pingInterval = setInterval(() => {
          sendMessage({ type: "pong", timestamp: Date.now() });
        }, 15e3);
        flushBuffer();
        break;
      case "trigger-debugger": {
        import("node:inspector").then((inspector) => {
          inspector.open();
          debugLogger.log(
            "Node debugger attached. Open chrome://inspect in Chrome to start debugging."
          );
          return import("./events-XB7DADIJ.js");
        }).then(({ appEvents, AppEvent, TransientMessageType }) => {
          appEvents.emit(AppEvent.TransientMessage, {
            message: "Debugger attached from DevTools.",
            type: TransientMessageType.Hint
          });
        }).catch(
          (err) => debugLogger.debug("Failed to trigger debugger:", err)
        );
        break;
      }
      case "ping":
        sendMessage({ type: "pong", timestamp: Date.now() });
        break;
      default:
        break;
    }
  };
  const sendMessage = (message) => {
    if (ws && ws.readyState === wrapper_default.OPEN) {
      ws.send(JSON.stringify(message));
    }
  };
  const sendToNetwork = (type, payload) => {
    const message = {
      type,
      payload,
      sessionId: sessionId || config.getSessionId(),
      timestamp: Date.now()
    };
    if (!ws || ws.readyState !== wrapper_default.OPEN || !capture.isNetworkLoggingEnabled()) {
      transportBuffer.push(message);
      if (transportBuffer.length > MAX_BUFFER_SIZE) transportBuffer.shift();
      return;
    }
    sendMessage(message);
  };
  const flushBuffer = () => {
    if (!ws || ws.readyState !== wrapper_default.OPEN || !capture.isNetworkLoggingEnabled()) {
      return;
    }
    const { network, console: consoleLogs } = capture.drainBufferedLogs();
    const allInitialLogs = [
      ...network.map((l) => ({
        type: "network",
        payload: l,
        timestamp: "timestamp" in l && l.timestamp ? l.timestamp : Date.now()
      })),
      ...consoleLogs.map((l) => ({
        type: "console",
        payload: l,
        timestamp: l.timestamp
      }))
    ].sort((a, b) => a.timestamp - b.timestamp);
    debugLogger.debug(
      `Flushing ${allInitialLogs.length} initial buffered logs and ${transportBuffer.length} transport buffered logs...`
    );
    for (const log of allInitialLogs) {
      sendMessage({
        type: log.type,
        payload: log.payload,
        sessionId: sessionId || config.getSessionId(),
        timestamp: Date.now()
      });
    }
    while (transportBuffer.length > 0) {
      const message = transportBuffer.shift();
      sendMessage(message);
    }
  };
  const cleanup = () => {
    if (pingInterval) {
      clearInterval(pingInterval);
      pingInterval = null;
    }
    ws = null;
  };
  const scheduleReconnect = () => {
    if (reconnectTimer) return;
    reconnectAttempts++;
    if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS && onReconnectFailed) {
      debugLogger.debug(
        `WebSocket reconnect failed after ${MAX_RECONNECT_ATTEMPTS} attempts, promoting to server...`
      );
      onReconnectFailed();
      return;
    }
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      debugLogger.debug("Reconnecting WebSocket...");
      connect();
    }, 1e3);
  };
  connect();
  capture.on("console", (payload) => sendToNetwork("console", payload));
  capture.on("network", (payload) => sendToNetwork("network", payload));
  capture.on("network-logging-enabled", () => {
    debugLogger.debug("Network logging enabled, flushing buffer...");
    flushBuffer();
  });
  process.on("exit", () => {
    if (reconnectTimer) clearTimeout(reconnectTimer);
    if (ws) ws.close();
    cleanup();
  });
}
var bridgeAttached = false;
function bridgeCoreEvents(capture) {
  if (bridgeAttached) return;
  bridgeAttached = true;
  coreEvents.on("console-log" /* ConsoleLog */, (payload) => {
    capture.logConsole(payload);
  });
}
function initActivityLogger(config, options) {
  const capture = ActivityLogger.getInstance();
  capture.enable();
  if (options.mode === "network") {
    setupNetworkLogging(
      capture,
      options.host,
      options.port,
      config,
      options.onReconnectFailed
    );
    capture.enableNetworkLogging();
  } else if (options.mode === "file") {
    setupFileLogging(capture, config, options.filePath);
  }
  bridgeCoreEvents(capture);
}
function addNetworkTransport(config, host, port, onReconnectFailed) {
  const capture = ActivityLogger.getInstance();
  setupNetworkLogging(capture, host, port, config, onReconnectFailed);
}

// packages/cli/src/utils/devtoolsService.ts
var DEFAULT_DEVTOOLS_PORT = 25417;
var DEFAULT_DEVTOOLS_HOST = "127.0.0.1";
var MAX_PROMOTION_ATTEMPTS = 3;
var promotionAttempts = 0;
var serverStartPromise = null;
var connectedUrl = null;
function probeDevTools(host, port) {
  return new Promise((resolve) => {
    const ws = new wrapper_default(`ws://${host}:${port}/ws`);
    const timer = setTimeout(() => {
      ws.close();
      resolve(false);
    }, 500);
    ws.on("open", () => {
      clearTimeout(timer);
      ws.close();
      resolve(true);
    });
    ws.on("error", () => {
      clearTimeout(timer);
      ws.close();
      resolve(false);
    });
  });
}
async function startOrJoinDevTools(defaultHost, defaultPort) {
  const mod = await import("@google/gemini-cli-devtools");
  const devtools = mod.DevTools.getInstance();
  const url = await devtools.start();
  const actualPort = devtools.getPort();
  if (actualPort === defaultPort) {
    debugLogger.log(`DevTools available at: ${url}`);
    return { host: defaultHost, port: actualPort };
  }
  const winnerAlive = await probeDevTools(defaultHost, defaultPort);
  if (winnerAlive) {
    await devtools.stop();
    debugLogger.log(
      `DevTools (existing) at: http://${defaultHost}:${defaultPort}`
    );
    return { host: defaultHost, port: defaultPort };
  }
  debugLogger.log(`DevTools available at: ${url}`);
  return { host: defaultHost, port: actualPort };
}
async function handlePromotion(config) {
  promotionAttempts++;
  if (promotionAttempts > MAX_PROMOTION_ATTEMPTS) {
    debugLogger.debug(
      `Giving up on DevTools promotion after ${MAX_PROMOTION_ATTEMPTS} attempts`
    );
    return;
  }
  try {
    const result = await startOrJoinDevTools(
      DEFAULT_DEVTOOLS_HOST,
      DEFAULT_DEVTOOLS_PORT
    );
    addNetworkTransport(
      config,
      result.host,
      result.port,
      () => handlePromotion(config)
    );
  } catch (err) {
    debugLogger.debug("Failed to promote to DevTools server:", err);
  }
}
function setupInitialActivityLogger(config) {
  const target = process.env["GEMINI_CLI_ACTIVITY_LOG_TARGET"];
  if (target) {
    if (!config.storage) return;
    initActivityLogger(config, { mode: "file", filePath: target });
  } else {
    initActivityLogger(config, { mode: "buffer" });
  }
}
function startDevToolsServer(config) {
  if (connectedUrl) return Promise.resolve(connectedUrl);
  if (serverStartPromise) return serverStartPromise;
  serverStartPromise = startDevToolsServerImpl(config).catch((err) => {
    serverStartPromise = null;
    throw err;
  });
  return serverStartPromise;
}
async function startDevToolsServerImpl(config) {
  const onReconnectFailed = () => handlePromotion(config);
  const existing = await probeDevTools(
    DEFAULT_DEVTOOLS_HOST,
    DEFAULT_DEVTOOLS_PORT
  );
  let host = DEFAULT_DEVTOOLS_HOST;
  let port = DEFAULT_DEVTOOLS_PORT;
  if (existing) {
    debugLogger.log(
      `DevTools (existing) at: http://${DEFAULT_DEVTOOLS_HOST}:${DEFAULT_DEVTOOLS_PORT}`
    );
  } else {
    try {
      const result = await startOrJoinDevTools(
        DEFAULT_DEVTOOLS_HOST,
        DEFAULT_DEVTOOLS_PORT
      );
      host = result.host;
      port = result.port;
    } catch (err) {
      debugLogger.debug("Failed to start DevTools:", err);
      throw err;
    }
  }
  addNetworkTransport(config, host, port, onReconnectFailed);
  const capture = ActivityLogger.getInstance();
  capture.enableNetworkLogging();
  const url = `http://localhost:${port}`;
  connectedUrl = url;
  return url;
}
async function toggleDevToolsPanel(config, isOpen, toggle, setOpen) {
  if (isOpen) {
    toggle();
    return;
  }
  try {
    const { openBrowserSecurely, shouldLaunchBrowser } = await import("./core-CUXG7RN5.js");
    const url = await startDevToolsServer(config);
    if (shouldLaunchBrowser()) {
      try {
        await openBrowserSecurely(url);
        return;
      } catch (e) {
        debugLogger.warn("Failed to open browser securely:", e);
      }
    }
    setOpen();
  } catch (e) {
    setOpen();
    debugLogger.error("Failed to start DevTools server:", e);
  }
}
function resetForTesting() {
  promotionAttempts = 0;
  serverStartPromise = null;
  connectedUrl = null;
}
export {
  resetForTesting,
  setupInitialActivityLogger,
  startDevToolsServer,
  toggleDevToolsPanel
};
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
