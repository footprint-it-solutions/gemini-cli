const require = (await import('node:module')).createRequire(import.meta.url); const __chunk_filename = (await import('node:url')).fileURLToPath(import.meta.url); const __chunk_dirname = (await import('node:path')).dirname(__chunk_filename);
import {
  AuthProviderType,
  DEFAULT_MODEL_CONFIGS,
  DEFAULT_TRUNCATE_TOOL_OUTPUT_THRESHOLD,
  FatalConfigError,
  GEMINI_DIR,
  SESSION_FILE_PREFIX,
  Storage,
  TOOL_OUTPUTS_DIR,
  ansiRegex,
  checkExhaustive,
  checkPathTrust,
  coreEvents,
  createCache,
  debugLogger,
  deleteSessionArtifactsAsync,
  deleteSubagentSessionDirAndArtifactsAsync,
  external_exports,
  getErrorMessage,
  getFsErrorMessage,
  homedir,
  import_lru_cache,
  isHeadlessMode,
  loadConversationRecord,
  loadTrustedFolders,
  partListUnionToString,
  require_strip_json_comments,
  sanitizeFilenamePart,
  stripAnsi
} from "./chunk-IIKCGBA6.js";
import {
  __commonJS,
  __require,
  __toESM
} from "./chunk-34MYV7JD.js";

// node_modules/dotenv/lib/main.js
var require_main = __commonJS({
  "node_modules/dotenv/lib/main.js"(exports, module) {
    var fs6 = __require("fs");
    var path6 = __require("path");
    var os = __require("os");
    var crypto = __require("crypto");
    var TIPS = [
      "\u25C8 encrypted .env [www.dotenvx.com]",
      "\u25C8 secrets for agents [www.dotenvx.com]",
      "\u2301 auth for agents [www.vestauth.com]",
      "\u2318 custom filepath { path: '/custom/path/.env' }",
      "\u2318 enable debugging { debug: true }",
      "\u2318 override existing { override: true }",
      "\u2318 suppress logs { quiet: true }",
      "\u2318 multiple files { path: ['.env.local', '.env'] }"
    ];
    function _getRandomTip() {
      return TIPS[Math.floor(Math.random() * TIPS.length)];
    }
    function parseBoolean(value) {
      if (typeof value === "string") {
        return !["false", "0", "no", "off", ""].includes(value.toLowerCase());
      }
      return Boolean(value);
    }
    function supportsAnsi() {
      return process.stdout.isTTY;
    }
    function dim(text) {
      return supportsAnsi() ? `\x1B[2m${text}\x1B[0m` : text;
    }
    var LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
    function parse3(src) {
      const obj = {};
      let lines = src.toString();
      lines = lines.replace(/\r\n?/mg, "\n");
      let match;
      while ((match = LINE.exec(lines)) != null) {
        const key = match[1];
        let value = match[2] || "";
        value = value.trim();
        const maybeQuote = value[0];
        value = value.replace(/^(['"`])([\s\S]*)\1$/mg, "$2");
        if (maybeQuote === '"') {
          value = value.replace(/\\n/g, "\n");
          value = value.replace(/\\r/g, "\r");
        }
        obj[key] = value;
      }
      return obj;
    }
    function _parseVault(options) {
      options = options || {};
      const vaultPath = _vaultPath(options);
      options.path = vaultPath;
      const result = DotenvModule.configDotenv(options);
      if (!result.parsed) {
        const err = new Error(`MISSING_DATA: Cannot parse ${vaultPath} for an unknown reason`);
        err.code = "MISSING_DATA";
        throw err;
      }
      const keys = _dotenvKey(options).split(",");
      const length = keys.length;
      let decrypted;
      for (let i = 0; i < length; i++) {
        try {
          const key = keys[i].trim();
          const attrs = _instructions(result, key);
          decrypted = DotenvModule.decrypt(attrs.ciphertext, attrs.key);
          break;
        } catch (error) {
          if (i + 1 >= length) {
            throw error;
          }
        }
      }
      return DotenvModule.parse(decrypted);
    }
    function _warn(message) {
      console.error(`\u26A0 ${message}`);
    }
    function _debug(message) {
      console.log(`\u2506 ${message}`);
    }
    function _log(message) {
      console.log(`\u25C7 ${message}`);
    }
    function _dotenvKey(options) {
      if (options && options.DOTENV_KEY && options.DOTENV_KEY.length > 0) {
        return options.DOTENV_KEY;
      }
      if (process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0) {
        return process.env.DOTENV_KEY;
      }
      return "";
    }
    function _instructions(result, dotenvKey) {
      let uri;
      try {
        uri = new URL(dotenvKey);
      } catch (error) {
        if (error.code === "ERR_INVALID_URL") {
          const err = new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        }
        throw error;
      }
      const key = uri.password;
      if (!key) {
        const err = new Error("INVALID_DOTENV_KEY: Missing key part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environment = uri.searchParams.get("environment");
      if (!environment) {
        const err = new Error("INVALID_DOTENV_KEY: Missing environment part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environmentKey = `DOTENV_VAULT_${environment.toUpperCase()}`;
      const ciphertext = result.parsed[environmentKey];
      if (!ciphertext) {
        const err = new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${environmentKey} in your .env.vault file.`);
        err.code = "NOT_FOUND_DOTENV_ENVIRONMENT";
        throw err;
      }
      return { ciphertext, key };
    }
    function _vaultPath(options) {
      let possibleVaultPath = null;
      if (options && options.path && options.path.length > 0) {
        if (Array.isArray(options.path)) {
          for (const filepath of options.path) {
            if (fs6.existsSync(filepath)) {
              possibleVaultPath = filepath.endsWith(".vault") ? filepath : `${filepath}.vault`;
            }
          }
        } else {
          possibleVaultPath = options.path.endsWith(".vault") ? options.path : `${options.path}.vault`;
        }
      } else {
        possibleVaultPath = path6.resolve(process.cwd(), ".env.vault");
      }
      if (fs6.existsSync(possibleVaultPath)) {
        return possibleVaultPath;
      }
      return null;
    }
    function _resolveHome(envPath) {
      return envPath[0] === "~" ? path6.join(os.homedir(), envPath.slice(1)) : envPath;
    }
    function _configVault(options) {
      const debug = parseBoolean(process.env.DOTENV_CONFIG_DEBUG || options && options.debug);
      const quiet = parseBoolean(process.env.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (debug || !quiet) {
        _log("loading env from encrypted .env.vault");
      }
      const parsed = DotenvModule._parseVault(options);
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      DotenvModule.populate(processEnv, parsed, options);
      return { parsed };
    }
    function configDotenv(options) {
      const dotenvPath = path6.resolve(process.cwd(), ".env");
      let encoding = "utf8";
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      let debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || options && options.debug);
      let quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (options && options.encoding) {
        encoding = options.encoding;
      } else {
        if (debug) {
          _debug("no encoding is specified (UTF-8 is used by default)");
        }
      }
      let optionPaths = [dotenvPath];
      if (options && options.path) {
        if (!Array.isArray(options.path)) {
          optionPaths = [_resolveHome(options.path)];
        } else {
          optionPaths = [];
          for (const filepath of options.path) {
            optionPaths.push(_resolveHome(filepath));
          }
        }
      }
      let lastError;
      const parsedAll = {};
      for (const path7 of optionPaths) {
        try {
          const parsed = DotenvModule.parse(fs6.readFileSync(path7, { encoding }));
          DotenvModule.populate(parsedAll, parsed, options);
        } catch (e) {
          if (debug) {
            _debug(`failed to load ${path7} ${e.message}`);
          }
          lastError = e;
        }
      }
      const populated = DotenvModule.populate(processEnv, parsedAll, options);
      debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || debug);
      quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || quiet);
      if (debug || !quiet) {
        const keysCount = Object.keys(populated).length;
        const shortPaths = [];
        for (const filePath of optionPaths) {
          try {
            const relative = path6.relative(process.cwd(), filePath);
            shortPaths.push(relative);
          } catch (e) {
            if (debug) {
              _debug(`failed to load ${filePath} ${e.message}`);
            }
            lastError = e;
          }
        }
        _log(`injected env (${keysCount}) from ${shortPaths.join(",")} ${dim(`// tip: ${_getRandomTip()}`)}`);
      }
      if (lastError) {
        return { parsed: parsedAll, error: lastError };
      } else {
        return { parsed: parsedAll };
      }
    }
    function config(options) {
      if (_dotenvKey(options).length === 0) {
        return DotenvModule.configDotenv(options);
      }
      const vaultPath = _vaultPath(options);
      if (!vaultPath) {
        _warn(`you set DOTENV_KEY but you are missing a .env.vault file at ${vaultPath}`);
        return DotenvModule.configDotenv(options);
      }
      return DotenvModule._configVault(options);
    }
    function decrypt(encrypted, keyStr) {
      const key = Buffer.from(keyStr.slice(-64), "hex");
      let ciphertext = Buffer.from(encrypted, "base64");
      const nonce = ciphertext.subarray(0, 12);
      const authTag = ciphertext.subarray(-16);
      ciphertext = ciphertext.subarray(12, -16);
      try {
        const aesgcm = crypto.createDecipheriv("aes-256-gcm", key, nonce);
        aesgcm.setAuthTag(authTag);
        return `${aesgcm.update(ciphertext)}${aesgcm.final()}`;
      } catch (error) {
        const isRange = error instanceof RangeError;
        const invalidKeyLength = error.message === "Invalid key length";
        const decryptionFailed = error.message === "Unsupported state or unable to authenticate data";
        if (isRange || invalidKeyLength) {
          const err = new Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        } else if (decryptionFailed) {
          const err = new Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");
          err.code = "DECRYPTION_FAILED";
          throw err;
        } else {
          throw error;
        }
      }
    }
    function populate(processEnv, parsed, options = {}) {
      const debug = Boolean(options && options.debug);
      const override = Boolean(options && options.override);
      const populated = {};
      if (typeof parsed !== "object") {
        const err = new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
        err.code = "OBJECT_REQUIRED";
        throw err;
      }
      for (const key of Object.keys(parsed)) {
        if (Object.prototype.hasOwnProperty.call(processEnv, key)) {
          if (override === true) {
            processEnv[key] = parsed[key];
            populated[key] = parsed[key];
          }
          if (debug) {
            if (override === true) {
              _debug(`"${key}" is already defined and WAS overwritten`);
            } else {
              _debug(`"${key}" is already defined and was NOT overwritten`);
            }
          }
        } else {
          processEnv[key] = parsed[key];
          populated[key] = parsed[key];
        }
      }
      return populated;
    }
    var DotenvModule = {
      configDotenv,
      _configVault,
      _parseVault,
      config,
      decrypt,
      parse: parse3,
      populate
    };
    module.exports.configDotenv = DotenvModule.configDotenv;
    module.exports._configVault = DotenvModule._configVault;
    module.exports._parseVault = DotenvModule._parseVault;
    module.exports.config = DotenvModule.config;
    module.exports.decrypt = DotenvModule.decrypt;
    module.exports.parse = DotenvModule.parse;
    module.exports.populate = DotenvModule.populate;
    module.exports = DotenvModule;
  }
});

// node_modules/tinycolor2/cjs/tinycolor.js
var require_tinycolor = __commonJS({
  "node_modules/tinycolor2/cjs/tinycolor.js"(exports, module) {
    (function(global, factory) {
      typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory() : typeof define === "function" && define.amd ? define(factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, global.tinycolor = factory());
    })(exports, (function() {
      "use strict";
      function _typeof2(obj) {
        "@babel/helpers - typeof";
        return _typeof2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
          return typeof obj2;
        } : function(obj2) {
          return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        }, _typeof2(obj);
      }
      var trimLeft2 = /^\s+/;
      var trimRight2 = /\s+$/;
      function tinycolor2(color, opts) {
        color = color ? color : "";
        opts = opts || {};
        if (color instanceof tinycolor2) {
          return color;
        }
        if (!(this instanceof tinycolor2)) {
          return new tinycolor2(color, opts);
        }
        var rgb = inputToRGB2(color);
        this._originalInput = color, this._r = rgb.r, this._g = rgb.g, this._b = rgb.b, this._a = rgb.a, this._roundA = Math.round(100 * this._a) / 100, this._format = opts.format || rgb.format;
        this._gradientType = opts.gradientType;
        if (this._r < 1) this._r = Math.round(this._r);
        if (this._g < 1) this._g = Math.round(this._g);
        if (this._b < 1) this._b = Math.round(this._b);
        this._ok = rgb.ok;
      }
      tinycolor2.prototype = {
        isDark: function isDark2() {
          return this.getBrightness() < 128;
        },
        isLight: function isLight2() {
          return !this.isDark();
        },
        isValid: function isValid2() {
          return this._ok;
        },
        getOriginalInput: function getOriginalInput2() {
          return this._originalInput;
        },
        getFormat: function getFormat2() {
          return this._format;
        },
        getAlpha: function getAlpha2() {
          return this._a;
        },
        getBrightness: function getBrightness2() {
          var rgb = this.toRgb();
          return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1e3;
        },
        getLuminance: function getLuminance3() {
          var rgb = this.toRgb();
          var RsRGB, GsRGB, BsRGB, R, G, B;
          RsRGB = rgb.r / 255;
          GsRGB = rgb.g / 255;
          BsRGB = rgb.b / 255;
          if (RsRGB <= 0.03928) R = RsRGB / 12.92;
          else R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
          if (GsRGB <= 0.03928) G = GsRGB / 12.92;
          else G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
          if (BsRGB <= 0.03928) B = BsRGB / 12.92;
          else B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
          return 0.2126 * R + 0.7152 * G + 0.0722 * B;
        },
        setAlpha: function setAlpha2(value) {
          this._a = boundAlpha2(value);
          this._roundA = Math.round(100 * this._a) / 100;
          return this;
        },
        toHsv: function toHsv2() {
          var hsv = rgbToHsv2(this._r, this._g, this._b);
          return {
            h: hsv.h * 360,
            s: hsv.s,
            v: hsv.v,
            a: this._a
          };
        },
        toHsvString: function toHsvString2() {
          var hsv = rgbToHsv2(this._r, this._g, this._b);
          var h = Math.round(hsv.h * 360), s = Math.round(hsv.s * 100), v = Math.round(hsv.v * 100);
          return this._a == 1 ? "hsv(" + h + ", " + s + "%, " + v + "%)" : "hsva(" + h + ", " + s + "%, " + v + "%, " + this._roundA + ")";
        },
        toHsl: function toHsl2() {
          var hsl = rgbToHsl2(this._r, this._g, this._b);
          return {
            h: hsl.h * 360,
            s: hsl.s,
            l: hsl.l,
            a: this._a
          };
        },
        toHslString: function toHslString2() {
          var hsl = rgbToHsl2(this._r, this._g, this._b);
          var h = Math.round(hsl.h * 360), s = Math.round(hsl.s * 100), l = Math.round(hsl.l * 100);
          return this._a == 1 ? "hsl(" + h + ", " + s + "%, " + l + "%)" : "hsla(" + h + ", " + s + "%, " + l + "%, " + this._roundA + ")";
        },
        toHex: function toHex2(allow3Char) {
          return rgbToHex2(this._r, this._g, this._b, allow3Char);
        },
        toHexString: function toHexString2(allow3Char) {
          return "#" + this.toHex(allow3Char);
        },
        toHex8: function toHex82(allow4Char) {
          return rgbaToHex2(this._r, this._g, this._b, this._a, allow4Char);
        },
        toHex8String: function toHex8String2(allow4Char) {
          return "#" + this.toHex8(allow4Char);
        },
        toRgb: function toRgb2() {
          return {
            r: Math.round(this._r),
            g: Math.round(this._g),
            b: Math.round(this._b),
            a: this._a
          };
        },
        toRgbString: function toRgbString2() {
          return this._a == 1 ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")";
        },
        toPercentageRgb: function toPercentageRgb2() {
          return {
            r: Math.round(bound012(this._r, 255) * 100) + "%",
            g: Math.round(bound012(this._g, 255) * 100) + "%",
            b: Math.round(bound012(this._b, 255) * 100) + "%",
            a: this._a
          };
        },
        toPercentageRgbString: function toPercentageRgbString2() {
          return this._a == 1 ? "rgb(" + Math.round(bound012(this._r, 255) * 100) + "%, " + Math.round(bound012(this._g, 255) * 100) + "%, " + Math.round(bound012(this._b, 255) * 100) + "%)" : "rgba(" + Math.round(bound012(this._r, 255) * 100) + "%, " + Math.round(bound012(this._g, 255) * 100) + "%, " + Math.round(bound012(this._b, 255) * 100) + "%, " + this._roundA + ")";
        },
        toName: function toName2() {
          if (this._a === 0) {
            return "transparent";
          }
          if (this._a < 1) {
            return false;
          }
          return hexNames2[rgbToHex2(this._r, this._g, this._b, true)] || false;
        },
        toFilter: function toFilter2(secondColor) {
          var hex8String = "#" + rgbaToArgbHex2(this._r, this._g, this._b, this._a);
          var secondHex8String = hex8String;
          var gradientType = this._gradientType ? "GradientType = 1, " : "";
          if (secondColor) {
            var s = tinycolor2(secondColor);
            secondHex8String = "#" + rgbaToArgbHex2(s._r, s._g, s._b, s._a);
          }
          return "progid:DXImageTransform.Microsoft.gradient(" + gradientType + "startColorstr=" + hex8String + ",endColorstr=" + secondHex8String + ")";
        },
        toString: function toString2(format) {
          var formatSet = !!format;
          format = format || this._format;
          var formattedString = false;
          var hasAlpha = this._a < 1 && this._a >= 0;
          var needsAlphaFormat = !formatSet && hasAlpha && (format === "hex" || format === "hex6" || format === "hex3" || format === "hex4" || format === "hex8" || format === "name");
          if (needsAlphaFormat) {
            if (format === "name" && this._a === 0) {
              return this.toName();
            }
            return this.toRgbString();
          }
          if (format === "rgb") {
            formattedString = this.toRgbString();
          }
          if (format === "prgb") {
            formattedString = this.toPercentageRgbString();
          }
          if (format === "hex" || format === "hex6") {
            formattedString = this.toHexString();
          }
          if (format === "hex3") {
            formattedString = this.toHexString(true);
          }
          if (format === "hex4") {
            formattedString = this.toHex8String(true);
          }
          if (format === "hex8") {
            formattedString = this.toHex8String();
          }
          if (format === "name") {
            formattedString = this.toName();
          }
          if (format === "hsl") {
            formattedString = this.toHslString();
          }
          if (format === "hsv") {
            formattedString = this.toHsvString();
          }
          return formattedString || this.toHexString();
        },
        clone: function clone2() {
          return tinycolor2(this.toString());
        },
        _applyModification: function _applyModification2(fn, args) {
          var color = fn.apply(null, [this].concat([].slice.call(args)));
          this._r = color._r;
          this._g = color._g;
          this._b = color._b;
          this.setAlpha(color._a);
          return this;
        },
        lighten: function lighten2() {
          return this._applyModification(_lighten2, arguments);
        },
        brighten: function brighten2() {
          return this._applyModification(_brighten2, arguments);
        },
        darken: function darken2() {
          return this._applyModification(_darken2, arguments);
        },
        desaturate: function desaturate2() {
          return this._applyModification(_desaturate2, arguments);
        },
        saturate: function saturate2() {
          return this._applyModification(_saturate2, arguments);
        },
        greyscale: function greyscale2() {
          return this._applyModification(_greyscale2, arguments);
        },
        spin: function spin2() {
          return this._applyModification(_spin2, arguments);
        },
        _applyCombination: function _applyCombination2(fn, args) {
          return fn.apply(null, [this].concat([].slice.call(args)));
        },
        analogous: function analogous2() {
          return this._applyCombination(_analogous2, arguments);
        },
        complement: function complement2() {
          return this._applyCombination(_complement2, arguments);
        },
        monochromatic: function monochromatic2() {
          return this._applyCombination(_monochromatic2, arguments);
        },
        splitcomplement: function splitcomplement2() {
          return this._applyCombination(_splitcomplement2, arguments);
        },
        // Disabled until https://github.com/bgrins/TinyColor/issues/254
        // polyad: function (number) {
        //   return this._applyCombination(polyad, [number]);
        // },
        triad: function triad2() {
          return this._applyCombination(polyad2, [3]);
        },
        tetrad: function tetrad2() {
          return this._applyCombination(polyad2, [4]);
        }
      };
      tinycolor2.fromRatio = function(color, opts) {
        if (_typeof2(color) == "object") {
          var newColor = {};
          for (var i in color) {
            if (color.hasOwnProperty(i)) {
              if (i === "a") {
                newColor[i] = color[i];
              } else {
                newColor[i] = convertToPercentage2(color[i]);
              }
            }
          }
          color = newColor;
        }
        return tinycolor2(color, opts);
      };
      function inputToRGB2(color) {
        var rgb = {
          r: 0,
          g: 0,
          b: 0
        };
        var a = 1;
        var s = null;
        var v = null;
        var l = null;
        var ok = false;
        var format = false;
        if (typeof color == "string") {
          color = stringInputToObject2(color);
        }
        if (_typeof2(color) == "object") {
          if (isValidCSSUnit2(color.r) && isValidCSSUnit2(color.g) && isValidCSSUnit2(color.b)) {
            rgb = rgbToRgb2(color.r, color.g, color.b);
            ok = true;
            format = String(color.r).substr(-1) === "%" ? "prgb" : "rgb";
          } else if (isValidCSSUnit2(color.h) && isValidCSSUnit2(color.s) && isValidCSSUnit2(color.v)) {
            s = convertToPercentage2(color.s);
            v = convertToPercentage2(color.v);
            rgb = hsvToRgb2(color.h, s, v);
            ok = true;
            format = "hsv";
          } else if (isValidCSSUnit2(color.h) && isValidCSSUnit2(color.s) && isValidCSSUnit2(color.l)) {
            s = convertToPercentage2(color.s);
            l = convertToPercentage2(color.l);
            rgb = hslToRgb2(color.h, s, l);
            ok = true;
            format = "hsl";
          }
          if (color.hasOwnProperty("a")) {
            a = color.a;
          }
        }
        a = boundAlpha2(a);
        return {
          ok,
          format: color.format || format,
          r: Math.min(255, Math.max(rgb.r, 0)),
          g: Math.min(255, Math.max(rgb.g, 0)),
          b: Math.min(255, Math.max(rgb.b, 0)),
          a
        };
      }
      function rgbToRgb2(r, g, b) {
        return {
          r: bound012(r, 255) * 255,
          g: bound012(g, 255) * 255,
          b: bound012(b, 255) * 255
        };
      }
      function rgbToHsl2(r, g, b) {
        r = bound012(r, 255);
        g = bound012(g, 255);
        b = bound012(b, 255);
        var max = Math.max(r, g, b), min = Math.min(r, g, b);
        var h, s, l = (max + min) / 2;
        if (max == min) {
          h = s = 0;
        } else {
          var d = max - min;
          s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
          switch (max) {
            case r:
              h = (g - b) / d + (g < b ? 6 : 0);
              break;
            case g:
              h = (b - r) / d + 2;
              break;
            case b:
              h = (r - g) / d + 4;
              break;
          }
          h /= 6;
        }
        return {
          h,
          s,
          l
        };
      }
      function hslToRgb2(h, s, l) {
        var r, g, b;
        h = bound012(h, 360);
        s = bound012(s, 100);
        l = bound012(l, 100);
        function hue2rgb(p2, q2, t) {
          if (t < 0) t += 1;
          if (t > 1) t -= 1;
          if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
          if (t < 1 / 2) return q2;
          if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
          return p2;
        }
        if (s === 0) {
          r = g = b = l;
        } else {
          var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
          var p = 2 * l - q;
          r = hue2rgb(p, q, h + 1 / 3);
          g = hue2rgb(p, q, h);
          b = hue2rgb(p, q, h - 1 / 3);
        }
        return {
          r: r * 255,
          g: g * 255,
          b: b * 255
        };
      }
      function rgbToHsv2(r, g, b) {
        r = bound012(r, 255);
        g = bound012(g, 255);
        b = bound012(b, 255);
        var max = Math.max(r, g, b), min = Math.min(r, g, b);
        var h, s, v = max;
        var d = max - min;
        s = max === 0 ? 0 : d / max;
        if (max == min) {
          h = 0;
        } else {
          switch (max) {
            case r:
              h = (g - b) / d + (g < b ? 6 : 0);
              break;
            case g:
              h = (b - r) / d + 2;
              break;
            case b:
              h = (r - g) / d + 4;
              break;
          }
          h /= 6;
        }
        return {
          h,
          s,
          v
        };
      }
      function hsvToRgb2(h, s, v) {
        h = bound012(h, 360) * 6;
        s = bound012(s, 100);
        v = bound012(v, 100);
        var i = Math.floor(h), f = h - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s), mod = i % 6, r = [v, q, p, p, t, v][mod], g = [t, v, v, q, p, p][mod], b = [p, p, t, v, v, q][mod];
        return {
          r: r * 255,
          g: g * 255,
          b: b * 255
        };
      }
      function rgbToHex2(r, g, b, allow3Char) {
        var hex = [pad22(Math.round(r).toString(16)), pad22(Math.round(g).toString(16)), pad22(Math.round(b).toString(16))];
        if (allow3Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1)) {
          return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
        }
        return hex.join("");
      }
      function rgbaToHex2(r, g, b, a, allow4Char) {
        var hex = [pad22(Math.round(r).toString(16)), pad22(Math.round(g).toString(16)), pad22(Math.round(b).toString(16)), pad22(convertDecimalToHex2(a))];
        if (allow4Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1) && hex[3].charAt(0) == hex[3].charAt(1)) {
          return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
        }
        return hex.join("");
      }
      function rgbaToArgbHex2(r, g, b, a) {
        var hex = [pad22(convertDecimalToHex2(a)), pad22(Math.round(r).toString(16)), pad22(Math.round(g).toString(16)), pad22(Math.round(b).toString(16))];
        return hex.join("");
      }
      tinycolor2.equals = function(color1, color2) {
        if (!color1 || !color2) return false;
        return tinycolor2(color1).toRgbString() == tinycolor2(color2).toRgbString();
      };
      tinycolor2.random = function() {
        return tinycolor2.fromRatio({
          r: Math.random(),
          g: Math.random(),
          b: Math.random()
        });
      };
      function _desaturate2(color, amount) {
        amount = amount === 0 ? 0 : amount || 10;
        var hsl = tinycolor2(color).toHsl();
        hsl.s -= amount / 100;
        hsl.s = clamp012(hsl.s);
        return tinycolor2(hsl);
      }
      function _saturate2(color, amount) {
        amount = amount === 0 ? 0 : amount || 10;
        var hsl = tinycolor2(color).toHsl();
        hsl.s += amount / 100;
        hsl.s = clamp012(hsl.s);
        return tinycolor2(hsl);
      }
      function _greyscale2(color) {
        return tinycolor2(color).desaturate(100);
      }
      function _lighten2(color, amount) {
        amount = amount === 0 ? 0 : amount || 10;
        var hsl = tinycolor2(color).toHsl();
        hsl.l += amount / 100;
        hsl.l = clamp012(hsl.l);
        return tinycolor2(hsl);
      }
      function _brighten2(color, amount) {
        amount = amount === 0 ? 0 : amount || 10;
        var rgb = tinycolor2(color).toRgb();
        rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
        rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
        rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
        return tinycolor2(rgb);
      }
      function _darken2(color, amount) {
        amount = amount === 0 ? 0 : amount || 10;
        var hsl = tinycolor2(color).toHsl();
        hsl.l -= amount / 100;
        hsl.l = clamp012(hsl.l);
        return tinycolor2(hsl);
      }
      function _spin2(color, amount) {
        var hsl = tinycolor2(color).toHsl();
        var hue = (hsl.h + amount) % 360;
        hsl.h = hue < 0 ? 360 + hue : hue;
        return tinycolor2(hsl);
      }
      function _complement2(color) {
        var hsl = tinycolor2(color).toHsl();
        hsl.h = (hsl.h + 180) % 360;
        return tinycolor2(hsl);
      }
      function polyad2(color, number) {
        if (isNaN(number) || number <= 0) {
          throw new Error("Argument to polyad must be a positive number");
        }
        var hsl = tinycolor2(color).toHsl();
        var result = [tinycolor2(color)];
        var step = 360 / number;
        for (var i = 1; i < number; i++) {
          result.push(tinycolor2({
            h: (hsl.h + i * step) % 360,
            s: hsl.s,
            l: hsl.l
          }));
        }
        return result;
      }
      function _splitcomplement2(color) {
        var hsl = tinycolor2(color).toHsl();
        var h = hsl.h;
        return [tinycolor2(color), tinycolor2({
          h: (h + 72) % 360,
          s: hsl.s,
          l: hsl.l
        }), tinycolor2({
          h: (h + 216) % 360,
          s: hsl.s,
          l: hsl.l
        })];
      }
      function _analogous2(color, results, slices) {
        results = results || 6;
        slices = slices || 30;
        var hsl = tinycolor2(color).toHsl();
        var part = 360 / slices;
        var ret = [tinycolor2(color)];
        for (hsl.h = (hsl.h - (part * results >> 1) + 720) % 360; --results; ) {
          hsl.h = (hsl.h + part) % 360;
          ret.push(tinycolor2(hsl));
        }
        return ret;
      }
      function _monochromatic2(color, results) {
        results = results || 6;
        var hsv = tinycolor2(color).toHsv();
        var h = hsv.h, s = hsv.s, v = hsv.v;
        var ret = [];
        var modification = 1 / results;
        while (results--) {
          ret.push(tinycolor2({
            h,
            s,
            v
          }));
          v = (v + modification) % 1;
        }
        return ret;
      }
      tinycolor2.mix = function(color1, color2, amount) {
        amount = amount === 0 ? 0 : amount || 50;
        var rgb1 = tinycolor2(color1).toRgb();
        var rgb2 = tinycolor2(color2).toRgb();
        var p = amount / 100;
        var rgba = {
          r: (rgb2.r - rgb1.r) * p + rgb1.r,
          g: (rgb2.g - rgb1.g) * p + rgb1.g,
          b: (rgb2.b - rgb1.b) * p + rgb1.b,
          a: (rgb2.a - rgb1.a) * p + rgb1.a
        };
        return tinycolor2(rgba);
      };
      tinycolor2.readability = function(color1, color2) {
        var c1 = tinycolor2(color1);
        var c2 = tinycolor2(color2);
        return (Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) / (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05);
      };
      tinycolor2.isReadable = function(color1, color2, wcag2) {
        var readability = tinycolor2.readability(color1, color2);
        var wcag2Parms, out;
        out = false;
        wcag2Parms = validateWCAG2Parms2(wcag2);
        switch (wcag2Parms.level + wcag2Parms.size) {
          case "AAsmall":
          case "AAAlarge":
            out = readability >= 4.5;
            break;
          case "AAlarge":
            out = readability >= 3;
            break;
          case "AAAsmall":
            out = readability >= 7;
            break;
        }
        return out;
      };
      tinycolor2.mostReadable = function(baseColor, colorList, args) {
        var bestColor = null;
        var bestScore = 0;
        var readability;
        var includeFallbackColors, level, size;
        args = args || {};
        includeFallbackColors = args.includeFallbackColors;
        level = args.level;
        size = args.size;
        for (var i = 0; i < colorList.length; i++) {
          readability = tinycolor2.readability(baseColor, colorList[i]);
          if (readability > bestScore) {
            bestScore = readability;
            bestColor = tinycolor2(colorList[i]);
          }
        }
        if (tinycolor2.isReadable(baseColor, bestColor, {
          level,
          size
        }) || !includeFallbackColors) {
          return bestColor;
        } else {
          args.includeFallbackColors = false;
          return tinycolor2.mostReadable(baseColor, ["#fff", "#000"], args);
        }
      };
      var names2 = tinycolor2.names = {
        aliceblue: "f0f8ff",
        antiquewhite: "faebd7",
        aqua: "0ff",
        aquamarine: "7fffd4",
        azure: "f0ffff",
        beige: "f5f5dc",
        bisque: "ffe4c4",
        black: "000",
        blanchedalmond: "ffebcd",
        blue: "00f",
        blueviolet: "8a2be2",
        brown: "a52a2a",
        burlywood: "deb887",
        burntsienna: "ea7e5d",
        cadetblue: "5f9ea0",
        chartreuse: "7fff00",
        chocolate: "d2691e",
        coral: "ff7f50",
        cornflowerblue: "6495ed",
        cornsilk: "fff8dc",
        crimson: "dc143c",
        cyan: "0ff",
        darkblue: "00008b",
        darkcyan: "008b8b",
        darkgoldenrod: "b8860b",
        darkgray: "a9a9a9",
        darkgreen: "006400",
        darkgrey: "a9a9a9",
        darkkhaki: "bdb76b",
        darkmagenta: "8b008b",
        darkolivegreen: "556b2f",
        darkorange: "ff8c00",
        darkorchid: "9932cc",
        darkred: "8b0000",
        darksalmon: "e9967a",
        darkseagreen: "8fbc8f",
        darkslateblue: "483d8b",
        darkslategray: "2f4f4f",
        darkslategrey: "2f4f4f",
        darkturquoise: "00ced1",
        darkviolet: "9400d3",
        deeppink: "ff1493",
        deepskyblue: "00bfff",
        dimgray: "696969",
        dimgrey: "696969",
        dodgerblue: "1e90ff",
        firebrick: "b22222",
        floralwhite: "fffaf0",
        forestgreen: "228b22",
        fuchsia: "f0f",
        gainsboro: "dcdcdc",
        ghostwhite: "f8f8ff",
        gold: "ffd700",
        goldenrod: "daa520",
        gray: "808080",
        green: "008000",
        greenyellow: "adff2f",
        grey: "808080",
        honeydew: "f0fff0",
        hotpink: "ff69b4",
        indianred: "cd5c5c",
        indigo: "4b0082",
        ivory: "fffff0",
        khaki: "f0e68c",
        lavender: "e6e6fa",
        lavenderblush: "fff0f5",
        lawngreen: "7cfc00",
        lemonchiffon: "fffacd",
        lightblue: "add8e6",
        lightcoral: "f08080",
        lightcyan: "e0ffff",
        lightgoldenrodyellow: "fafad2",
        lightgray: "d3d3d3",
        lightgreen: "90ee90",
        lightgrey: "d3d3d3",
        lightpink: "ffb6c1",
        lightsalmon: "ffa07a",
        lightseagreen: "20b2aa",
        lightskyblue: "87cefa",
        lightslategray: "789",
        lightslategrey: "789",
        lightsteelblue: "b0c4de",
        lightyellow: "ffffe0",
        lime: "0f0",
        limegreen: "32cd32",
        linen: "faf0e6",
        magenta: "f0f",
        maroon: "800000",
        mediumaquamarine: "66cdaa",
        mediumblue: "0000cd",
        mediumorchid: "ba55d3",
        mediumpurple: "9370db",
        mediumseagreen: "3cb371",
        mediumslateblue: "7b68ee",
        mediumspringgreen: "00fa9a",
        mediumturquoise: "48d1cc",
        mediumvioletred: "c71585",
        midnightblue: "191970",
        mintcream: "f5fffa",
        mistyrose: "ffe4e1",
        moccasin: "ffe4b5",
        navajowhite: "ffdead",
        navy: "000080",
        oldlace: "fdf5e6",
        olive: "808000",
        olivedrab: "6b8e23",
        orange: "ffa500",
        orangered: "ff4500",
        orchid: "da70d6",
        palegoldenrod: "eee8aa",
        palegreen: "98fb98",
        paleturquoise: "afeeee",
        palevioletred: "db7093",
        papayawhip: "ffefd5",
        peachpuff: "ffdab9",
        peru: "cd853f",
        pink: "ffc0cb",
        plum: "dda0dd",
        powderblue: "b0e0e6",
        purple: "800080",
        rebeccapurple: "663399",
        red: "f00",
        rosybrown: "bc8f8f",
        royalblue: "4169e1",
        saddlebrown: "8b4513",
        salmon: "fa8072",
        sandybrown: "f4a460",
        seagreen: "2e8b57",
        seashell: "fff5ee",
        sienna: "a0522d",
        silver: "c0c0c0",
        skyblue: "87ceeb",
        slateblue: "6a5acd",
        slategray: "708090",
        slategrey: "708090",
        snow: "fffafa",
        springgreen: "00ff7f",
        steelblue: "4682b4",
        tan: "d2b48c",
        teal: "008080",
        thistle: "d8bfd8",
        tomato: "ff6347",
        turquoise: "40e0d0",
        violet: "ee82ee",
        wheat: "f5deb3",
        white: "fff",
        whitesmoke: "f5f5f5",
        yellow: "ff0",
        yellowgreen: "9acd32"
      };
      var hexNames2 = tinycolor2.hexNames = flip2(names2);
      function flip2(o) {
        var flipped = {};
        for (var i in o) {
          if (o.hasOwnProperty(i)) {
            flipped[o[i]] = i;
          }
        }
        return flipped;
      }
      function boundAlpha2(a) {
        a = parseFloat(a);
        if (isNaN(a) || a < 0 || a > 1) {
          a = 1;
        }
        return a;
      }
      function bound012(n, max) {
        if (isOnePointZero2(n)) n = "100%";
        var processPercent = isPercentage2(n);
        n = Math.min(max, Math.max(0, parseFloat(n)));
        if (processPercent) {
          n = parseInt(n * max, 10) / 100;
        }
        if (Math.abs(n - max) < 1e-6) {
          return 1;
        }
        return n % max / parseFloat(max);
      }
      function clamp012(val) {
        return Math.min(1, Math.max(0, val));
      }
      function parseIntFromHex2(val) {
        return parseInt(val, 16);
      }
      function isOnePointZero2(n) {
        return typeof n == "string" && n.indexOf(".") != -1 && parseFloat(n) === 1;
      }
      function isPercentage2(n) {
        return typeof n === "string" && n.indexOf("%") != -1;
      }
      function pad22(c) {
        return c.length == 1 ? "0" + c : "" + c;
      }
      function convertToPercentage2(n) {
        if (n <= 1) {
          n = n * 100 + "%";
        }
        return n;
      }
      function convertDecimalToHex2(d) {
        return Math.round(parseFloat(d) * 255).toString(16);
      }
      function convertHexToDecimal2(h) {
        return parseIntFromHex2(h) / 255;
      }
      var matchers2 = (function() {
        var CSS_INTEGER = "[-\\+]?\\d+%?";
        var CSS_NUMBER = "[-\\+]?\\d*\\.\\d+%?";
        var CSS_UNIT = "(?:" + CSS_NUMBER + ")|(?:" + CSS_INTEGER + ")";
        var PERMISSIVE_MATCH3 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
        var PERMISSIVE_MATCH4 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
        return {
          CSS_UNIT: new RegExp(CSS_UNIT),
          rgb: new RegExp("rgb" + PERMISSIVE_MATCH3),
          rgba: new RegExp("rgba" + PERMISSIVE_MATCH4),
          hsl: new RegExp("hsl" + PERMISSIVE_MATCH3),
          hsla: new RegExp("hsla" + PERMISSIVE_MATCH4),
          hsv: new RegExp("hsv" + PERMISSIVE_MATCH3),
          hsva: new RegExp("hsva" + PERMISSIVE_MATCH4),
          hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
          hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
          hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
          hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
        };
      })();
      function isValidCSSUnit2(color) {
        return !!matchers2.CSS_UNIT.exec(color);
      }
      function stringInputToObject2(color) {
        color = color.replace(trimLeft2, "").replace(trimRight2, "").toLowerCase();
        var named = false;
        if (names2[color]) {
          color = names2[color];
          named = true;
        } else if (color == "transparent") {
          return {
            r: 0,
            g: 0,
            b: 0,
            a: 0,
            format: "name"
          };
        }
        var match;
        if (match = matchers2.rgb.exec(color)) {
          return {
            r: match[1],
            g: match[2],
            b: match[3]
          };
        }
        if (match = matchers2.rgba.exec(color)) {
          return {
            r: match[1],
            g: match[2],
            b: match[3],
            a: match[4]
          };
        }
        if (match = matchers2.hsl.exec(color)) {
          return {
            h: match[1],
            s: match[2],
            l: match[3]
          };
        }
        if (match = matchers2.hsla.exec(color)) {
          return {
            h: match[1],
            s: match[2],
            l: match[3],
            a: match[4]
          };
        }
        if (match = matchers2.hsv.exec(color)) {
          return {
            h: match[1],
            s: match[2],
            v: match[3]
          };
        }
        if (match = matchers2.hsva.exec(color)) {
          return {
            h: match[1],
            s: match[2],
            v: match[3],
            a: match[4]
          };
        }
        if (match = matchers2.hex8.exec(color)) {
          return {
            r: parseIntFromHex2(match[1]),
            g: parseIntFromHex2(match[2]),
            b: parseIntFromHex2(match[3]),
            a: convertHexToDecimal2(match[4]),
            format: named ? "name" : "hex8"
          };
        }
        if (match = matchers2.hex6.exec(color)) {
          return {
            r: parseIntFromHex2(match[1]),
            g: parseIntFromHex2(match[2]),
            b: parseIntFromHex2(match[3]),
            format: named ? "name" : "hex"
          };
        }
        if (match = matchers2.hex4.exec(color)) {
          return {
            r: parseIntFromHex2(match[1] + "" + match[1]),
            g: parseIntFromHex2(match[2] + "" + match[2]),
            b: parseIntFromHex2(match[3] + "" + match[3]),
            a: convertHexToDecimal2(match[4] + "" + match[4]),
            format: named ? "name" : "hex8"
          };
        }
        if (match = matchers2.hex3.exec(color)) {
          return {
            r: parseIntFromHex2(match[1] + "" + match[1]),
            g: parseIntFromHex2(match[2] + "" + match[2]),
            b: parseIntFromHex2(match[3] + "" + match[3]),
            format: named ? "name" : "hex"
          };
        }
        return false;
      }
      function validateWCAG2Parms2(parms) {
        var level, size;
        parms = parms || {
          level: "AA",
          size: "small"
        };
        level = (parms.level || "AA").toUpperCase();
        size = (parms.size || "small").toLowerCase();
        if (level !== "AA" && level !== "AAA") {
          level = "AA";
        }
        if (size !== "small" && size !== "large") {
          size = "small";
        }
        return {
          level,
          size
        };
      }
      return tinycolor2;
    }));
  }
});

// node_modules/tinygradient/index.js
var require_tinygradient = __commonJS({
  "node_modules/tinygradient/index.js"(exports, module) {
    var tinycolor2 = require_tinycolor();
    var RGBA_MAX = { r: 256, g: 256, b: 256, a: 1 };
    var HSVA_MAX = { h: 360, s: 1, v: 1, a: 1 };
    function stepize(start, end, steps) {
      let step = {};
      for (let k in start) {
        if (start.hasOwnProperty(k)) {
          step[k] = steps === 0 ? 0 : (end[k] - start[k]) / steps;
        }
      }
      return step;
    }
    function interpolate(step, start, i, max) {
      let color = {};
      for (let k in start) {
        if (start.hasOwnProperty(k)) {
          color[k] = step[k] * i + start[k];
          color[k] = color[k] < 0 ? color[k] + max[k] : max[k] !== 1 ? color[k] % max[k] : color[k];
        }
      }
      return color;
    }
    function interpolateRgb(stop1, stop2, steps) {
      const start = stop1.color.toRgb();
      const end = stop2.color.toRgb();
      const step = stepize(start, end, steps);
      let gradient = [stop1.color];
      for (let i = 1; i < steps; i++) {
        const color = interpolate(step, start, i, RGBA_MAX);
        gradient.push(tinycolor2(color));
      }
      return gradient;
    }
    function interpolateHsv(stop1, stop2, steps, mode) {
      const start = stop1.color.toHsv();
      const end = stop2.color.toHsv();
      if (start.s === 0 || end.s === 0) {
        return interpolateRgb(stop1, stop2, steps);
      }
      let trigonometric;
      if (typeof mode === "boolean") {
        trigonometric = mode;
      } else {
        const trigShortest = start.h < end.h && end.h - start.h < 180 || start.h > end.h && start.h - end.h > 180;
        trigonometric = mode === "long" && trigShortest || mode === "short" && !trigShortest;
      }
      const step = stepize(start, end, steps);
      let gradient = [stop1.color];
      let diff;
      if (start.h <= end.h && !trigonometric || start.h >= end.h && trigonometric) {
        diff = end.h - start.h;
      } else if (trigonometric) {
        diff = 360 - end.h + start.h;
      } else {
        diff = 360 - start.h + end.h;
      }
      step.h = Math.pow(-1, trigonometric ? 1 : 0) * Math.abs(diff) / steps;
      for (let i = 1; i < steps; i++) {
        const color = interpolate(step, start, i, HSVA_MAX);
        gradient.push(tinycolor2(color));
      }
      return gradient;
    }
    function computeSubsteps(stops, steps) {
      const l = stops.length;
      steps = parseInt(steps, 10);
      if (isNaN(steps) || steps < 2) {
        throw new Error("Invalid number of steps (< 2)");
      }
      if (steps < l) {
        throw new Error("Number of steps cannot be inferior to number of stops");
      }
      let substeps = [];
      for (let i = 1; i < l; i++) {
        const step = (steps - 1) * (stops[i].pos - stops[i - 1].pos);
        substeps.push(Math.max(1, Math.round(step)));
      }
      let totalSubsteps = 1;
      for (let n = l - 1; n--; ) totalSubsteps += substeps[n];
      while (totalSubsteps !== steps) {
        if (totalSubsteps < steps) {
          const min = Math.min.apply(null, substeps);
          substeps[substeps.indexOf(min)]++;
          totalSubsteps++;
        } else {
          const max = Math.max.apply(null, substeps);
          substeps[substeps.indexOf(max)]--;
          totalSubsteps--;
        }
      }
      return substeps;
    }
    function computeAt(stops, pos, method, max) {
      if (pos < 0 || pos > 1) {
        throw new Error("Position must be between 0 and 1");
      }
      let start, end;
      for (let i = 0, l = stops.length; i < l - 1; i++) {
        if (pos >= stops[i].pos && pos < stops[i + 1].pos) {
          start = stops[i];
          end = stops[i + 1];
          break;
        }
      }
      if (!start) {
        start = end = stops[stops.length - 1];
      }
      const step = stepize(start.color[method](), end.color[method](), (end.pos - start.pos) * 100);
      const color = interpolate(step, start.color[method](), (pos - start.pos) * 100, max);
      return tinycolor2(color);
    }
    var TinyGradient = class _TinyGradient {
      /**
       * @param {StopInput[]|ColorInput[]} stops
       * @returns {TinyGradient}
       */
      constructor(stops) {
        if (stops.length < 2) {
          throw new Error("Invalid number of stops (< 2)");
        }
        const havingPositions = stops[0].pos !== void 0;
        let l = stops.length;
        let p = -1;
        let lastColorLess = false;
        this.stops = stops.map((stop, i) => {
          const hasPosition = stop.pos !== void 0;
          if (havingPositions ^ hasPosition) {
            throw new Error("Cannot mix positionned and not posionned color stops");
          }
          if (hasPosition) {
            const hasColor = stop.color !== void 0;
            if (!hasColor && (lastColorLess || i === 0 || i === l - 1)) {
              throw new Error("Cannot define two consecutive position-only stops");
            }
            lastColorLess = !hasColor;
            stop = {
              color: hasColor ? tinycolor2(stop.color) : null,
              colorLess: !hasColor,
              pos: stop.pos
            };
            if (stop.pos < 0 || stop.pos > 1) {
              throw new Error("Color stops positions must be between 0 and 1");
            } else if (stop.pos < p) {
              throw new Error("Color stops positions are not ordered");
            }
            p = stop.pos;
          } else {
            stop = {
              color: tinycolor2(stop.color !== void 0 ? stop.color : stop),
              pos: i / (l - 1)
            };
          }
          return stop;
        });
        if (this.stops[0].pos !== 0) {
          this.stops.unshift({
            color: this.stops[0].color,
            pos: 0
          });
          l++;
        }
        if (this.stops[l - 1].pos !== 1) {
          this.stops.push({
            color: this.stops[l - 1].color,
            pos: 1
          });
        }
      }
      /**
       * Return new instance with reversed stops
       * @return {TinyGradient}
       */
      reverse() {
        let stops = [];
        this.stops.forEach(function(stop) {
          stops.push({
            color: stop.color,
            pos: 1 - stop.pos
          });
        });
        return new _TinyGradient(stops.reverse());
      }
      /**
       * Return new instance with looped stops
       * @return {TinyGradient}
       */
      loop() {
        let stops1 = [];
        let stops2 = [];
        this.stops.forEach((stop) => {
          stops1.push({
            color: stop.color,
            pos: stop.pos / 2
          });
        });
        this.stops.slice(0, -1).forEach((stop) => {
          stops2.push({
            color: stop.color,
            pos: 1 - stop.pos / 2
          });
        });
        return new _TinyGradient(stops1.concat(stops2.reverse()));
      }
      /**
       * Generate gradient with RGBa interpolation
       * @param {number} steps
       * @return {tinycolor[]}
       */
      rgb(steps) {
        const substeps = computeSubsteps(this.stops, steps);
        let gradient = [];
        this.stops.forEach((stop, i) => {
          if (stop.colorLess) {
            stop.color = interpolateRgb(this.stops[i - 1], this.stops[i + 1], 2)[1];
          }
        });
        for (let i = 0, l = this.stops.length; i < l - 1; i++) {
          const rgb = interpolateRgb(this.stops[i], this.stops[i + 1], substeps[i]);
          gradient.splice(gradient.length, 0, ...rgb);
        }
        gradient.push(this.stops[this.stops.length - 1].color);
        return gradient;
      }
      /**
       * Generate gradient with HSVa interpolation
       * @param {number} steps
       * @param {boolean|'long'|'short'} [mode=false]
       *    - false to step in clockwise
       *    - true to step in trigonometric order
       *    - 'short' to use the shortest way
       *    - 'long' to use the longest way
       * @return {tinycolor[]}
       */
      hsv(steps, mode) {
        const substeps = computeSubsteps(this.stops, steps);
        let gradient = [];
        this.stops.forEach((stop, i) => {
          if (stop.colorLess) {
            stop.color = interpolateHsv(this.stops[i - 1], this.stops[i + 1], 2, mode)[1];
          }
        });
        for (let i = 0, l = this.stops.length; i < l - 1; i++) {
          const hsv = interpolateHsv(this.stops[i], this.stops[i + 1], substeps[i], mode);
          gradient.splice(gradient.length, 0, ...hsv);
        }
        gradient.push(this.stops[this.stops.length - 1].color);
        return gradient;
      }
      /**
       * Generate CSS3 command (no prefix) for this gradient
       * @param {String} [mode=linear] - 'linear' or 'radial'
       * @param {String} [direction] - default is 'to right' or 'ellipse at center'
       * @return {String}
       */
      css(mode, direction) {
        mode = mode || "linear";
        direction = direction || (mode === "linear" ? "to right" : "ellipse at center");
        let css = mode + "-gradient(" + direction;
        this.stops.forEach(function(stop) {
          css += ", " + (stop.colorLess ? "" : stop.color.toRgbString() + " ") + stop.pos * 100 + "%";
        });
        css += ")";
        return css;
      }
      /**
       * Returns the color at specific position with RGBa interpolation
       * @param {number} pos, between 0 and 1
       * @return {tinycolor}
       */
      rgbAt(pos) {
        return computeAt(this.stops, pos, "toRgb", RGBA_MAX);
      }
      /**
       * Returns the color at specific position with HSVa interpolation
       * @param {number} pos, between 0 and 1
       * @return {tinycolor}
       */
      hsvAt(pos) {
        return computeAt(this.stops, pos, "toHsv", HSVA_MAX);
      }
    };
    module.exports = function(stops) {
      if (arguments.length === 1) {
        if (!Array.isArray(arguments[0])) {
          throw new Error('"stops" is not an array');
        }
        stops = arguments[0];
      } else {
        stops = Array.prototype.slice.call(arguments);
      }
      return new TinyGradient(stops);
    };
  }
});

// node_modules/esprima/dist/esprima.js
var require_esprima = __commonJS({
  "node_modules/esprima/dist/esprima.js"(exports, module) {
    (function webpackUniversalModuleDefinition(root, factory) {
      if (typeof exports === "object" && typeof module === "object")
        module.exports = factory();
      else if (typeof define === "function" && define.amd)
        define([], factory);
      else if (typeof exports === "object")
        exports["esprima"] = factory();
      else
        root["esprima"] = factory();
    })(exports, function() {
      return (
        /******/
        (function(modules) {
          var installedModules = {};
          function __webpack_require__(moduleId) {
            if (installedModules[moduleId])
              return installedModules[moduleId].exports;
            var module2 = installedModules[moduleId] = {
              /******/
              exports: {},
              /******/
              id: moduleId,
              /******/
              loaded: false
              /******/
            };
            modules[moduleId].call(module2.exports, module2, module2.exports, __webpack_require__);
            module2.loaded = true;
            return module2.exports;
          }
          __webpack_require__.m = modules;
          __webpack_require__.c = installedModules;
          __webpack_require__.p = "";
          return __webpack_require__(0);
        })([
          /* 0 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var comment_handler_1 = __webpack_require__(1);
            var jsx_parser_1 = __webpack_require__(3);
            var parser_1 = __webpack_require__(8);
            var tokenizer_1 = __webpack_require__(15);
            function parse3(code, options, delegate) {
              var commentHandler = null;
              var proxyDelegate = function(node, metadata) {
                if (delegate) {
                  delegate(node, metadata);
                }
                if (commentHandler) {
                  commentHandler.visit(node, metadata);
                }
              };
              var parserDelegate = typeof delegate === "function" ? proxyDelegate : null;
              var collectComment = false;
              if (options) {
                collectComment = typeof options.comment === "boolean" && options.comment;
                var attachComment = typeof options.attachComment === "boolean" && options.attachComment;
                if (collectComment || attachComment) {
                  commentHandler = new comment_handler_1.CommentHandler();
                  commentHandler.attach = attachComment;
                  options.comment = true;
                  parserDelegate = proxyDelegate;
                }
              }
              var isModule = false;
              if (options && typeof options.sourceType === "string") {
                isModule = options.sourceType === "module";
              }
              var parser;
              if (options && typeof options.jsx === "boolean" && options.jsx) {
                parser = new jsx_parser_1.JSXParser(code, options, parserDelegate);
              } else {
                parser = new parser_1.Parser(code, options, parserDelegate);
              }
              var program = isModule ? parser.parseModule() : parser.parseScript();
              var ast = program;
              if (collectComment && commentHandler) {
                ast.comments = commentHandler.comments;
              }
              if (parser.config.tokens) {
                ast.tokens = parser.tokens;
              }
              if (parser.config.tolerant) {
                ast.errors = parser.errorHandler.errors;
              }
              return ast;
            }
            exports2.parse = parse3;
            function parseModule(code, options, delegate) {
              var parsingOptions = options || {};
              parsingOptions.sourceType = "module";
              return parse3(code, parsingOptions, delegate);
            }
            exports2.parseModule = parseModule;
            function parseScript(code, options, delegate) {
              var parsingOptions = options || {};
              parsingOptions.sourceType = "script";
              return parse3(code, parsingOptions, delegate);
            }
            exports2.parseScript = parseScript;
            function tokenize(code, options, delegate) {
              var tokenizer = new tokenizer_1.Tokenizer(code, options);
              var tokens;
              tokens = [];
              try {
                while (true) {
                  var token = tokenizer.getNextToken();
                  if (!token) {
                    break;
                  }
                  if (delegate) {
                    token = delegate(token);
                  }
                  tokens.push(token);
                }
              } catch (e) {
                tokenizer.errorHandler.tolerate(e);
              }
              if (tokenizer.errorHandler.tolerant) {
                tokens.errors = tokenizer.errors();
              }
              return tokens;
            }
            exports2.tokenize = tokenize;
            var syntax_1 = __webpack_require__(2);
            exports2.Syntax = syntax_1.Syntax;
            exports2.version = "4.0.1";
          },
          /* 1 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var syntax_1 = __webpack_require__(2);
            var CommentHandler = (function() {
              function CommentHandler2() {
                this.attach = false;
                this.comments = [];
                this.stack = [];
                this.leading = [];
                this.trailing = [];
              }
              CommentHandler2.prototype.insertInnerComments = function(node, metadata) {
                if (node.type === syntax_1.Syntax.BlockStatement && node.body.length === 0) {
                  var innerComments = [];
                  for (var i = this.leading.length - 1; i >= 0; --i) {
                    var entry = this.leading[i];
                    if (metadata.end.offset >= entry.start) {
                      innerComments.unshift(entry.comment);
                      this.leading.splice(i, 1);
                      this.trailing.splice(i, 1);
                    }
                  }
                  if (innerComments.length) {
                    node.innerComments = innerComments;
                  }
                }
              };
              CommentHandler2.prototype.findTrailingComments = function(metadata) {
                var trailingComments = [];
                if (this.trailing.length > 0) {
                  for (var i = this.trailing.length - 1; i >= 0; --i) {
                    var entry_1 = this.trailing[i];
                    if (entry_1.start >= metadata.end.offset) {
                      trailingComments.unshift(entry_1.comment);
                    }
                  }
                  this.trailing.length = 0;
                  return trailingComments;
                }
                var entry = this.stack[this.stack.length - 1];
                if (entry && entry.node.trailingComments) {
                  var firstComment = entry.node.trailingComments[0];
                  if (firstComment && firstComment.range[0] >= metadata.end.offset) {
                    trailingComments = entry.node.trailingComments;
                    delete entry.node.trailingComments;
                  }
                }
                return trailingComments;
              };
              CommentHandler2.prototype.findLeadingComments = function(metadata) {
                var leadingComments = [];
                var target;
                while (this.stack.length > 0) {
                  var entry = this.stack[this.stack.length - 1];
                  if (entry && entry.start >= metadata.start.offset) {
                    target = entry.node;
                    this.stack.pop();
                  } else {
                    break;
                  }
                }
                if (target) {
                  var count = target.leadingComments ? target.leadingComments.length : 0;
                  for (var i = count - 1; i >= 0; --i) {
                    var comment = target.leadingComments[i];
                    if (comment.range[1] <= metadata.start.offset) {
                      leadingComments.unshift(comment);
                      target.leadingComments.splice(i, 1);
                    }
                  }
                  if (target.leadingComments && target.leadingComments.length === 0) {
                    delete target.leadingComments;
                  }
                  return leadingComments;
                }
                for (var i = this.leading.length - 1; i >= 0; --i) {
                  var entry = this.leading[i];
                  if (entry.start <= metadata.start.offset) {
                    leadingComments.unshift(entry.comment);
                    this.leading.splice(i, 1);
                  }
                }
                return leadingComments;
              };
              CommentHandler2.prototype.visitNode = function(node, metadata) {
                if (node.type === syntax_1.Syntax.Program && node.body.length > 0) {
                  return;
                }
                this.insertInnerComments(node, metadata);
                var trailingComments = this.findTrailingComments(metadata);
                var leadingComments = this.findLeadingComments(metadata);
                if (leadingComments.length > 0) {
                  node.leadingComments = leadingComments;
                }
                if (trailingComments.length > 0) {
                  node.trailingComments = trailingComments;
                }
                this.stack.push({
                  node,
                  start: metadata.start.offset
                });
              };
              CommentHandler2.prototype.visitComment = function(node, metadata) {
                var type = node.type[0] === "L" ? "Line" : "Block";
                var comment = {
                  type,
                  value: node.value
                };
                if (node.range) {
                  comment.range = node.range;
                }
                if (node.loc) {
                  comment.loc = node.loc;
                }
                this.comments.push(comment);
                if (this.attach) {
                  var entry = {
                    comment: {
                      type,
                      value: node.value,
                      range: [metadata.start.offset, metadata.end.offset]
                    },
                    start: metadata.start.offset
                  };
                  if (node.loc) {
                    entry.comment.loc = node.loc;
                  }
                  node.type = type;
                  this.leading.push(entry);
                  this.trailing.push(entry);
                }
              };
              CommentHandler2.prototype.visit = function(node, metadata) {
                if (node.type === "LineComment") {
                  this.visitComment(node, metadata);
                } else if (node.type === "BlockComment") {
                  this.visitComment(node, metadata);
                } else if (this.attach) {
                  this.visitNode(node, metadata);
                }
              };
              return CommentHandler2;
            })();
            exports2.CommentHandler = CommentHandler;
          },
          /* 2 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            exports2.Syntax = {
              AssignmentExpression: "AssignmentExpression",
              AssignmentPattern: "AssignmentPattern",
              ArrayExpression: "ArrayExpression",
              ArrayPattern: "ArrayPattern",
              ArrowFunctionExpression: "ArrowFunctionExpression",
              AwaitExpression: "AwaitExpression",
              BlockStatement: "BlockStatement",
              BinaryExpression: "BinaryExpression",
              BreakStatement: "BreakStatement",
              CallExpression: "CallExpression",
              CatchClause: "CatchClause",
              ClassBody: "ClassBody",
              ClassDeclaration: "ClassDeclaration",
              ClassExpression: "ClassExpression",
              ConditionalExpression: "ConditionalExpression",
              ContinueStatement: "ContinueStatement",
              DoWhileStatement: "DoWhileStatement",
              DebuggerStatement: "DebuggerStatement",
              EmptyStatement: "EmptyStatement",
              ExportAllDeclaration: "ExportAllDeclaration",
              ExportDefaultDeclaration: "ExportDefaultDeclaration",
              ExportNamedDeclaration: "ExportNamedDeclaration",
              ExportSpecifier: "ExportSpecifier",
              ExpressionStatement: "ExpressionStatement",
              ForStatement: "ForStatement",
              ForOfStatement: "ForOfStatement",
              ForInStatement: "ForInStatement",
              FunctionDeclaration: "FunctionDeclaration",
              FunctionExpression: "FunctionExpression",
              Identifier: "Identifier",
              IfStatement: "IfStatement",
              ImportDeclaration: "ImportDeclaration",
              ImportDefaultSpecifier: "ImportDefaultSpecifier",
              ImportNamespaceSpecifier: "ImportNamespaceSpecifier",
              ImportSpecifier: "ImportSpecifier",
              Literal: "Literal",
              LabeledStatement: "LabeledStatement",
              LogicalExpression: "LogicalExpression",
              MemberExpression: "MemberExpression",
              MetaProperty: "MetaProperty",
              MethodDefinition: "MethodDefinition",
              NewExpression: "NewExpression",
              ObjectExpression: "ObjectExpression",
              ObjectPattern: "ObjectPattern",
              Program: "Program",
              Property: "Property",
              RestElement: "RestElement",
              ReturnStatement: "ReturnStatement",
              SequenceExpression: "SequenceExpression",
              SpreadElement: "SpreadElement",
              Super: "Super",
              SwitchCase: "SwitchCase",
              SwitchStatement: "SwitchStatement",
              TaggedTemplateExpression: "TaggedTemplateExpression",
              TemplateElement: "TemplateElement",
              TemplateLiteral: "TemplateLiteral",
              ThisExpression: "ThisExpression",
              ThrowStatement: "ThrowStatement",
              TryStatement: "TryStatement",
              UnaryExpression: "UnaryExpression",
              UpdateExpression: "UpdateExpression",
              VariableDeclaration: "VariableDeclaration",
              VariableDeclarator: "VariableDeclarator",
              WhileStatement: "WhileStatement",
              WithStatement: "WithStatement",
              YieldExpression: "YieldExpression"
            };
          },
          /* 3 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            var __extends = this && this.__extends || (function() {
              var extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
                d.__proto__ = b;
              } || function(d, b) {
                for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
              };
              return function(d, b) {
                extendStatics(d, b);
                function __() {
                  this.constructor = d;
                }
                d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
              };
            })();
            Object.defineProperty(exports2, "__esModule", { value: true });
            var character_1 = __webpack_require__(4);
            var JSXNode = __webpack_require__(5);
            var jsx_syntax_1 = __webpack_require__(6);
            var Node = __webpack_require__(7);
            var parser_1 = __webpack_require__(8);
            var token_1 = __webpack_require__(13);
            var xhtml_entities_1 = __webpack_require__(14);
            token_1.TokenName[
              100
              /* Identifier */
            ] = "JSXIdentifier";
            token_1.TokenName[
              101
              /* Text */
            ] = "JSXText";
            function getQualifiedElementName(elementName) {
              var qualifiedName;
              switch (elementName.type) {
                case jsx_syntax_1.JSXSyntax.JSXIdentifier:
                  var id = elementName;
                  qualifiedName = id.name;
                  break;
                case jsx_syntax_1.JSXSyntax.JSXNamespacedName:
                  var ns = elementName;
                  qualifiedName = getQualifiedElementName(ns.namespace) + ":" + getQualifiedElementName(ns.name);
                  break;
                case jsx_syntax_1.JSXSyntax.JSXMemberExpression:
                  var expr = elementName;
                  qualifiedName = getQualifiedElementName(expr.object) + "." + getQualifiedElementName(expr.property);
                  break;
                /* istanbul ignore next */
                default:
                  break;
              }
              return qualifiedName;
            }
            var JSXParser = (function(_super) {
              __extends(JSXParser2, _super);
              function JSXParser2(code, options, delegate) {
                return _super.call(this, code, options, delegate) || this;
              }
              JSXParser2.prototype.parsePrimaryExpression = function() {
                return this.match("<") ? this.parseJSXRoot() : _super.prototype.parsePrimaryExpression.call(this);
              };
              JSXParser2.prototype.startJSX = function() {
                this.scanner.index = this.startMarker.index;
                this.scanner.lineNumber = this.startMarker.line;
                this.scanner.lineStart = this.startMarker.index - this.startMarker.column;
              };
              JSXParser2.prototype.finishJSX = function() {
                this.nextToken();
              };
              JSXParser2.prototype.reenterJSX = function() {
                this.startJSX();
                this.expectJSX("}");
                if (this.config.tokens) {
                  this.tokens.pop();
                }
              };
              JSXParser2.prototype.createJSXNode = function() {
                this.collectComments();
                return {
                  index: this.scanner.index,
                  line: this.scanner.lineNumber,
                  column: this.scanner.index - this.scanner.lineStart
                };
              };
              JSXParser2.prototype.createJSXChildNode = function() {
                return {
                  index: this.scanner.index,
                  line: this.scanner.lineNumber,
                  column: this.scanner.index - this.scanner.lineStart
                };
              };
              JSXParser2.prototype.scanXHTMLEntity = function(quote) {
                var result = "&";
                var valid = true;
                var terminated = false;
                var numeric = false;
                var hex = false;
                while (!this.scanner.eof() && valid && !terminated) {
                  var ch = this.scanner.source[this.scanner.index];
                  if (ch === quote) {
                    break;
                  }
                  terminated = ch === ";";
                  result += ch;
                  ++this.scanner.index;
                  if (!terminated) {
                    switch (result.length) {
                      case 2:
                        numeric = ch === "#";
                        break;
                      case 3:
                        if (numeric) {
                          hex = ch === "x";
                          valid = hex || character_1.Character.isDecimalDigit(ch.charCodeAt(0));
                          numeric = numeric && !hex;
                        }
                        break;
                      default:
                        valid = valid && !(numeric && !character_1.Character.isDecimalDigit(ch.charCodeAt(0)));
                        valid = valid && !(hex && !character_1.Character.isHexDigit(ch.charCodeAt(0)));
                        break;
                    }
                  }
                }
                if (valid && terminated && result.length > 2) {
                  var str = result.substr(1, result.length - 2);
                  if (numeric && str.length > 1) {
                    result = String.fromCharCode(parseInt(str.substr(1), 10));
                  } else if (hex && str.length > 2) {
                    result = String.fromCharCode(parseInt("0" + str.substr(1), 16));
                  } else if (!numeric && !hex && xhtml_entities_1.XHTMLEntities[str]) {
                    result = xhtml_entities_1.XHTMLEntities[str];
                  }
                }
                return result;
              };
              JSXParser2.prototype.lexJSX = function() {
                var cp = this.scanner.source.charCodeAt(this.scanner.index);
                if (cp === 60 || cp === 62 || cp === 47 || cp === 58 || cp === 61 || cp === 123 || cp === 125) {
                  var value = this.scanner.source[this.scanner.index++];
                  return {
                    type: 7,
                    value,
                    lineNumber: this.scanner.lineNumber,
                    lineStart: this.scanner.lineStart,
                    start: this.scanner.index - 1,
                    end: this.scanner.index
                  };
                }
                if (cp === 34 || cp === 39) {
                  var start = this.scanner.index;
                  var quote = this.scanner.source[this.scanner.index++];
                  var str = "";
                  while (!this.scanner.eof()) {
                    var ch = this.scanner.source[this.scanner.index++];
                    if (ch === quote) {
                      break;
                    } else if (ch === "&") {
                      str += this.scanXHTMLEntity(quote);
                    } else {
                      str += ch;
                    }
                  }
                  return {
                    type: 8,
                    value: str,
                    lineNumber: this.scanner.lineNumber,
                    lineStart: this.scanner.lineStart,
                    start,
                    end: this.scanner.index
                  };
                }
                if (cp === 46) {
                  var n1 = this.scanner.source.charCodeAt(this.scanner.index + 1);
                  var n2 = this.scanner.source.charCodeAt(this.scanner.index + 2);
                  var value = n1 === 46 && n2 === 46 ? "..." : ".";
                  var start = this.scanner.index;
                  this.scanner.index += value.length;
                  return {
                    type: 7,
                    value,
                    lineNumber: this.scanner.lineNumber,
                    lineStart: this.scanner.lineStart,
                    start,
                    end: this.scanner.index
                  };
                }
                if (cp === 96) {
                  return {
                    type: 10,
                    value: "",
                    lineNumber: this.scanner.lineNumber,
                    lineStart: this.scanner.lineStart,
                    start: this.scanner.index,
                    end: this.scanner.index
                  };
                }
                if (character_1.Character.isIdentifierStart(cp) && cp !== 92) {
                  var start = this.scanner.index;
                  ++this.scanner.index;
                  while (!this.scanner.eof()) {
                    var ch = this.scanner.source.charCodeAt(this.scanner.index);
                    if (character_1.Character.isIdentifierPart(ch) && ch !== 92) {
                      ++this.scanner.index;
                    } else if (ch === 45) {
                      ++this.scanner.index;
                    } else {
                      break;
                    }
                  }
                  var id = this.scanner.source.slice(start, this.scanner.index);
                  return {
                    type: 100,
                    value: id,
                    lineNumber: this.scanner.lineNumber,
                    lineStart: this.scanner.lineStart,
                    start,
                    end: this.scanner.index
                  };
                }
                return this.scanner.lex();
              };
              JSXParser2.prototype.nextJSXToken = function() {
                this.collectComments();
                this.startMarker.index = this.scanner.index;
                this.startMarker.line = this.scanner.lineNumber;
                this.startMarker.column = this.scanner.index - this.scanner.lineStart;
                var token = this.lexJSX();
                this.lastMarker.index = this.scanner.index;
                this.lastMarker.line = this.scanner.lineNumber;
                this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
                if (this.config.tokens) {
                  this.tokens.push(this.convertToken(token));
                }
                return token;
              };
              JSXParser2.prototype.nextJSXText = function() {
                this.startMarker.index = this.scanner.index;
                this.startMarker.line = this.scanner.lineNumber;
                this.startMarker.column = this.scanner.index - this.scanner.lineStart;
                var start = this.scanner.index;
                var text = "";
                while (!this.scanner.eof()) {
                  var ch = this.scanner.source[this.scanner.index];
                  if (ch === "{" || ch === "<") {
                    break;
                  }
                  ++this.scanner.index;
                  text += ch;
                  if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                    ++this.scanner.lineNumber;
                    if (ch === "\r" && this.scanner.source[this.scanner.index] === "\n") {
                      ++this.scanner.index;
                    }
                    this.scanner.lineStart = this.scanner.index;
                  }
                }
                this.lastMarker.index = this.scanner.index;
                this.lastMarker.line = this.scanner.lineNumber;
                this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
                var token = {
                  type: 101,
                  value: text,
                  lineNumber: this.scanner.lineNumber,
                  lineStart: this.scanner.lineStart,
                  start,
                  end: this.scanner.index
                };
                if (text.length > 0 && this.config.tokens) {
                  this.tokens.push(this.convertToken(token));
                }
                return token;
              };
              JSXParser2.prototype.peekJSXToken = function() {
                var state = this.scanner.saveState();
                this.scanner.scanComments();
                var next = this.lexJSX();
                this.scanner.restoreState(state);
                return next;
              };
              JSXParser2.prototype.expectJSX = function(value) {
                var token = this.nextJSXToken();
                if (token.type !== 7 || token.value !== value) {
                  this.throwUnexpectedToken(token);
                }
              };
              JSXParser2.prototype.matchJSX = function(value) {
                var next = this.peekJSXToken();
                return next.type === 7 && next.value === value;
              };
              JSXParser2.prototype.parseJSXIdentifier = function() {
                var node = this.createJSXNode();
                var token = this.nextJSXToken();
                if (token.type !== 100) {
                  this.throwUnexpectedToken(token);
                }
                return this.finalize(node, new JSXNode.JSXIdentifier(token.value));
              };
              JSXParser2.prototype.parseJSXElementName = function() {
                var node = this.createJSXNode();
                var elementName = this.parseJSXIdentifier();
                if (this.matchJSX(":")) {
                  var namespace = elementName;
                  this.expectJSX(":");
                  var name_1 = this.parseJSXIdentifier();
                  elementName = this.finalize(node, new JSXNode.JSXNamespacedName(namespace, name_1));
                } else if (this.matchJSX(".")) {
                  while (this.matchJSX(".")) {
                    var object = elementName;
                    this.expectJSX(".");
                    var property = this.parseJSXIdentifier();
                    elementName = this.finalize(node, new JSXNode.JSXMemberExpression(object, property));
                  }
                }
                return elementName;
              };
              JSXParser2.prototype.parseJSXAttributeName = function() {
                var node = this.createJSXNode();
                var attributeName;
                var identifier = this.parseJSXIdentifier();
                if (this.matchJSX(":")) {
                  var namespace = identifier;
                  this.expectJSX(":");
                  var name_2 = this.parseJSXIdentifier();
                  attributeName = this.finalize(node, new JSXNode.JSXNamespacedName(namespace, name_2));
                } else {
                  attributeName = identifier;
                }
                return attributeName;
              };
              JSXParser2.prototype.parseJSXStringLiteralAttribute = function() {
                var node = this.createJSXNode();
                var token = this.nextJSXToken();
                if (token.type !== 8) {
                  this.throwUnexpectedToken(token);
                }
                var raw = this.getTokenRaw(token);
                return this.finalize(node, new Node.Literal(token.value, raw));
              };
              JSXParser2.prototype.parseJSXExpressionAttribute = function() {
                var node = this.createJSXNode();
                this.expectJSX("{");
                this.finishJSX();
                if (this.match("}")) {
                  this.tolerateError("JSX attributes must only be assigned a non-empty expression");
                }
                var expression = this.parseAssignmentExpression();
                this.reenterJSX();
                return this.finalize(node, new JSXNode.JSXExpressionContainer(expression));
              };
              JSXParser2.prototype.parseJSXAttributeValue = function() {
                return this.matchJSX("{") ? this.parseJSXExpressionAttribute() : this.matchJSX("<") ? this.parseJSXElement() : this.parseJSXStringLiteralAttribute();
              };
              JSXParser2.prototype.parseJSXNameValueAttribute = function() {
                var node = this.createJSXNode();
                var name = this.parseJSXAttributeName();
                var value = null;
                if (this.matchJSX("=")) {
                  this.expectJSX("=");
                  value = this.parseJSXAttributeValue();
                }
                return this.finalize(node, new JSXNode.JSXAttribute(name, value));
              };
              JSXParser2.prototype.parseJSXSpreadAttribute = function() {
                var node = this.createJSXNode();
                this.expectJSX("{");
                this.expectJSX("...");
                this.finishJSX();
                var argument = this.parseAssignmentExpression();
                this.reenterJSX();
                return this.finalize(node, new JSXNode.JSXSpreadAttribute(argument));
              };
              JSXParser2.prototype.parseJSXAttributes = function() {
                var attributes = [];
                while (!this.matchJSX("/") && !this.matchJSX(">")) {
                  var attribute = this.matchJSX("{") ? this.parseJSXSpreadAttribute() : this.parseJSXNameValueAttribute();
                  attributes.push(attribute);
                }
                return attributes;
              };
              JSXParser2.prototype.parseJSXOpeningElement = function() {
                var node = this.createJSXNode();
                this.expectJSX("<");
                var name = this.parseJSXElementName();
                var attributes = this.parseJSXAttributes();
                var selfClosing = this.matchJSX("/");
                if (selfClosing) {
                  this.expectJSX("/");
                }
                this.expectJSX(">");
                return this.finalize(node, new JSXNode.JSXOpeningElement(name, selfClosing, attributes));
              };
              JSXParser2.prototype.parseJSXBoundaryElement = function() {
                var node = this.createJSXNode();
                this.expectJSX("<");
                if (this.matchJSX("/")) {
                  this.expectJSX("/");
                  var name_3 = this.parseJSXElementName();
                  this.expectJSX(">");
                  return this.finalize(node, new JSXNode.JSXClosingElement(name_3));
                }
                var name = this.parseJSXElementName();
                var attributes = this.parseJSXAttributes();
                var selfClosing = this.matchJSX("/");
                if (selfClosing) {
                  this.expectJSX("/");
                }
                this.expectJSX(">");
                return this.finalize(node, new JSXNode.JSXOpeningElement(name, selfClosing, attributes));
              };
              JSXParser2.prototype.parseJSXEmptyExpression = function() {
                var node = this.createJSXChildNode();
                this.collectComments();
                this.lastMarker.index = this.scanner.index;
                this.lastMarker.line = this.scanner.lineNumber;
                this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
                return this.finalize(node, new JSXNode.JSXEmptyExpression());
              };
              JSXParser2.prototype.parseJSXExpressionContainer = function() {
                var node = this.createJSXNode();
                this.expectJSX("{");
                var expression;
                if (this.matchJSX("}")) {
                  expression = this.parseJSXEmptyExpression();
                  this.expectJSX("}");
                } else {
                  this.finishJSX();
                  expression = this.parseAssignmentExpression();
                  this.reenterJSX();
                }
                return this.finalize(node, new JSXNode.JSXExpressionContainer(expression));
              };
              JSXParser2.prototype.parseJSXChildren = function() {
                var children = [];
                while (!this.scanner.eof()) {
                  var node = this.createJSXChildNode();
                  var token = this.nextJSXText();
                  if (token.start < token.end) {
                    var raw = this.getTokenRaw(token);
                    var child = this.finalize(node, new JSXNode.JSXText(token.value, raw));
                    children.push(child);
                  }
                  if (this.scanner.source[this.scanner.index] === "{") {
                    var container = this.parseJSXExpressionContainer();
                    children.push(container);
                  } else {
                    break;
                  }
                }
                return children;
              };
              JSXParser2.prototype.parseComplexJSXElement = function(el) {
                var stack = [];
                while (!this.scanner.eof()) {
                  el.children = el.children.concat(this.parseJSXChildren());
                  var node = this.createJSXChildNode();
                  var element = this.parseJSXBoundaryElement();
                  if (element.type === jsx_syntax_1.JSXSyntax.JSXOpeningElement) {
                    var opening = element;
                    if (opening.selfClosing) {
                      var child = this.finalize(node, new JSXNode.JSXElement(opening, [], null));
                      el.children.push(child);
                    } else {
                      stack.push(el);
                      el = { node, opening, closing: null, children: [] };
                    }
                  }
                  if (element.type === jsx_syntax_1.JSXSyntax.JSXClosingElement) {
                    el.closing = element;
                    var open_1 = getQualifiedElementName(el.opening.name);
                    var close_1 = getQualifiedElementName(el.closing.name);
                    if (open_1 !== close_1) {
                      this.tolerateError("Expected corresponding JSX closing tag for %0", open_1);
                    }
                    if (stack.length > 0) {
                      var child = this.finalize(el.node, new JSXNode.JSXElement(el.opening, el.children, el.closing));
                      el = stack[stack.length - 1];
                      el.children.push(child);
                      stack.pop();
                    } else {
                      break;
                    }
                  }
                }
                return el;
              };
              JSXParser2.prototype.parseJSXElement = function() {
                var node = this.createJSXNode();
                var opening = this.parseJSXOpeningElement();
                var children = [];
                var closing = null;
                if (!opening.selfClosing) {
                  var el = this.parseComplexJSXElement({ node, opening, closing, children });
                  children = el.children;
                  closing = el.closing;
                }
                return this.finalize(node, new JSXNode.JSXElement(opening, children, closing));
              };
              JSXParser2.prototype.parseJSXRoot = function() {
                if (this.config.tokens) {
                  this.tokens.pop();
                }
                this.startJSX();
                var element = this.parseJSXElement();
                this.finishJSX();
                return element;
              };
              JSXParser2.prototype.isStartOfExpression = function() {
                return _super.prototype.isStartOfExpression.call(this) || this.match("<");
              };
              return JSXParser2;
            })(parser_1.Parser);
            exports2.JSXParser = JSXParser;
          },
          /* 4 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var Regex = {
              // Unicode v8.0.0 NonAsciiIdentifierStart:
              NonAsciiIdentifierStart: /[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0-\u08B4\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]/,
              // Unicode v8.0.0 NonAsciiIdentifierPart:
              NonAsciiIdentifierPart: /[\xAA\xB5\xB7\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u08A0-\u08B4\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D01-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1369-\u1371\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1CD0-\u1CD2\u1CD4-\u1CF6\u1CF8\u1CF9\u1D00-\u1DF5\u1DFC-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C4\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/
            };
            exports2.Character = {
              /* tslint:disable:no-bitwise */
              fromCodePoint: function(cp) {
                return cp < 65536 ? String.fromCharCode(cp) : String.fromCharCode(55296 + (cp - 65536 >> 10)) + String.fromCharCode(56320 + (cp - 65536 & 1023));
              },
              // https://tc39.github.io/ecma262/#sec-white-space
              isWhiteSpace: function(cp) {
                return cp === 32 || cp === 9 || cp === 11 || cp === 12 || cp === 160 || cp >= 5760 && [5760, 8192, 8193, 8194, 8195, 8196, 8197, 8198, 8199, 8200, 8201, 8202, 8239, 8287, 12288, 65279].indexOf(cp) >= 0;
              },
              // https://tc39.github.io/ecma262/#sec-line-terminators
              isLineTerminator: function(cp) {
                return cp === 10 || cp === 13 || cp === 8232 || cp === 8233;
              },
              // https://tc39.github.io/ecma262/#sec-names-and-keywords
              isIdentifierStart: function(cp) {
                return cp === 36 || cp === 95 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp === 92 || cp >= 128 && Regex.NonAsciiIdentifierStart.test(exports2.Character.fromCodePoint(cp));
              },
              isIdentifierPart: function(cp) {
                return cp === 36 || cp === 95 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp >= 48 && cp <= 57 || cp === 92 || cp >= 128 && Regex.NonAsciiIdentifierPart.test(exports2.Character.fromCodePoint(cp));
              },
              // https://tc39.github.io/ecma262/#sec-literals-numeric-literals
              isDecimalDigit: function(cp) {
                return cp >= 48 && cp <= 57;
              },
              isHexDigit: function(cp) {
                return cp >= 48 && cp <= 57 || cp >= 65 && cp <= 70 || cp >= 97 && cp <= 102;
              },
              isOctalDigit: function(cp) {
                return cp >= 48 && cp <= 55;
              }
            };
          },
          /* 5 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var jsx_syntax_1 = __webpack_require__(6);
            var JSXClosingElement = /* @__PURE__ */ (function() {
              function JSXClosingElement2(name) {
                this.type = jsx_syntax_1.JSXSyntax.JSXClosingElement;
                this.name = name;
              }
              return JSXClosingElement2;
            })();
            exports2.JSXClosingElement = JSXClosingElement;
            var JSXElement = /* @__PURE__ */ (function() {
              function JSXElement2(openingElement, children, closingElement) {
                this.type = jsx_syntax_1.JSXSyntax.JSXElement;
                this.openingElement = openingElement;
                this.children = children;
                this.closingElement = closingElement;
              }
              return JSXElement2;
            })();
            exports2.JSXElement = JSXElement;
            var JSXEmptyExpression = /* @__PURE__ */ (function() {
              function JSXEmptyExpression2() {
                this.type = jsx_syntax_1.JSXSyntax.JSXEmptyExpression;
              }
              return JSXEmptyExpression2;
            })();
            exports2.JSXEmptyExpression = JSXEmptyExpression;
            var JSXExpressionContainer = /* @__PURE__ */ (function() {
              function JSXExpressionContainer2(expression) {
                this.type = jsx_syntax_1.JSXSyntax.JSXExpressionContainer;
                this.expression = expression;
              }
              return JSXExpressionContainer2;
            })();
            exports2.JSXExpressionContainer = JSXExpressionContainer;
            var JSXIdentifier = /* @__PURE__ */ (function() {
              function JSXIdentifier2(name) {
                this.type = jsx_syntax_1.JSXSyntax.JSXIdentifier;
                this.name = name;
              }
              return JSXIdentifier2;
            })();
            exports2.JSXIdentifier = JSXIdentifier;
            var JSXMemberExpression = /* @__PURE__ */ (function() {
              function JSXMemberExpression2(object, property) {
                this.type = jsx_syntax_1.JSXSyntax.JSXMemberExpression;
                this.object = object;
                this.property = property;
              }
              return JSXMemberExpression2;
            })();
            exports2.JSXMemberExpression = JSXMemberExpression;
            var JSXAttribute = /* @__PURE__ */ (function() {
              function JSXAttribute2(name, value) {
                this.type = jsx_syntax_1.JSXSyntax.JSXAttribute;
                this.name = name;
                this.value = value;
              }
              return JSXAttribute2;
            })();
            exports2.JSXAttribute = JSXAttribute;
            var JSXNamespacedName = /* @__PURE__ */ (function() {
              function JSXNamespacedName2(namespace, name) {
                this.type = jsx_syntax_1.JSXSyntax.JSXNamespacedName;
                this.namespace = namespace;
                this.name = name;
              }
              return JSXNamespacedName2;
            })();
            exports2.JSXNamespacedName = JSXNamespacedName;
            var JSXOpeningElement = /* @__PURE__ */ (function() {
              function JSXOpeningElement2(name, selfClosing, attributes) {
                this.type = jsx_syntax_1.JSXSyntax.JSXOpeningElement;
                this.name = name;
                this.selfClosing = selfClosing;
                this.attributes = attributes;
              }
              return JSXOpeningElement2;
            })();
            exports2.JSXOpeningElement = JSXOpeningElement;
            var JSXSpreadAttribute = /* @__PURE__ */ (function() {
              function JSXSpreadAttribute2(argument) {
                this.type = jsx_syntax_1.JSXSyntax.JSXSpreadAttribute;
                this.argument = argument;
              }
              return JSXSpreadAttribute2;
            })();
            exports2.JSXSpreadAttribute = JSXSpreadAttribute;
            var JSXText = /* @__PURE__ */ (function() {
              function JSXText2(value, raw) {
                this.type = jsx_syntax_1.JSXSyntax.JSXText;
                this.value = value;
                this.raw = raw;
              }
              return JSXText2;
            })();
            exports2.JSXText = JSXText;
          },
          /* 6 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            exports2.JSXSyntax = {
              JSXAttribute: "JSXAttribute",
              JSXClosingElement: "JSXClosingElement",
              JSXElement: "JSXElement",
              JSXEmptyExpression: "JSXEmptyExpression",
              JSXExpressionContainer: "JSXExpressionContainer",
              JSXIdentifier: "JSXIdentifier",
              JSXMemberExpression: "JSXMemberExpression",
              JSXNamespacedName: "JSXNamespacedName",
              JSXOpeningElement: "JSXOpeningElement",
              JSXSpreadAttribute: "JSXSpreadAttribute",
              JSXText: "JSXText"
            };
          },
          /* 7 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var syntax_1 = __webpack_require__(2);
            var ArrayExpression = /* @__PURE__ */ (function() {
              function ArrayExpression2(elements) {
                this.type = syntax_1.Syntax.ArrayExpression;
                this.elements = elements;
              }
              return ArrayExpression2;
            })();
            exports2.ArrayExpression = ArrayExpression;
            var ArrayPattern = /* @__PURE__ */ (function() {
              function ArrayPattern2(elements) {
                this.type = syntax_1.Syntax.ArrayPattern;
                this.elements = elements;
              }
              return ArrayPattern2;
            })();
            exports2.ArrayPattern = ArrayPattern;
            var ArrowFunctionExpression = /* @__PURE__ */ (function() {
              function ArrowFunctionExpression2(params, body, expression) {
                this.type = syntax_1.Syntax.ArrowFunctionExpression;
                this.id = null;
                this.params = params;
                this.body = body;
                this.generator = false;
                this.expression = expression;
                this.async = false;
              }
              return ArrowFunctionExpression2;
            })();
            exports2.ArrowFunctionExpression = ArrowFunctionExpression;
            var AssignmentExpression = /* @__PURE__ */ (function() {
              function AssignmentExpression2(operator, left, right) {
                this.type = syntax_1.Syntax.AssignmentExpression;
                this.operator = operator;
                this.left = left;
                this.right = right;
              }
              return AssignmentExpression2;
            })();
            exports2.AssignmentExpression = AssignmentExpression;
            var AssignmentPattern = /* @__PURE__ */ (function() {
              function AssignmentPattern2(left, right) {
                this.type = syntax_1.Syntax.AssignmentPattern;
                this.left = left;
                this.right = right;
              }
              return AssignmentPattern2;
            })();
            exports2.AssignmentPattern = AssignmentPattern;
            var AsyncArrowFunctionExpression = /* @__PURE__ */ (function() {
              function AsyncArrowFunctionExpression2(params, body, expression) {
                this.type = syntax_1.Syntax.ArrowFunctionExpression;
                this.id = null;
                this.params = params;
                this.body = body;
                this.generator = false;
                this.expression = expression;
                this.async = true;
              }
              return AsyncArrowFunctionExpression2;
            })();
            exports2.AsyncArrowFunctionExpression = AsyncArrowFunctionExpression;
            var AsyncFunctionDeclaration = /* @__PURE__ */ (function() {
              function AsyncFunctionDeclaration2(id, params, body) {
                this.type = syntax_1.Syntax.FunctionDeclaration;
                this.id = id;
                this.params = params;
                this.body = body;
                this.generator = false;
                this.expression = false;
                this.async = true;
              }
              return AsyncFunctionDeclaration2;
            })();
            exports2.AsyncFunctionDeclaration = AsyncFunctionDeclaration;
            var AsyncFunctionExpression = /* @__PURE__ */ (function() {
              function AsyncFunctionExpression2(id, params, body) {
                this.type = syntax_1.Syntax.FunctionExpression;
                this.id = id;
                this.params = params;
                this.body = body;
                this.generator = false;
                this.expression = false;
                this.async = true;
              }
              return AsyncFunctionExpression2;
            })();
            exports2.AsyncFunctionExpression = AsyncFunctionExpression;
            var AwaitExpression = /* @__PURE__ */ (function() {
              function AwaitExpression2(argument) {
                this.type = syntax_1.Syntax.AwaitExpression;
                this.argument = argument;
              }
              return AwaitExpression2;
            })();
            exports2.AwaitExpression = AwaitExpression;
            var BinaryExpression = /* @__PURE__ */ (function() {
              function BinaryExpression2(operator, left, right) {
                var logical = operator === "||" || operator === "&&";
                this.type = logical ? syntax_1.Syntax.LogicalExpression : syntax_1.Syntax.BinaryExpression;
                this.operator = operator;
                this.left = left;
                this.right = right;
              }
              return BinaryExpression2;
            })();
            exports2.BinaryExpression = BinaryExpression;
            var BlockStatement = /* @__PURE__ */ (function() {
              function BlockStatement2(body) {
                this.type = syntax_1.Syntax.BlockStatement;
                this.body = body;
              }
              return BlockStatement2;
            })();
            exports2.BlockStatement = BlockStatement;
            var BreakStatement = /* @__PURE__ */ (function() {
              function BreakStatement2(label) {
                this.type = syntax_1.Syntax.BreakStatement;
                this.label = label;
              }
              return BreakStatement2;
            })();
            exports2.BreakStatement = BreakStatement;
            var CallExpression = /* @__PURE__ */ (function() {
              function CallExpression2(callee, args) {
                this.type = syntax_1.Syntax.CallExpression;
                this.callee = callee;
                this.arguments = args;
              }
              return CallExpression2;
            })();
            exports2.CallExpression = CallExpression;
            var CatchClause = /* @__PURE__ */ (function() {
              function CatchClause2(param, body) {
                this.type = syntax_1.Syntax.CatchClause;
                this.param = param;
                this.body = body;
              }
              return CatchClause2;
            })();
            exports2.CatchClause = CatchClause;
            var ClassBody = /* @__PURE__ */ (function() {
              function ClassBody2(body) {
                this.type = syntax_1.Syntax.ClassBody;
                this.body = body;
              }
              return ClassBody2;
            })();
            exports2.ClassBody = ClassBody;
            var ClassDeclaration = /* @__PURE__ */ (function() {
              function ClassDeclaration2(id, superClass, body) {
                this.type = syntax_1.Syntax.ClassDeclaration;
                this.id = id;
                this.superClass = superClass;
                this.body = body;
              }
              return ClassDeclaration2;
            })();
            exports2.ClassDeclaration = ClassDeclaration;
            var ClassExpression = /* @__PURE__ */ (function() {
              function ClassExpression2(id, superClass, body) {
                this.type = syntax_1.Syntax.ClassExpression;
                this.id = id;
                this.superClass = superClass;
                this.body = body;
              }
              return ClassExpression2;
            })();
            exports2.ClassExpression = ClassExpression;
            var ComputedMemberExpression = /* @__PURE__ */ (function() {
              function ComputedMemberExpression2(object, property) {
                this.type = syntax_1.Syntax.MemberExpression;
                this.computed = true;
                this.object = object;
                this.property = property;
              }
              return ComputedMemberExpression2;
            })();
            exports2.ComputedMemberExpression = ComputedMemberExpression;
            var ConditionalExpression = /* @__PURE__ */ (function() {
              function ConditionalExpression2(test, consequent, alternate) {
                this.type = syntax_1.Syntax.ConditionalExpression;
                this.test = test;
                this.consequent = consequent;
                this.alternate = alternate;
              }
              return ConditionalExpression2;
            })();
            exports2.ConditionalExpression = ConditionalExpression;
            var ContinueStatement = /* @__PURE__ */ (function() {
              function ContinueStatement2(label) {
                this.type = syntax_1.Syntax.ContinueStatement;
                this.label = label;
              }
              return ContinueStatement2;
            })();
            exports2.ContinueStatement = ContinueStatement;
            var DebuggerStatement = /* @__PURE__ */ (function() {
              function DebuggerStatement2() {
                this.type = syntax_1.Syntax.DebuggerStatement;
              }
              return DebuggerStatement2;
            })();
            exports2.DebuggerStatement = DebuggerStatement;
            var Directive = /* @__PURE__ */ (function() {
              function Directive2(expression, directive) {
                this.type = syntax_1.Syntax.ExpressionStatement;
                this.expression = expression;
                this.directive = directive;
              }
              return Directive2;
            })();
            exports2.Directive = Directive;
            var DoWhileStatement = /* @__PURE__ */ (function() {
              function DoWhileStatement2(body, test) {
                this.type = syntax_1.Syntax.DoWhileStatement;
                this.body = body;
                this.test = test;
              }
              return DoWhileStatement2;
            })();
            exports2.DoWhileStatement = DoWhileStatement;
            var EmptyStatement = /* @__PURE__ */ (function() {
              function EmptyStatement2() {
                this.type = syntax_1.Syntax.EmptyStatement;
              }
              return EmptyStatement2;
            })();
            exports2.EmptyStatement = EmptyStatement;
            var ExportAllDeclaration = /* @__PURE__ */ (function() {
              function ExportAllDeclaration2(source) {
                this.type = syntax_1.Syntax.ExportAllDeclaration;
                this.source = source;
              }
              return ExportAllDeclaration2;
            })();
            exports2.ExportAllDeclaration = ExportAllDeclaration;
            var ExportDefaultDeclaration = /* @__PURE__ */ (function() {
              function ExportDefaultDeclaration2(declaration) {
                this.type = syntax_1.Syntax.ExportDefaultDeclaration;
                this.declaration = declaration;
              }
              return ExportDefaultDeclaration2;
            })();
            exports2.ExportDefaultDeclaration = ExportDefaultDeclaration;
            var ExportNamedDeclaration = /* @__PURE__ */ (function() {
              function ExportNamedDeclaration2(declaration, specifiers, source) {
                this.type = syntax_1.Syntax.ExportNamedDeclaration;
                this.declaration = declaration;
                this.specifiers = specifiers;
                this.source = source;
              }
              return ExportNamedDeclaration2;
            })();
            exports2.ExportNamedDeclaration = ExportNamedDeclaration;
            var ExportSpecifier = /* @__PURE__ */ (function() {
              function ExportSpecifier2(local, exported) {
                this.type = syntax_1.Syntax.ExportSpecifier;
                this.exported = exported;
                this.local = local;
              }
              return ExportSpecifier2;
            })();
            exports2.ExportSpecifier = ExportSpecifier;
            var ExpressionStatement = /* @__PURE__ */ (function() {
              function ExpressionStatement2(expression) {
                this.type = syntax_1.Syntax.ExpressionStatement;
                this.expression = expression;
              }
              return ExpressionStatement2;
            })();
            exports2.ExpressionStatement = ExpressionStatement;
            var ForInStatement = /* @__PURE__ */ (function() {
              function ForInStatement2(left, right, body) {
                this.type = syntax_1.Syntax.ForInStatement;
                this.left = left;
                this.right = right;
                this.body = body;
                this.each = false;
              }
              return ForInStatement2;
            })();
            exports2.ForInStatement = ForInStatement;
            var ForOfStatement = /* @__PURE__ */ (function() {
              function ForOfStatement2(left, right, body) {
                this.type = syntax_1.Syntax.ForOfStatement;
                this.left = left;
                this.right = right;
                this.body = body;
              }
              return ForOfStatement2;
            })();
            exports2.ForOfStatement = ForOfStatement;
            var ForStatement = /* @__PURE__ */ (function() {
              function ForStatement2(init, test, update, body) {
                this.type = syntax_1.Syntax.ForStatement;
                this.init = init;
                this.test = test;
                this.update = update;
                this.body = body;
              }
              return ForStatement2;
            })();
            exports2.ForStatement = ForStatement;
            var FunctionDeclaration = /* @__PURE__ */ (function() {
              function FunctionDeclaration2(id, params, body, generator) {
                this.type = syntax_1.Syntax.FunctionDeclaration;
                this.id = id;
                this.params = params;
                this.body = body;
                this.generator = generator;
                this.expression = false;
                this.async = false;
              }
              return FunctionDeclaration2;
            })();
            exports2.FunctionDeclaration = FunctionDeclaration;
            var FunctionExpression = /* @__PURE__ */ (function() {
              function FunctionExpression2(id, params, body, generator) {
                this.type = syntax_1.Syntax.FunctionExpression;
                this.id = id;
                this.params = params;
                this.body = body;
                this.generator = generator;
                this.expression = false;
                this.async = false;
              }
              return FunctionExpression2;
            })();
            exports2.FunctionExpression = FunctionExpression;
            var Identifier = /* @__PURE__ */ (function() {
              function Identifier2(name) {
                this.type = syntax_1.Syntax.Identifier;
                this.name = name;
              }
              return Identifier2;
            })();
            exports2.Identifier = Identifier;
            var IfStatement = /* @__PURE__ */ (function() {
              function IfStatement2(test, consequent, alternate) {
                this.type = syntax_1.Syntax.IfStatement;
                this.test = test;
                this.consequent = consequent;
                this.alternate = alternate;
              }
              return IfStatement2;
            })();
            exports2.IfStatement = IfStatement;
            var ImportDeclaration = /* @__PURE__ */ (function() {
              function ImportDeclaration2(specifiers, source) {
                this.type = syntax_1.Syntax.ImportDeclaration;
                this.specifiers = specifiers;
                this.source = source;
              }
              return ImportDeclaration2;
            })();
            exports2.ImportDeclaration = ImportDeclaration;
            var ImportDefaultSpecifier = /* @__PURE__ */ (function() {
              function ImportDefaultSpecifier2(local) {
                this.type = syntax_1.Syntax.ImportDefaultSpecifier;
                this.local = local;
              }
              return ImportDefaultSpecifier2;
            })();
            exports2.ImportDefaultSpecifier = ImportDefaultSpecifier;
            var ImportNamespaceSpecifier = /* @__PURE__ */ (function() {
              function ImportNamespaceSpecifier2(local) {
                this.type = syntax_1.Syntax.ImportNamespaceSpecifier;
                this.local = local;
              }
              return ImportNamespaceSpecifier2;
            })();
            exports2.ImportNamespaceSpecifier = ImportNamespaceSpecifier;
            var ImportSpecifier = /* @__PURE__ */ (function() {
              function ImportSpecifier2(local, imported) {
                this.type = syntax_1.Syntax.ImportSpecifier;
                this.local = local;
                this.imported = imported;
              }
              return ImportSpecifier2;
            })();
            exports2.ImportSpecifier = ImportSpecifier;
            var LabeledStatement = /* @__PURE__ */ (function() {
              function LabeledStatement2(label, body) {
                this.type = syntax_1.Syntax.LabeledStatement;
                this.label = label;
                this.body = body;
              }
              return LabeledStatement2;
            })();
            exports2.LabeledStatement = LabeledStatement;
            var Literal = /* @__PURE__ */ (function() {
              function Literal2(value, raw) {
                this.type = syntax_1.Syntax.Literal;
                this.value = value;
                this.raw = raw;
              }
              return Literal2;
            })();
            exports2.Literal = Literal;
            var MetaProperty = /* @__PURE__ */ (function() {
              function MetaProperty2(meta, property) {
                this.type = syntax_1.Syntax.MetaProperty;
                this.meta = meta;
                this.property = property;
              }
              return MetaProperty2;
            })();
            exports2.MetaProperty = MetaProperty;
            var MethodDefinition = /* @__PURE__ */ (function() {
              function MethodDefinition2(key, computed, value, kind, isStatic) {
                this.type = syntax_1.Syntax.MethodDefinition;
                this.key = key;
                this.computed = computed;
                this.value = value;
                this.kind = kind;
                this.static = isStatic;
              }
              return MethodDefinition2;
            })();
            exports2.MethodDefinition = MethodDefinition;
            var Module = /* @__PURE__ */ (function() {
              function Module2(body) {
                this.type = syntax_1.Syntax.Program;
                this.body = body;
                this.sourceType = "module";
              }
              return Module2;
            })();
            exports2.Module = Module;
            var NewExpression = /* @__PURE__ */ (function() {
              function NewExpression2(callee, args) {
                this.type = syntax_1.Syntax.NewExpression;
                this.callee = callee;
                this.arguments = args;
              }
              return NewExpression2;
            })();
            exports2.NewExpression = NewExpression;
            var ObjectExpression = /* @__PURE__ */ (function() {
              function ObjectExpression2(properties) {
                this.type = syntax_1.Syntax.ObjectExpression;
                this.properties = properties;
              }
              return ObjectExpression2;
            })();
            exports2.ObjectExpression = ObjectExpression;
            var ObjectPattern = /* @__PURE__ */ (function() {
              function ObjectPattern2(properties) {
                this.type = syntax_1.Syntax.ObjectPattern;
                this.properties = properties;
              }
              return ObjectPattern2;
            })();
            exports2.ObjectPattern = ObjectPattern;
            var Property = /* @__PURE__ */ (function() {
              function Property2(kind, key, computed, value, method, shorthand) {
                this.type = syntax_1.Syntax.Property;
                this.key = key;
                this.computed = computed;
                this.value = value;
                this.kind = kind;
                this.method = method;
                this.shorthand = shorthand;
              }
              return Property2;
            })();
            exports2.Property = Property;
            var RegexLiteral = /* @__PURE__ */ (function() {
              function RegexLiteral2(value, raw, pattern, flags) {
                this.type = syntax_1.Syntax.Literal;
                this.value = value;
                this.raw = raw;
                this.regex = { pattern, flags };
              }
              return RegexLiteral2;
            })();
            exports2.RegexLiteral = RegexLiteral;
            var RestElement = /* @__PURE__ */ (function() {
              function RestElement2(argument) {
                this.type = syntax_1.Syntax.RestElement;
                this.argument = argument;
              }
              return RestElement2;
            })();
            exports2.RestElement = RestElement;
            var ReturnStatement = /* @__PURE__ */ (function() {
              function ReturnStatement2(argument) {
                this.type = syntax_1.Syntax.ReturnStatement;
                this.argument = argument;
              }
              return ReturnStatement2;
            })();
            exports2.ReturnStatement = ReturnStatement;
            var Script = /* @__PURE__ */ (function() {
              function Script2(body) {
                this.type = syntax_1.Syntax.Program;
                this.body = body;
                this.sourceType = "script";
              }
              return Script2;
            })();
            exports2.Script = Script;
            var SequenceExpression = /* @__PURE__ */ (function() {
              function SequenceExpression2(expressions) {
                this.type = syntax_1.Syntax.SequenceExpression;
                this.expressions = expressions;
              }
              return SequenceExpression2;
            })();
            exports2.SequenceExpression = SequenceExpression;
            var SpreadElement = /* @__PURE__ */ (function() {
              function SpreadElement2(argument) {
                this.type = syntax_1.Syntax.SpreadElement;
                this.argument = argument;
              }
              return SpreadElement2;
            })();
            exports2.SpreadElement = SpreadElement;
            var StaticMemberExpression = /* @__PURE__ */ (function() {
              function StaticMemberExpression2(object, property) {
                this.type = syntax_1.Syntax.MemberExpression;
                this.computed = false;
                this.object = object;
                this.property = property;
              }
              return StaticMemberExpression2;
            })();
            exports2.StaticMemberExpression = StaticMemberExpression;
            var Super = /* @__PURE__ */ (function() {
              function Super2() {
                this.type = syntax_1.Syntax.Super;
              }
              return Super2;
            })();
            exports2.Super = Super;
            var SwitchCase = /* @__PURE__ */ (function() {
              function SwitchCase2(test, consequent) {
                this.type = syntax_1.Syntax.SwitchCase;
                this.test = test;
                this.consequent = consequent;
              }
              return SwitchCase2;
            })();
            exports2.SwitchCase = SwitchCase;
            var SwitchStatement = /* @__PURE__ */ (function() {
              function SwitchStatement2(discriminant, cases) {
                this.type = syntax_1.Syntax.SwitchStatement;
                this.discriminant = discriminant;
                this.cases = cases;
              }
              return SwitchStatement2;
            })();
            exports2.SwitchStatement = SwitchStatement;
            var TaggedTemplateExpression = /* @__PURE__ */ (function() {
              function TaggedTemplateExpression2(tag, quasi) {
                this.type = syntax_1.Syntax.TaggedTemplateExpression;
                this.tag = tag;
                this.quasi = quasi;
              }
              return TaggedTemplateExpression2;
            })();
            exports2.TaggedTemplateExpression = TaggedTemplateExpression;
            var TemplateElement = /* @__PURE__ */ (function() {
              function TemplateElement2(value, tail) {
                this.type = syntax_1.Syntax.TemplateElement;
                this.value = value;
                this.tail = tail;
              }
              return TemplateElement2;
            })();
            exports2.TemplateElement = TemplateElement;
            var TemplateLiteral = /* @__PURE__ */ (function() {
              function TemplateLiteral2(quasis, expressions) {
                this.type = syntax_1.Syntax.TemplateLiteral;
                this.quasis = quasis;
                this.expressions = expressions;
              }
              return TemplateLiteral2;
            })();
            exports2.TemplateLiteral = TemplateLiteral;
            var ThisExpression = /* @__PURE__ */ (function() {
              function ThisExpression2() {
                this.type = syntax_1.Syntax.ThisExpression;
              }
              return ThisExpression2;
            })();
            exports2.ThisExpression = ThisExpression;
            var ThrowStatement = /* @__PURE__ */ (function() {
              function ThrowStatement2(argument) {
                this.type = syntax_1.Syntax.ThrowStatement;
                this.argument = argument;
              }
              return ThrowStatement2;
            })();
            exports2.ThrowStatement = ThrowStatement;
            var TryStatement = /* @__PURE__ */ (function() {
              function TryStatement2(block, handler, finalizer) {
                this.type = syntax_1.Syntax.TryStatement;
                this.block = block;
                this.handler = handler;
                this.finalizer = finalizer;
              }
              return TryStatement2;
            })();
            exports2.TryStatement = TryStatement;
            var UnaryExpression = /* @__PURE__ */ (function() {
              function UnaryExpression2(operator, argument) {
                this.type = syntax_1.Syntax.UnaryExpression;
                this.operator = operator;
                this.argument = argument;
                this.prefix = true;
              }
              return UnaryExpression2;
            })();
            exports2.UnaryExpression = UnaryExpression;
            var UpdateExpression = /* @__PURE__ */ (function() {
              function UpdateExpression2(operator, argument, prefix) {
                this.type = syntax_1.Syntax.UpdateExpression;
                this.operator = operator;
                this.argument = argument;
                this.prefix = prefix;
              }
              return UpdateExpression2;
            })();
            exports2.UpdateExpression = UpdateExpression;
            var VariableDeclaration = /* @__PURE__ */ (function() {
              function VariableDeclaration2(declarations, kind) {
                this.type = syntax_1.Syntax.VariableDeclaration;
                this.declarations = declarations;
                this.kind = kind;
              }
              return VariableDeclaration2;
            })();
            exports2.VariableDeclaration = VariableDeclaration;
            var VariableDeclarator = /* @__PURE__ */ (function() {
              function VariableDeclarator2(id, init) {
                this.type = syntax_1.Syntax.VariableDeclarator;
                this.id = id;
                this.init = init;
              }
              return VariableDeclarator2;
            })();
            exports2.VariableDeclarator = VariableDeclarator;
            var WhileStatement = /* @__PURE__ */ (function() {
              function WhileStatement2(test, body) {
                this.type = syntax_1.Syntax.WhileStatement;
                this.test = test;
                this.body = body;
              }
              return WhileStatement2;
            })();
            exports2.WhileStatement = WhileStatement;
            var WithStatement = /* @__PURE__ */ (function() {
              function WithStatement2(object, body) {
                this.type = syntax_1.Syntax.WithStatement;
                this.object = object;
                this.body = body;
              }
              return WithStatement2;
            })();
            exports2.WithStatement = WithStatement;
            var YieldExpression = /* @__PURE__ */ (function() {
              function YieldExpression2(argument, delegate) {
                this.type = syntax_1.Syntax.YieldExpression;
                this.argument = argument;
                this.delegate = delegate;
              }
              return YieldExpression2;
            })();
            exports2.YieldExpression = YieldExpression;
          },
          /* 8 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var assert_1 = __webpack_require__(9);
            var error_handler_1 = __webpack_require__(10);
            var messages_1 = __webpack_require__(11);
            var Node = __webpack_require__(7);
            var scanner_1 = __webpack_require__(12);
            var syntax_1 = __webpack_require__(2);
            var token_1 = __webpack_require__(13);
            var ArrowParameterPlaceHolder = "ArrowParameterPlaceHolder";
            var Parser = (function() {
              function Parser2(code, options, delegate) {
                if (options === void 0) {
                  options = {};
                }
                this.config = {
                  range: typeof options.range === "boolean" && options.range,
                  loc: typeof options.loc === "boolean" && options.loc,
                  source: null,
                  tokens: typeof options.tokens === "boolean" && options.tokens,
                  comment: typeof options.comment === "boolean" && options.comment,
                  tolerant: typeof options.tolerant === "boolean" && options.tolerant
                };
                if (this.config.loc && options.source && options.source !== null) {
                  this.config.source = String(options.source);
                }
                this.delegate = delegate;
                this.errorHandler = new error_handler_1.ErrorHandler();
                this.errorHandler.tolerant = this.config.tolerant;
                this.scanner = new scanner_1.Scanner(code, this.errorHandler);
                this.scanner.trackComment = this.config.comment;
                this.operatorPrecedence = {
                  ")": 0,
                  ";": 0,
                  ",": 0,
                  "=": 0,
                  "]": 0,
                  "||": 1,
                  "&&": 2,
                  "|": 3,
                  "^": 4,
                  "&": 5,
                  "==": 6,
                  "!=": 6,
                  "===": 6,
                  "!==": 6,
                  "<": 7,
                  ">": 7,
                  "<=": 7,
                  ">=": 7,
                  "<<": 8,
                  ">>": 8,
                  ">>>": 8,
                  "+": 9,
                  "-": 9,
                  "*": 11,
                  "/": 11,
                  "%": 11
                };
                this.lookahead = {
                  type: 2,
                  value: "",
                  lineNumber: this.scanner.lineNumber,
                  lineStart: 0,
                  start: 0,
                  end: 0
                };
                this.hasLineTerminator = false;
                this.context = {
                  isModule: false,
                  await: false,
                  allowIn: true,
                  allowStrictDirective: true,
                  allowYield: true,
                  firstCoverInitializedNameError: null,
                  isAssignmentTarget: false,
                  isBindingElement: false,
                  inFunctionBody: false,
                  inIteration: false,
                  inSwitch: false,
                  labelSet: {},
                  strict: false
                };
                this.tokens = [];
                this.startMarker = {
                  index: 0,
                  line: this.scanner.lineNumber,
                  column: 0
                };
                this.lastMarker = {
                  index: 0,
                  line: this.scanner.lineNumber,
                  column: 0
                };
                this.nextToken();
                this.lastMarker = {
                  index: this.scanner.index,
                  line: this.scanner.lineNumber,
                  column: this.scanner.index - this.scanner.lineStart
                };
              }
              Parser2.prototype.throwError = function(messageFormat) {
                var values = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                  values[_i - 1] = arguments[_i];
                }
                var args = Array.prototype.slice.call(arguments, 1);
                var msg = messageFormat.replace(/%(\d)/g, function(whole, idx) {
                  assert_1.assert(idx < args.length, "Message reference must be in range");
                  return args[idx];
                });
                var index = this.lastMarker.index;
                var line = this.lastMarker.line;
                var column = this.lastMarker.column + 1;
                throw this.errorHandler.createError(index, line, column, msg);
              };
              Parser2.prototype.tolerateError = function(messageFormat) {
                var values = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                  values[_i - 1] = arguments[_i];
                }
                var args = Array.prototype.slice.call(arguments, 1);
                var msg = messageFormat.replace(/%(\d)/g, function(whole, idx) {
                  assert_1.assert(idx < args.length, "Message reference must be in range");
                  return args[idx];
                });
                var index = this.lastMarker.index;
                var line = this.scanner.lineNumber;
                var column = this.lastMarker.column + 1;
                this.errorHandler.tolerateError(index, line, column, msg);
              };
              Parser2.prototype.unexpectedTokenError = function(token, message) {
                var msg = message || messages_1.Messages.UnexpectedToken;
                var value;
                if (token) {
                  if (!message) {
                    msg = token.type === 2 ? messages_1.Messages.UnexpectedEOS : token.type === 3 ? messages_1.Messages.UnexpectedIdentifier : token.type === 6 ? messages_1.Messages.UnexpectedNumber : token.type === 8 ? messages_1.Messages.UnexpectedString : token.type === 10 ? messages_1.Messages.UnexpectedTemplate : messages_1.Messages.UnexpectedToken;
                    if (token.type === 4) {
                      if (this.scanner.isFutureReservedWord(token.value)) {
                        msg = messages_1.Messages.UnexpectedReserved;
                      } else if (this.context.strict && this.scanner.isStrictModeReservedWord(token.value)) {
                        msg = messages_1.Messages.StrictReservedWord;
                      }
                    }
                  }
                  value = token.value;
                } else {
                  value = "ILLEGAL";
                }
                msg = msg.replace("%0", value);
                if (token && typeof token.lineNumber === "number") {
                  var index = token.start;
                  var line = token.lineNumber;
                  var lastMarkerLineStart = this.lastMarker.index - this.lastMarker.column;
                  var column = token.start - lastMarkerLineStart + 1;
                  return this.errorHandler.createError(index, line, column, msg);
                } else {
                  var index = this.lastMarker.index;
                  var line = this.lastMarker.line;
                  var column = this.lastMarker.column + 1;
                  return this.errorHandler.createError(index, line, column, msg);
                }
              };
              Parser2.prototype.throwUnexpectedToken = function(token, message) {
                throw this.unexpectedTokenError(token, message);
              };
              Parser2.prototype.tolerateUnexpectedToken = function(token, message) {
                this.errorHandler.tolerate(this.unexpectedTokenError(token, message));
              };
              Parser2.prototype.collectComments = function() {
                if (!this.config.comment) {
                  this.scanner.scanComments();
                } else {
                  var comments = this.scanner.scanComments();
                  if (comments.length > 0 && this.delegate) {
                    for (var i = 0; i < comments.length; ++i) {
                      var e = comments[i];
                      var node = void 0;
                      node = {
                        type: e.multiLine ? "BlockComment" : "LineComment",
                        value: this.scanner.source.slice(e.slice[0], e.slice[1])
                      };
                      if (this.config.range) {
                        node.range = e.range;
                      }
                      if (this.config.loc) {
                        node.loc = e.loc;
                      }
                      var metadata = {
                        start: {
                          line: e.loc.start.line,
                          column: e.loc.start.column,
                          offset: e.range[0]
                        },
                        end: {
                          line: e.loc.end.line,
                          column: e.loc.end.column,
                          offset: e.range[1]
                        }
                      };
                      this.delegate(node, metadata);
                    }
                  }
                }
              };
              Parser2.prototype.getTokenRaw = function(token) {
                return this.scanner.source.slice(token.start, token.end);
              };
              Parser2.prototype.convertToken = function(token) {
                var t = {
                  type: token_1.TokenName[token.type],
                  value: this.getTokenRaw(token)
                };
                if (this.config.range) {
                  t.range = [token.start, token.end];
                }
                if (this.config.loc) {
                  t.loc = {
                    start: {
                      line: this.startMarker.line,
                      column: this.startMarker.column
                    },
                    end: {
                      line: this.scanner.lineNumber,
                      column: this.scanner.index - this.scanner.lineStart
                    }
                  };
                }
                if (token.type === 9) {
                  var pattern = token.pattern;
                  var flags = token.flags;
                  t.regex = { pattern, flags };
                }
                return t;
              };
              Parser2.prototype.nextToken = function() {
                var token = this.lookahead;
                this.lastMarker.index = this.scanner.index;
                this.lastMarker.line = this.scanner.lineNumber;
                this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
                this.collectComments();
                if (this.scanner.index !== this.startMarker.index) {
                  this.startMarker.index = this.scanner.index;
                  this.startMarker.line = this.scanner.lineNumber;
                  this.startMarker.column = this.scanner.index - this.scanner.lineStart;
                }
                var next = this.scanner.lex();
                this.hasLineTerminator = token.lineNumber !== next.lineNumber;
                if (next && this.context.strict && next.type === 3) {
                  if (this.scanner.isStrictModeReservedWord(next.value)) {
                    next.type = 4;
                  }
                }
                this.lookahead = next;
                if (this.config.tokens && next.type !== 2) {
                  this.tokens.push(this.convertToken(next));
                }
                return token;
              };
              Parser2.prototype.nextRegexToken = function() {
                this.collectComments();
                var token = this.scanner.scanRegExp();
                if (this.config.tokens) {
                  this.tokens.pop();
                  this.tokens.push(this.convertToken(token));
                }
                this.lookahead = token;
                this.nextToken();
                return token;
              };
              Parser2.prototype.createNode = function() {
                return {
                  index: this.startMarker.index,
                  line: this.startMarker.line,
                  column: this.startMarker.column
                };
              };
              Parser2.prototype.startNode = function(token, lastLineStart) {
                if (lastLineStart === void 0) {
                  lastLineStart = 0;
                }
                var column = token.start - token.lineStart;
                var line = token.lineNumber;
                if (column < 0) {
                  column += lastLineStart;
                  line--;
                }
                return {
                  index: token.start,
                  line,
                  column
                };
              };
              Parser2.prototype.finalize = function(marker, node) {
                if (this.config.range) {
                  node.range = [marker.index, this.lastMarker.index];
                }
                if (this.config.loc) {
                  node.loc = {
                    start: {
                      line: marker.line,
                      column: marker.column
                    },
                    end: {
                      line: this.lastMarker.line,
                      column: this.lastMarker.column
                    }
                  };
                  if (this.config.source) {
                    node.loc.source = this.config.source;
                  }
                }
                if (this.delegate) {
                  var metadata = {
                    start: {
                      line: marker.line,
                      column: marker.column,
                      offset: marker.index
                    },
                    end: {
                      line: this.lastMarker.line,
                      column: this.lastMarker.column,
                      offset: this.lastMarker.index
                    }
                  };
                  this.delegate(node, metadata);
                }
                return node;
              };
              Parser2.prototype.expect = function(value) {
                var token = this.nextToken();
                if (token.type !== 7 || token.value !== value) {
                  this.throwUnexpectedToken(token);
                }
              };
              Parser2.prototype.expectCommaSeparator = function() {
                if (this.config.tolerant) {
                  var token = this.lookahead;
                  if (token.type === 7 && token.value === ",") {
                    this.nextToken();
                  } else if (token.type === 7 && token.value === ";") {
                    this.nextToken();
                    this.tolerateUnexpectedToken(token);
                  } else {
                    this.tolerateUnexpectedToken(token, messages_1.Messages.UnexpectedToken);
                  }
                } else {
                  this.expect(",");
                }
              };
              Parser2.prototype.expectKeyword = function(keyword) {
                var token = this.nextToken();
                if (token.type !== 4 || token.value !== keyword) {
                  this.throwUnexpectedToken(token);
                }
              };
              Parser2.prototype.match = function(value) {
                return this.lookahead.type === 7 && this.lookahead.value === value;
              };
              Parser2.prototype.matchKeyword = function(keyword) {
                return this.lookahead.type === 4 && this.lookahead.value === keyword;
              };
              Parser2.prototype.matchContextualKeyword = function(keyword) {
                return this.lookahead.type === 3 && this.lookahead.value === keyword;
              };
              Parser2.prototype.matchAssign = function() {
                if (this.lookahead.type !== 7) {
                  return false;
                }
                var op = this.lookahead.value;
                return op === "=" || op === "*=" || op === "**=" || op === "/=" || op === "%=" || op === "+=" || op === "-=" || op === "<<=" || op === ">>=" || op === ">>>=" || op === "&=" || op === "^=" || op === "|=";
              };
              Parser2.prototype.isolateCoverGrammar = function(parseFunction) {
                var previousIsBindingElement = this.context.isBindingElement;
                var previousIsAssignmentTarget = this.context.isAssignmentTarget;
                var previousFirstCoverInitializedNameError = this.context.firstCoverInitializedNameError;
                this.context.isBindingElement = true;
                this.context.isAssignmentTarget = true;
                this.context.firstCoverInitializedNameError = null;
                var result = parseFunction.call(this);
                if (this.context.firstCoverInitializedNameError !== null) {
                  this.throwUnexpectedToken(this.context.firstCoverInitializedNameError);
                }
                this.context.isBindingElement = previousIsBindingElement;
                this.context.isAssignmentTarget = previousIsAssignmentTarget;
                this.context.firstCoverInitializedNameError = previousFirstCoverInitializedNameError;
                return result;
              };
              Parser2.prototype.inheritCoverGrammar = function(parseFunction) {
                var previousIsBindingElement = this.context.isBindingElement;
                var previousIsAssignmentTarget = this.context.isAssignmentTarget;
                var previousFirstCoverInitializedNameError = this.context.firstCoverInitializedNameError;
                this.context.isBindingElement = true;
                this.context.isAssignmentTarget = true;
                this.context.firstCoverInitializedNameError = null;
                var result = parseFunction.call(this);
                this.context.isBindingElement = this.context.isBindingElement && previousIsBindingElement;
                this.context.isAssignmentTarget = this.context.isAssignmentTarget && previousIsAssignmentTarget;
                this.context.firstCoverInitializedNameError = previousFirstCoverInitializedNameError || this.context.firstCoverInitializedNameError;
                return result;
              };
              Parser2.prototype.consumeSemicolon = function() {
                if (this.match(";")) {
                  this.nextToken();
                } else if (!this.hasLineTerminator) {
                  if (this.lookahead.type !== 2 && !this.match("}")) {
                    this.throwUnexpectedToken(this.lookahead);
                  }
                  this.lastMarker.index = this.startMarker.index;
                  this.lastMarker.line = this.startMarker.line;
                  this.lastMarker.column = this.startMarker.column;
                }
              };
              Parser2.prototype.parsePrimaryExpression = function() {
                var node = this.createNode();
                var expr;
                var token, raw;
                switch (this.lookahead.type) {
                  case 3:
                    if ((this.context.isModule || this.context.await) && this.lookahead.value === "await") {
                      this.tolerateUnexpectedToken(this.lookahead);
                    }
                    expr = this.matchAsyncFunction() ? this.parseFunctionExpression() : this.finalize(node, new Node.Identifier(this.nextToken().value));
                    break;
                  case 6:
                  case 8:
                    if (this.context.strict && this.lookahead.octal) {
                      this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.StrictOctalLiteral);
                    }
                    this.context.isAssignmentTarget = false;
                    this.context.isBindingElement = false;
                    token = this.nextToken();
                    raw = this.getTokenRaw(token);
                    expr = this.finalize(node, new Node.Literal(token.value, raw));
                    break;
                  case 1:
                    this.context.isAssignmentTarget = false;
                    this.context.isBindingElement = false;
                    token = this.nextToken();
                    raw = this.getTokenRaw(token);
                    expr = this.finalize(node, new Node.Literal(token.value === "true", raw));
                    break;
                  case 5:
                    this.context.isAssignmentTarget = false;
                    this.context.isBindingElement = false;
                    token = this.nextToken();
                    raw = this.getTokenRaw(token);
                    expr = this.finalize(node, new Node.Literal(null, raw));
                    break;
                  case 10:
                    expr = this.parseTemplateLiteral();
                    break;
                  case 7:
                    switch (this.lookahead.value) {
                      case "(":
                        this.context.isBindingElement = false;
                        expr = this.inheritCoverGrammar(this.parseGroupExpression);
                        break;
                      case "[":
                        expr = this.inheritCoverGrammar(this.parseArrayInitializer);
                        break;
                      case "{":
                        expr = this.inheritCoverGrammar(this.parseObjectInitializer);
                        break;
                      case "/":
                      case "/=":
                        this.context.isAssignmentTarget = false;
                        this.context.isBindingElement = false;
                        this.scanner.index = this.startMarker.index;
                        token = this.nextRegexToken();
                        raw = this.getTokenRaw(token);
                        expr = this.finalize(node, new Node.RegexLiteral(token.regex, raw, token.pattern, token.flags));
                        break;
                      default:
                        expr = this.throwUnexpectedToken(this.nextToken());
                    }
                    break;
                  case 4:
                    if (!this.context.strict && this.context.allowYield && this.matchKeyword("yield")) {
                      expr = this.parseIdentifierName();
                    } else if (!this.context.strict && this.matchKeyword("let")) {
                      expr = this.finalize(node, new Node.Identifier(this.nextToken().value));
                    } else {
                      this.context.isAssignmentTarget = false;
                      this.context.isBindingElement = false;
                      if (this.matchKeyword("function")) {
                        expr = this.parseFunctionExpression();
                      } else if (this.matchKeyword("this")) {
                        this.nextToken();
                        expr = this.finalize(node, new Node.ThisExpression());
                      } else if (this.matchKeyword("class")) {
                        expr = this.parseClassExpression();
                      } else {
                        expr = this.throwUnexpectedToken(this.nextToken());
                      }
                    }
                    break;
                  default:
                    expr = this.throwUnexpectedToken(this.nextToken());
                }
                return expr;
              };
              Parser2.prototype.parseSpreadElement = function() {
                var node = this.createNode();
                this.expect("...");
                var arg = this.inheritCoverGrammar(this.parseAssignmentExpression);
                return this.finalize(node, new Node.SpreadElement(arg));
              };
              Parser2.prototype.parseArrayInitializer = function() {
                var node = this.createNode();
                var elements = [];
                this.expect("[");
                while (!this.match("]")) {
                  if (this.match(",")) {
                    this.nextToken();
                    elements.push(null);
                  } else if (this.match("...")) {
                    var element = this.parseSpreadElement();
                    if (!this.match("]")) {
                      this.context.isAssignmentTarget = false;
                      this.context.isBindingElement = false;
                      this.expect(",");
                    }
                    elements.push(element);
                  } else {
                    elements.push(this.inheritCoverGrammar(this.parseAssignmentExpression));
                    if (!this.match("]")) {
                      this.expect(",");
                    }
                  }
                }
                this.expect("]");
                return this.finalize(node, new Node.ArrayExpression(elements));
              };
              Parser2.prototype.parsePropertyMethod = function(params) {
                this.context.isAssignmentTarget = false;
                this.context.isBindingElement = false;
                var previousStrict = this.context.strict;
                var previousAllowStrictDirective = this.context.allowStrictDirective;
                this.context.allowStrictDirective = params.simple;
                var body = this.isolateCoverGrammar(this.parseFunctionSourceElements);
                if (this.context.strict && params.firstRestricted) {
                  this.tolerateUnexpectedToken(params.firstRestricted, params.message);
                }
                if (this.context.strict && params.stricted) {
                  this.tolerateUnexpectedToken(params.stricted, params.message);
                }
                this.context.strict = previousStrict;
                this.context.allowStrictDirective = previousAllowStrictDirective;
                return body;
              };
              Parser2.prototype.parsePropertyMethodFunction = function() {
                var isGenerator = false;
                var node = this.createNode();
                var previousAllowYield = this.context.allowYield;
                this.context.allowYield = true;
                var params = this.parseFormalParameters();
                var method = this.parsePropertyMethod(params);
                this.context.allowYield = previousAllowYield;
                return this.finalize(node, new Node.FunctionExpression(null, params.params, method, isGenerator));
              };
              Parser2.prototype.parsePropertyMethodAsyncFunction = function() {
                var node = this.createNode();
                var previousAllowYield = this.context.allowYield;
                var previousAwait = this.context.await;
                this.context.allowYield = false;
                this.context.await = true;
                var params = this.parseFormalParameters();
                var method = this.parsePropertyMethod(params);
                this.context.allowYield = previousAllowYield;
                this.context.await = previousAwait;
                return this.finalize(node, new Node.AsyncFunctionExpression(null, params.params, method));
              };
              Parser2.prototype.parseObjectPropertyKey = function() {
                var node = this.createNode();
                var token = this.nextToken();
                var key;
                switch (token.type) {
                  case 8:
                  case 6:
                    if (this.context.strict && token.octal) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.StrictOctalLiteral);
                    }
                    var raw = this.getTokenRaw(token);
                    key = this.finalize(node, new Node.Literal(token.value, raw));
                    break;
                  case 3:
                  case 1:
                  case 5:
                  case 4:
                    key = this.finalize(node, new Node.Identifier(token.value));
                    break;
                  case 7:
                    if (token.value === "[") {
                      key = this.isolateCoverGrammar(this.parseAssignmentExpression);
                      this.expect("]");
                    } else {
                      key = this.throwUnexpectedToken(token);
                    }
                    break;
                  default:
                    key = this.throwUnexpectedToken(token);
                }
                return key;
              };
              Parser2.prototype.isPropertyKey = function(key, value) {
                return key.type === syntax_1.Syntax.Identifier && key.name === value || key.type === syntax_1.Syntax.Literal && key.value === value;
              };
              Parser2.prototype.parseObjectProperty = function(hasProto) {
                var node = this.createNode();
                var token = this.lookahead;
                var kind;
                var key = null;
                var value = null;
                var computed = false;
                var method = false;
                var shorthand = false;
                var isAsync = false;
                if (token.type === 3) {
                  var id = token.value;
                  this.nextToken();
                  computed = this.match("[");
                  isAsync = !this.hasLineTerminator && id === "async" && !this.match(":") && !this.match("(") && !this.match("*") && !this.match(",");
                  key = isAsync ? this.parseObjectPropertyKey() : this.finalize(node, new Node.Identifier(id));
                } else if (this.match("*")) {
                  this.nextToken();
                } else {
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                }
                var lookaheadPropertyKey = this.qualifiedPropertyName(this.lookahead);
                if (token.type === 3 && !isAsync && token.value === "get" && lookaheadPropertyKey) {
                  kind = "get";
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  this.context.allowYield = false;
                  value = this.parseGetterMethod();
                } else if (token.type === 3 && !isAsync && token.value === "set" && lookaheadPropertyKey) {
                  kind = "set";
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  value = this.parseSetterMethod();
                } else if (token.type === 7 && token.value === "*" && lookaheadPropertyKey) {
                  kind = "init";
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  value = this.parseGeneratorMethod();
                  method = true;
                } else {
                  if (!key) {
                    this.throwUnexpectedToken(this.lookahead);
                  }
                  kind = "init";
                  if (this.match(":") && !isAsync) {
                    if (!computed && this.isPropertyKey(key, "__proto__")) {
                      if (hasProto.value) {
                        this.tolerateError(messages_1.Messages.DuplicateProtoProperty);
                      }
                      hasProto.value = true;
                    }
                    this.nextToken();
                    value = this.inheritCoverGrammar(this.parseAssignmentExpression);
                  } else if (this.match("(")) {
                    value = isAsync ? this.parsePropertyMethodAsyncFunction() : this.parsePropertyMethodFunction();
                    method = true;
                  } else if (token.type === 3) {
                    var id = this.finalize(node, new Node.Identifier(token.value));
                    if (this.match("=")) {
                      this.context.firstCoverInitializedNameError = this.lookahead;
                      this.nextToken();
                      shorthand = true;
                      var init = this.isolateCoverGrammar(this.parseAssignmentExpression);
                      value = this.finalize(node, new Node.AssignmentPattern(id, init));
                    } else {
                      shorthand = true;
                      value = id;
                    }
                  } else {
                    this.throwUnexpectedToken(this.nextToken());
                  }
                }
                return this.finalize(node, new Node.Property(kind, key, computed, value, method, shorthand));
              };
              Parser2.prototype.parseObjectInitializer = function() {
                var node = this.createNode();
                this.expect("{");
                var properties = [];
                var hasProto = { value: false };
                while (!this.match("}")) {
                  properties.push(this.parseObjectProperty(hasProto));
                  if (!this.match("}")) {
                    this.expectCommaSeparator();
                  }
                }
                this.expect("}");
                return this.finalize(node, new Node.ObjectExpression(properties));
              };
              Parser2.prototype.parseTemplateHead = function() {
                assert_1.assert(this.lookahead.head, "Template literal must start with a template head");
                var node = this.createNode();
                var token = this.nextToken();
                var raw = token.value;
                var cooked = token.cooked;
                return this.finalize(node, new Node.TemplateElement({ raw, cooked }, token.tail));
              };
              Parser2.prototype.parseTemplateElement = function() {
                if (this.lookahead.type !== 10) {
                  this.throwUnexpectedToken();
                }
                var node = this.createNode();
                var token = this.nextToken();
                var raw = token.value;
                var cooked = token.cooked;
                return this.finalize(node, new Node.TemplateElement({ raw, cooked }, token.tail));
              };
              Parser2.prototype.parseTemplateLiteral = function() {
                var node = this.createNode();
                var expressions = [];
                var quasis = [];
                var quasi = this.parseTemplateHead();
                quasis.push(quasi);
                while (!quasi.tail) {
                  expressions.push(this.parseExpression());
                  quasi = this.parseTemplateElement();
                  quasis.push(quasi);
                }
                return this.finalize(node, new Node.TemplateLiteral(quasis, expressions));
              };
              Parser2.prototype.reinterpretExpressionAsPattern = function(expr) {
                switch (expr.type) {
                  case syntax_1.Syntax.Identifier:
                  case syntax_1.Syntax.MemberExpression:
                  case syntax_1.Syntax.RestElement:
                  case syntax_1.Syntax.AssignmentPattern:
                    break;
                  case syntax_1.Syntax.SpreadElement:
                    expr.type = syntax_1.Syntax.RestElement;
                    this.reinterpretExpressionAsPattern(expr.argument);
                    break;
                  case syntax_1.Syntax.ArrayExpression:
                    expr.type = syntax_1.Syntax.ArrayPattern;
                    for (var i = 0; i < expr.elements.length; i++) {
                      if (expr.elements[i] !== null) {
                        this.reinterpretExpressionAsPattern(expr.elements[i]);
                      }
                    }
                    break;
                  case syntax_1.Syntax.ObjectExpression:
                    expr.type = syntax_1.Syntax.ObjectPattern;
                    for (var i = 0; i < expr.properties.length; i++) {
                      this.reinterpretExpressionAsPattern(expr.properties[i].value);
                    }
                    break;
                  case syntax_1.Syntax.AssignmentExpression:
                    expr.type = syntax_1.Syntax.AssignmentPattern;
                    delete expr.operator;
                    this.reinterpretExpressionAsPattern(expr.left);
                    break;
                  default:
                    break;
                }
              };
              Parser2.prototype.parseGroupExpression = function() {
                var expr;
                this.expect("(");
                if (this.match(")")) {
                  this.nextToken();
                  if (!this.match("=>")) {
                    this.expect("=>");
                  }
                  expr = {
                    type: ArrowParameterPlaceHolder,
                    params: [],
                    async: false
                  };
                } else {
                  var startToken = this.lookahead;
                  var params = [];
                  if (this.match("...")) {
                    expr = this.parseRestElement(params);
                    this.expect(")");
                    if (!this.match("=>")) {
                      this.expect("=>");
                    }
                    expr = {
                      type: ArrowParameterPlaceHolder,
                      params: [expr],
                      async: false
                    };
                  } else {
                    var arrow = false;
                    this.context.isBindingElement = true;
                    expr = this.inheritCoverGrammar(this.parseAssignmentExpression);
                    if (this.match(",")) {
                      var expressions = [];
                      this.context.isAssignmentTarget = false;
                      expressions.push(expr);
                      while (this.lookahead.type !== 2) {
                        if (!this.match(",")) {
                          break;
                        }
                        this.nextToken();
                        if (this.match(")")) {
                          this.nextToken();
                          for (var i = 0; i < expressions.length; i++) {
                            this.reinterpretExpressionAsPattern(expressions[i]);
                          }
                          arrow = true;
                          expr = {
                            type: ArrowParameterPlaceHolder,
                            params: expressions,
                            async: false
                          };
                        } else if (this.match("...")) {
                          if (!this.context.isBindingElement) {
                            this.throwUnexpectedToken(this.lookahead);
                          }
                          expressions.push(this.parseRestElement(params));
                          this.expect(")");
                          if (!this.match("=>")) {
                            this.expect("=>");
                          }
                          this.context.isBindingElement = false;
                          for (var i = 0; i < expressions.length; i++) {
                            this.reinterpretExpressionAsPattern(expressions[i]);
                          }
                          arrow = true;
                          expr = {
                            type: ArrowParameterPlaceHolder,
                            params: expressions,
                            async: false
                          };
                        } else {
                          expressions.push(this.inheritCoverGrammar(this.parseAssignmentExpression));
                        }
                        if (arrow) {
                          break;
                        }
                      }
                      if (!arrow) {
                        expr = this.finalize(this.startNode(startToken), new Node.SequenceExpression(expressions));
                      }
                    }
                    if (!arrow) {
                      this.expect(")");
                      if (this.match("=>")) {
                        if (expr.type === syntax_1.Syntax.Identifier && expr.name === "yield") {
                          arrow = true;
                          expr = {
                            type: ArrowParameterPlaceHolder,
                            params: [expr],
                            async: false
                          };
                        }
                        if (!arrow) {
                          if (!this.context.isBindingElement) {
                            this.throwUnexpectedToken(this.lookahead);
                          }
                          if (expr.type === syntax_1.Syntax.SequenceExpression) {
                            for (var i = 0; i < expr.expressions.length; i++) {
                              this.reinterpretExpressionAsPattern(expr.expressions[i]);
                            }
                          } else {
                            this.reinterpretExpressionAsPattern(expr);
                          }
                          var parameters = expr.type === syntax_1.Syntax.SequenceExpression ? expr.expressions : [expr];
                          expr = {
                            type: ArrowParameterPlaceHolder,
                            params: parameters,
                            async: false
                          };
                        }
                      }
                      this.context.isBindingElement = false;
                    }
                  }
                }
                return expr;
              };
              Parser2.prototype.parseArguments = function() {
                this.expect("(");
                var args = [];
                if (!this.match(")")) {
                  while (true) {
                    var expr = this.match("...") ? this.parseSpreadElement() : this.isolateCoverGrammar(this.parseAssignmentExpression);
                    args.push(expr);
                    if (this.match(")")) {
                      break;
                    }
                    this.expectCommaSeparator();
                    if (this.match(")")) {
                      break;
                    }
                  }
                }
                this.expect(")");
                return args;
              };
              Parser2.prototype.isIdentifierName = function(token) {
                return token.type === 3 || token.type === 4 || token.type === 1 || token.type === 5;
              };
              Parser2.prototype.parseIdentifierName = function() {
                var node = this.createNode();
                var token = this.nextToken();
                if (!this.isIdentifierName(token)) {
                  this.throwUnexpectedToken(token);
                }
                return this.finalize(node, new Node.Identifier(token.value));
              };
              Parser2.prototype.parseNewExpression = function() {
                var node = this.createNode();
                var id = this.parseIdentifierName();
                assert_1.assert(id.name === "new", "New expression must start with `new`");
                var expr;
                if (this.match(".")) {
                  this.nextToken();
                  if (this.lookahead.type === 3 && this.context.inFunctionBody && this.lookahead.value === "target") {
                    var property = this.parseIdentifierName();
                    expr = new Node.MetaProperty(id, property);
                  } else {
                    this.throwUnexpectedToken(this.lookahead);
                  }
                } else {
                  var callee = this.isolateCoverGrammar(this.parseLeftHandSideExpression);
                  var args = this.match("(") ? this.parseArguments() : [];
                  expr = new Node.NewExpression(callee, args);
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                }
                return this.finalize(node, expr);
              };
              Parser2.prototype.parseAsyncArgument = function() {
                var arg = this.parseAssignmentExpression();
                this.context.firstCoverInitializedNameError = null;
                return arg;
              };
              Parser2.prototype.parseAsyncArguments = function() {
                this.expect("(");
                var args = [];
                if (!this.match(")")) {
                  while (true) {
                    var expr = this.match("...") ? this.parseSpreadElement() : this.isolateCoverGrammar(this.parseAsyncArgument);
                    args.push(expr);
                    if (this.match(")")) {
                      break;
                    }
                    this.expectCommaSeparator();
                    if (this.match(")")) {
                      break;
                    }
                  }
                }
                this.expect(")");
                return args;
              };
              Parser2.prototype.parseLeftHandSideExpressionAllowCall = function() {
                var startToken = this.lookahead;
                var maybeAsync = this.matchContextualKeyword("async");
                var previousAllowIn = this.context.allowIn;
                this.context.allowIn = true;
                var expr;
                if (this.matchKeyword("super") && this.context.inFunctionBody) {
                  expr = this.createNode();
                  this.nextToken();
                  expr = this.finalize(expr, new Node.Super());
                  if (!this.match("(") && !this.match(".") && !this.match("[")) {
                    this.throwUnexpectedToken(this.lookahead);
                  }
                } else {
                  expr = this.inheritCoverGrammar(this.matchKeyword("new") ? this.parseNewExpression : this.parsePrimaryExpression);
                }
                while (true) {
                  if (this.match(".")) {
                    this.context.isBindingElement = false;
                    this.context.isAssignmentTarget = true;
                    this.expect(".");
                    var property = this.parseIdentifierName();
                    expr = this.finalize(this.startNode(startToken), new Node.StaticMemberExpression(expr, property));
                  } else if (this.match("(")) {
                    var asyncArrow = maybeAsync && startToken.lineNumber === this.lookahead.lineNumber;
                    this.context.isBindingElement = false;
                    this.context.isAssignmentTarget = false;
                    var args = asyncArrow ? this.parseAsyncArguments() : this.parseArguments();
                    expr = this.finalize(this.startNode(startToken), new Node.CallExpression(expr, args));
                    if (asyncArrow && this.match("=>")) {
                      for (var i = 0; i < args.length; ++i) {
                        this.reinterpretExpressionAsPattern(args[i]);
                      }
                      expr = {
                        type: ArrowParameterPlaceHolder,
                        params: args,
                        async: true
                      };
                    }
                  } else if (this.match("[")) {
                    this.context.isBindingElement = false;
                    this.context.isAssignmentTarget = true;
                    this.expect("[");
                    var property = this.isolateCoverGrammar(this.parseExpression);
                    this.expect("]");
                    expr = this.finalize(this.startNode(startToken), new Node.ComputedMemberExpression(expr, property));
                  } else if (this.lookahead.type === 10 && this.lookahead.head) {
                    var quasi = this.parseTemplateLiteral();
                    expr = this.finalize(this.startNode(startToken), new Node.TaggedTemplateExpression(expr, quasi));
                  } else {
                    break;
                  }
                }
                this.context.allowIn = previousAllowIn;
                return expr;
              };
              Parser2.prototype.parseSuper = function() {
                var node = this.createNode();
                this.expectKeyword("super");
                if (!this.match("[") && !this.match(".")) {
                  this.throwUnexpectedToken(this.lookahead);
                }
                return this.finalize(node, new Node.Super());
              };
              Parser2.prototype.parseLeftHandSideExpression = function() {
                assert_1.assert(this.context.allowIn, "callee of new expression always allow in keyword.");
                var node = this.startNode(this.lookahead);
                var expr = this.matchKeyword("super") && this.context.inFunctionBody ? this.parseSuper() : this.inheritCoverGrammar(this.matchKeyword("new") ? this.parseNewExpression : this.parsePrimaryExpression);
                while (true) {
                  if (this.match("[")) {
                    this.context.isBindingElement = false;
                    this.context.isAssignmentTarget = true;
                    this.expect("[");
                    var property = this.isolateCoverGrammar(this.parseExpression);
                    this.expect("]");
                    expr = this.finalize(node, new Node.ComputedMemberExpression(expr, property));
                  } else if (this.match(".")) {
                    this.context.isBindingElement = false;
                    this.context.isAssignmentTarget = true;
                    this.expect(".");
                    var property = this.parseIdentifierName();
                    expr = this.finalize(node, new Node.StaticMemberExpression(expr, property));
                  } else if (this.lookahead.type === 10 && this.lookahead.head) {
                    var quasi = this.parseTemplateLiteral();
                    expr = this.finalize(node, new Node.TaggedTemplateExpression(expr, quasi));
                  } else {
                    break;
                  }
                }
                return expr;
              };
              Parser2.prototype.parseUpdateExpression = function() {
                var expr;
                var startToken = this.lookahead;
                if (this.match("++") || this.match("--")) {
                  var node = this.startNode(startToken);
                  var token = this.nextToken();
                  expr = this.inheritCoverGrammar(this.parseUnaryExpression);
                  if (this.context.strict && expr.type === syntax_1.Syntax.Identifier && this.scanner.isRestrictedWord(expr.name)) {
                    this.tolerateError(messages_1.Messages.StrictLHSPrefix);
                  }
                  if (!this.context.isAssignmentTarget) {
                    this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
                  }
                  var prefix = true;
                  expr = this.finalize(node, new Node.UpdateExpression(token.value, expr, prefix));
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                } else {
                  expr = this.inheritCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
                  if (!this.hasLineTerminator && this.lookahead.type === 7) {
                    if (this.match("++") || this.match("--")) {
                      if (this.context.strict && expr.type === syntax_1.Syntax.Identifier && this.scanner.isRestrictedWord(expr.name)) {
                        this.tolerateError(messages_1.Messages.StrictLHSPostfix);
                      }
                      if (!this.context.isAssignmentTarget) {
                        this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
                      }
                      this.context.isAssignmentTarget = false;
                      this.context.isBindingElement = false;
                      var operator = this.nextToken().value;
                      var prefix = false;
                      expr = this.finalize(this.startNode(startToken), new Node.UpdateExpression(operator, expr, prefix));
                    }
                  }
                }
                return expr;
              };
              Parser2.prototype.parseAwaitExpression = function() {
                var node = this.createNode();
                this.nextToken();
                var argument = this.parseUnaryExpression();
                return this.finalize(node, new Node.AwaitExpression(argument));
              };
              Parser2.prototype.parseUnaryExpression = function() {
                var expr;
                if (this.match("+") || this.match("-") || this.match("~") || this.match("!") || this.matchKeyword("delete") || this.matchKeyword("void") || this.matchKeyword("typeof")) {
                  var node = this.startNode(this.lookahead);
                  var token = this.nextToken();
                  expr = this.inheritCoverGrammar(this.parseUnaryExpression);
                  expr = this.finalize(node, new Node.UnaryExpression(token.value, expr));
                  if (this.context.strict && expr.operator === "delete" && expr.argument.type === syntax_1.Syntax.Identifier) {
                    this.tolerateError(messages_1.Messages.StrictDelete);
                  }
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                } else if (this.context.await && this.matchContextualKeyword("await")) {
                  expr = this.parseAwaitExpression();
                } else {
                  expr = this.parseUpdateExpression();
                }
                return expr;
              };
              Parser2.prototype.parseExponentiationExpression = function() {
                var startToken = this.lookahead;
                var expr = this.inheritCoverGrammar(this.parseUnaryExpression);
                if (expr.type !== syntax_1.Syntax.UnaryExpression && this.match("**")) {
                  this.nextToken();
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                  var left = expr;
                  var right = this.isolateCoverGrammar(this.parseExponentiationExpression);
                  expr = this.finalize(this.startNode(startToken), new Node.BinaryExpression("**", left, right));
                }
                return expr;
              };
              Parser2.prototype.binaryPrecedence = function(token) {
                var op = token.value;
                var precedence;
                if (token.type === 7) {
                  precedence = this.operatorPrecedence[op] || 0;
                } else if (token.type === 4) {
                  precedence = op === "instanceof" || this.context.allowIn && op === "in" ? 7 : 0;
                } else {
                  precedence = 0;
                }
                return precedence;
              };
              Parser2.prototype.parseBinaryExpression = function() {
                var startToken = this.lookahead;
                var expr = this.inheritCoverGrammar(this.parseExponentiationExpression);
                var token = this.lookahead;
                var prec = this.binaryPrecedence(token);
                if (prec > 0) {
                  this.nextToken();
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                  var markers = [startToken, this.lookahead];
                  var left = expr;
                  var right = this.isolateCoverGrammar(this.parseExponentiationExpression);
                  var stack = [left, token.value, right];
                  var precedences = [prec];
                  while (true) {
                    prec = this.binaryPrecedence(this.lookahead);
                    if (prec <= 0) {
                      break;
                    }
                    while (stack.length > 2 && prec <= precedences[precedences.length - 1]) {
                      right = stack.pop();
                      var operator = stack.pop();
                      precedences.pop();
                      left = stack.pop();
                      markers.pop();
                      var node = this.startNode(markers[markers.length - 1]);
                      stack.push(this.finalize(node, new Node.BinaryExpression(operator, left, right)));
                    }
                    stack.push(this.nextToken().value);
                    precedences.push(prec);
                    markers.push(this.lookahead);
                    stack.push(this.isolateCoverGrammar(this.parseExponentiationExpression));
                  }
                  var i = stack.length - 1;
                  expr = stack[i];
                  var lastMarker = markers.pop();
                  while (i > 1) {
                    var marker = markers.pop();
                    var lastLineStart = lastMarker && lastMarker.lineStart;
                    var node = this.startNode(marker, lastLineStart);
                    var operator = stack[i - 1];
                    expr = this.finalize(node, new Node.BinaryExpression(operator, stack[i - 2], expr));
                    i -= 2;
                    lastMarker = marker;
                  }
                }
                return expr;
              };
              Parser2.prototype.parseConditionalExpression = function() {
                var startToken = this.lookahead;
                var expr = this.inheritCoverGrammar(this.parseBinaryExpression);
                if (this.match("?")) {
                  this.nextToken();
                  var previousAllowIn = this.context.allowIn;
                  this.context.allowIn = true;
                  var consequent = this.isolateCoverGrammar(this.parseAssignmentExpression);
                  this.context.allowIn = previousAllowIn;
                  this.expect(":");
                  var alternate = this.isolateCoverGrammar(this.parseAssignmentExpression);
                  expr = this.finalize(this.startNode(startToken), new Node.ConditionalExpression(expr, consequent, alternate));
                  this.context.isAssignmentTarget = false;
                  this.context.isBindingElement = false;
                }
                return expr;
              };
              Parser2.prototype.checkPatternParam = function(options, param) {
                switch (param.type) {
                  case syntax_1.Syntax.Identifier:
                    this.validateParam(options, param, param.name);
                    break;
                  case syntax_1.Syntax.RestElement:
                    this.checkPatternParam(options, param.argument);
                    break;
                  case syntax_1.Syntax.AssignmentPattern:
                    this.checkPatternParam(options, param.left);
                    break;
                  case syntax_1.Syntax.ArrayPattern:
                    for (var i = 0; i < param.elements.length; i++) {
                      if (param.elements[i] !== null) {
                        this.checkPatternParam(options, param.elements[i]);
                      }
                    }
                    break;
                  case syntax_1.Syntax.ObjectPattern:
                    for (var i = 0; i < param.properties.length; i++) {
                      this.checkPatternParam(options, param.properties[i].value);
                    }
                    break;
                  default:
                    break;
                }
                options.simple = options.simple && param instanceof Node.Identifier;
              };
              Parser2.prototype.reinterpretAsCoverFormalsList = function(expr) {
                var params = [expr];
                var options;
                var asyncArrow = false;
                switch (expr.type) {
                  case syntax_1.Syntax.Identifier:
                    break;
                  case ArrowParameterPlaceHolder:
                    params = expr.params;
                    asyncArrow = expr.async;
                    break;
                  default:
                    return null;
                }
                options = {
                  simple: true,
                  paramSet: {}
                };
                for (var i = 0; i < params.length; ++i) {
                  var param = params[i];
                  if (param.type === syntax_1.Syntax.AssignmentPattern) {
                    if (param.right.type === syntax_1.Syntax.YieldExpression) {
                      if (param.right.argument) {
                        this.throwUnexpectedToken(this.lookahead);
                      }
                      param.right.type = syntax_1.Syntax.Identifier;
                      param.right.name = "yield";
                      delete param.right.argument;
                      delete param.right.delegate;
                    }
                  } else if (asyncArrow && param.type === syntax_1.Syntax.Identifier && param.name === "await") {
                    this.throwUnexpectedToken(this.lookahead);
                  }
                  this.checkPatternParam(options, param);
                  params[i] = param;
                }
                if (this.context.strict || !this.context.allowYield) {
                  for (var i = 0; i < params.length; ++i) {
                    var param = params[i];
                    if (param.type === syntax_1.Syntax.YieldExpression) {
                      this.throwUnexpectedToken(this.lookahead);
                    }
                  }
                }
                if (options.message === messages_1.Messages.StrictParamDupe) {
                  var token = this.context.strict ? options.stricted : options.firstRestricted;
                  this.throwUnexpectedToken(token, options.message);
                }
                return {
                  simple: options.simple,
                  params,
                  stricted: options.stricted,
                  firstRestricted: options.firstRestricted,
                  message: options.message
                };
              };
              Parser2.prototype.parseAssignmentExpression = function() {
                var expr;
                if (!this.context.allowYield && this.matchKeyword("yield")) {
                  expr = this.parseYieldExpression();
                } else {
                  var startToken = this.lookahead;
                  var token = startToken;
                  expr = this.parseConditionalExpression();
                  if (token.type === 3 && token.lineNumber === this.lookahead.lineNumber && token.value === "async") {
                    if (this.lookahead.type === 3 || this.matchKeyword("yield")) {
                      var arg = this.parsePrimaryExpression();
                      this.reinterpretExpressionAsPattern(arg);
                      expr = {
                        type: ArrowParameterPlaceHolder,
                        params: [arg],
                        async: true
                      };
                    }
                  }
                  if (expr.type === ArrowParameterPlaceHolder || this.match("=>")) {
                    this.context.isAssignmentTarget = false;
                    this.context.isBindingElement = false;
                    var isAsync = expr.async;
                    var list = this.reinterpretAsCoverFormalsList(expr);
                    if (list) {
                      if (this.hasLineTerminator) {
                        this.tolerateUnexpectedToken(this.lookahead);
                      }
                      this.context.firstCoverInitializedNameError = null;
                      var previousStrict = this.context.strict;
                      var previousAllowStrictDirective = this.context.allowStrictDirective;
                      this.context.allowStrictDirective = list.simple;
                      var previousAllowYield = this.context.allowYield;
                      var previousAwait = this.context.await;
                      this.context.allowYield = true;
                      this.context.await = isAsync;
                      var node = this.startNode(startToken);
                      this.expect("=>");
                      var body = void 0;
                      if (this.match("{")) {
                        var previousAllowIn = this.context.allowIn;
                        this.context.allowIn = true;
                        body = this.parseFunctionSourceElements();
                        this.context.allowIn = previousAllowIn;
                      } else {
                        body = this.isolateCoverGrammar(this.parseAssignmentExpression);
                      }
                      var expression = body.type !== syntax_1.Syntax.BlockStatement;
                      if (this.context.strict && list.firstRestricted) {
                        this.throwUnexpectedToken(list.firstRestricted, list.message);
                      }
                      if (this.context.strict && list.stricted) {
                        this.tolerateUnexpectedToken(list.stricted, list.message);
                      }
                      expr = isAsync ? this.finalize(node, new Node.AsyncArrowFunctionExpression(list.params, body, expression)) : this.finalize(node, new Node.ArrowFunctionExpression(list.params, body, expression));
                      this.context.strict = previousStrict;
                      this.context.allowStrictDirective = previousAllowStrictDirective;
                      this.context.allowYield = previousAllowYield;
                      this.context.await = previousAwait;
                    }
                  } else {
                    if (this.matchAssign()) {
                      if (!this.context.isAssignmentTarget) {
                        this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
                      }
                      if (this.context.strict && expr.type === syntax_1.Syntax.Identifier) {
                        var id = expr;
                        if (this.scanner.isRestrictedWord(id.name)) {
                          this.tolerateUnexpectedToken(token, messages_1.Messages.StrictLHSAssignment);
                        }
                        if (this.scanner.isStrictModeReservedWord(id.name)) {
                          this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
                        }
                      }
                      if (!this.match("=")) {
                        this.context.isAssignmentTarget = false;
                        this.context.isBindingElement = false;
                      } else {
                        this.reinterpretExpressionAsPattern(expr);
                      }
                      token = this.nextToken();
                      var operator = token.value;
                      var right = this.isolateCoverGrammar(this.parseAssignmentExpression);
                      expr = this.finalize(this.startNode(startToken), new Node.AssignmentExpression(operator, expr, right));
                      this.context.firstCoverInitializedNameError = null;
                    }
                  }
                }
                return expr;
              };
              Parser2.prototype.parseExpression = function() {
                var startToken = this.lookahead;
                var expr = this.isolateCoverGrammar(this.parseAssignmentExpression);
                if (this.match(",")) {
                  var expressions = [];
                  expressions.push(expr);
                  while (this.lookahead.type !== 2) {
                    if (!this.match(",")) {
                      break;
                    }
                    this.nextToken();
                    expressions.push(this.isolateCoverGrammar(this.parseAssignmentExpression));
                  }
                  expr = this.finalize(this.startNode(startToken), new Node.SequenceExpression(expressions));
                }
                return expr;
              };
              Parser2.prototype.parseStatementListItem = function() {
                var statement;
                this.context.isAssignmentTarget = true;
                this.context.isBindingElement = true;
                if (this.lookahead.type === 4) {
                  switch (this.lookahead.value) {
                    case "export":
                      if (!this.context.isModule) {
                        this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.IllegalExportDeclaration);
                      }
                      statement = this.parseExportDeclaration();
                      break;
                    case "import":
                      if (!this.context.isModule) {
                        this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.IllegalImportDeclaration);
                      }
                      statement = this.parseImportDeclaration();
                      break;
                    case "const":
                      statement = this.parseLexicalDeclaration({ inFor: false });
                      break;
                    case "function":
                      statement = this.parseFunctionDeclaration();
                      break;
                    case "class":
                      statement = this.parseClassDeclaration();
                      break;
                    case "let":
                      statement = this.isLexicalDeclaration() ? this.parseLexicalDeclaration({ inFor: false }) : this.parseStatement();
                      break;
                    default:
                      statement = this.parseStatement();
                      break;
                  }
                } else {
                  statement = this.parseStatement();
                }
                return statement;
              };
              Parser2.prototype.parseBlock = function() {
                var node = this.createNode();
                this.expect("{");
                var block = [];
                while (true) {
                  if (this.match("}")) {
                    break;
                  }
                  block.push(this.parseStatementListItem());
                }
                this.expect("}");
                return this.finalize(node, new Node.BlockStatement(block));
              };
              Parser2.prototype.parseLexicalBinding = function(kind, options) {
                var node = this.createNode();
                var params = [];
                var id = this.parsePattern(params, kind);
                if (this.context.strict && id.type === syntax_1.Syntax.Identifier) {
                  if (this.scanner.isRestrictedWord(id.name)) {
                    this.tolerateError(messages_1.Messages.StrictVarName);
                  }
                }
                var init = null;
                if (kind === "const") {
                  if (!this.matchKeyword("in") && !this.matchContextualKeyword("of")) {
                    if (this.match("=")) {
                      this.nextToken();
                      init = this.isolateCoverGrammar(this.parseAssignmentExpression);
                    } else {
                      this.throwError(messages_1.Messages.DeclarationMissingInitializer, "const");
                    }
                  }
                } else if (!options.inFor && id.type !== syntax_1.Syntax.Identifier || this.match("=")) {
                  this.expect("=");
                  init = this.isolateCoverGrammar(this.parseAssignmentExpression);
                }
                return this.finalize(node, new Node.VariableDeclarator(id, init));
              };
              Parser2.prototype.parseBindingList = function(kind, options) {
                var list = [this.parseLexicalBinding(kind, options)];
                while (this.match(",")) {
                  this.nextToken();
                  list.push(this.parseLexicalBinding(kind, options));
                }
                return list;
              };
              Parser2.prototype.isLexicalDeclaration = function() {
                var state = this.scanner.saveState();
                this.scanner.scanComments();
                var next = this.scanner.lex();
                this.scanner.restoreState(state);
                return next.type === 3 || next.type === 7 && next.value === "[" || next.type === 7 && next.value === "{" || next.type === 4 && next.value === "let" || next.type === 4 && next.value === "yield";
              };
              Parser2.prototype.parseLexicalDeclaration = function(options) {
                var node = this.createNode();
                var kind = this.nextToken().value;
                assert_1.assert(kind === "let" || kind === "const", "Lexical declaration must be either let or const");
                var declarations = this.parseBindingList(kind, options);
                this.consumeSemicolon();
                return this.finalize(node, new Node.VariableDeclaration(declarations, kind));
              };
              Parser2.prototype.parseBindingRestElement = function(params, kind) {
                var node = this.createNode();
                this.expect("...");
                var arg = this.parsePattern(params, kind);
                return this.finalize(node, new Node.RestElement(arg));
              };
              Parser2.prototype.parseArrayPattern = function(params, kind) {
                var node = this.createNode();
                this.expect("[");
                var elements = [];
                while (!this.match("]")) {
                  if (this.match(",")) {
                    this.nextToken();
                    elements.push(null);
                  } else {
                    if (this.match("...")) {
                      elements.push(this.parseBindingRestElement(params, kind));
                      break;
                    } else {
                      elements.push(this.parsePatternWithDefault(params, kind));
                    }
                    if (!this.match("]")) {
                      this.expect(",");
                    }
                  }
                }
                this.expect("]");
                return this.finalize(node, new Node.ArrayPattern(elements));
              };
              Parser2.prototype.parsePropertyPattern = function(params, kind) {
                var node = this.createNode();
                var computed = false;
                var shorthand = false;
                var method = false;
                var key;
                var value;
                if (this.lookahead.type === 3) {
                  var keyToken = this.lookahead;
                  key = this.parseVariableIdentifier();
                  var init = this.finalize(node, new Node.Identifier(keyToken.value));
                  if (this.match("=")) {
                    params.push(keyToken);
                    shorthand = true;
                    this.nextToken();
                    var expr = this.parseAssignmentExpression();
                    value = this.finalize(this.startNode(keyToken), new Node.AssignmentPattern(init, expr));
                  } else if (!this.match(":")) {
                    params.push(keyToken);
                    shorthand = true;
                    value = init;
                  } else {
                    this.expect(":");
                    value = this.parsePatternWithDefault(params, kind);
                  }
                } else {
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  this.expect(":");
                  value = this.parsePatternWithDefault(params, kind);
                }
                return this.finalize(node, new Node.Property("init", key, computed, value, method, shorthand));
              };
              Parser2.prototype.parseObjectPattern = function(params, kind) {
                var node = this.createNode();
                var properties = [];
                this.expect("{");
                while (!this.match("}")) {
                  properties.push(this.parsePropertyPattern(params, kind));
                  if (!this.match("}")) {
                    this.expect(",");
                  }
                }
                this.expect("}");
                return this.finalize(node, new Node.ObjectPattern(properties));
              };
              Parser2.prototype.parsePattern = function(params, kind) {
                var pattern;
                if (this.match("[")) {
                  pattern = this.parseArrayPattern(params, kind);
                } else if (this.match("{")) {
                  pattern = this.parseObjectPattern(params, kind);
                } else {
                  if (this.matchKeyword("let") && (kind === "const" || kind === "let")) {
                    this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.LetInLexicalBinding);
                  }
                  params.push(this.lookahead);
                  pattern = this.parseVariableIdentifier(kind);
                }
                return pattern;
              };
              Parser2.prototype.parsePatternWithDefault = function(params, kind) {
                var startToken = this.lookahead;
                var pattern = this.parsePattern(params, kind);
                if (this.match("=")) {
                  this.nextToken();
                  var previousAllowYield = this.context.allowYield;
                  this.context.allowYield = true;
                  var right = this.isolateCoverGrammar(this.parseAssignmentExpression);
                  this.context.allowYield = previousAllowYield;
                  pattern = this.finalize(this.startNode(startToken), new Node.AssignmentPattern(pattern, right));
                }
                return pattern;
              };
              Parser2.prototype.parseVariableIdentifier = function(kind) {
                var node = this.createNode();
                var token = this.nextToken();
                if (token.type === 4 && token.value === "yield") {
                  if (this.context.strict) {
                    this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
                  } else if (!this.context.allowYield) {
                    this.throwUnexpectedToken(token);
                  }
                } else if (token.type !== 3) {
                  if (this.context.strict && token.type === 4 && this.scanner.isStrictModeReservedWord(token.value)) {
                    this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
                  } else {
                    if (this.context.strict || token.value !== "let" || kind !== "var") {
                      this.throwUnexpectedToken(token);
                    }
                  }
                } else if ((this.context.isModule || this.context.await) && token.type === 3 && token.value === "await") {
                  this.tolerateUnexpectedToken(token);
                }
                return this.finalize(node, new Node.Identifier(token.value));
              };
              Parser2.prototype.parseVariableDeclaration = function(options) {
                var node = this.createNode();
                var params = [];
                var id = this.parsePattern(params, "var");
                if (this.context.strict && id.type === syntax_1.Syntax.Identifier) {
                  if (this.scanner.isRestrictedWord(id.name)) {
                    this.tolerateError(messages_1.Messages.StrictVarName);
                  }
                }
                var init = null;
                if (this.match("=")) {
                  this.nextToken();
                  init = this.isolateCoverGrammar(this.parseAssignmentExpression);
                } else if (id.type !== syntax_1.Syntax.Identifier && !options.inFor) {
                  this.expect("=");
                }
                return this.finalize(node, new Node.VariableDeclarator(id, init));
              };
              Parser2.prototype.parseVariableDeclarationList = function(options) {
                var opt = { inFor: options.inFor };
                var list = [];
                list.push(this.parseVariableDeclaration(opt));
                while (this.match(",")) {
                  this.nextToken();
                  list.push(this.parseVariableDeclaration(opt));
                }
                return list;
              };
              Parser2.prototype.parseVariableStatement = function() {
                var node = this.createNode();
                this.expectKeyword("var");
                var declarations = this.parseVariableDeclarationList({ inFor: false });
                this.consumeSemicolon();
                return this.finalize(node, new Node.VariableDeclaration(declarations, "var"));
              };
              Parser2.prototype.parseEmptyStatement = function() {
                var node = this.createNode();
                this.expect(";");
                return this.finalize(node, new Node.EmptyStatement());
              };
              Parser2.prototype.parseExpressionStatement = function() {
                var node = this.createNode();
                var expr = this.parseExpression();
                this.consumeSemicolon();
                return this.finalize(node, new Node.ExpressionStatement(expr));
              };
              Parser2.prototype.parseIfClause = function() {
                if (this.context.strict && this.matchKeyword("function")) {
                  this.tolerateError(messages_1.Messages.StrictFunction);
                }
                return this.parseStatement();
              };
              Parser2.prototype.parseIfStatement = function() {
                var node = this.createNode();
                var consequent;
                var alternate = null;
                this.expectKeyword("if");
                this.expect("(");
                var test = this.parseExpression();
                if (!this.match(")") && this.config.tolerant) {
                  this.tolerateUnexpectedToken(this.nextToken());
                  consequent = this.finalize(this.createNode(), new Node.EmptyStatement());
                } else {
                  this.expect(")");
                  consequent = this.parseIfClause();
                  if (this.matchKeyword("else")) {
                    this.nextToken();
                    alternate = this.parseIfClause();
                  }
                }
                return this.finalize(node, new Node.IfStatement(test, consequent, alternate));
              };
              Parser2.prototype.parseDoWhileStatement = function() {
                var node = this.createNode();
                this.expectKeyword("do");
                var previousInIteration = this.context.inIteration;
                this.context.inIteration = true;
                var body = this.parseStatement();
                this.context.inIteration = previousInIteration;
                this.expectKeyword("while");
                this.expect("(");
                var test = this.parseExpression();
                if (!this.match(")") && this.config.tolerant) {
                  this.tolerateUnexpectedToken(this.nextToken());
                } else {
                  this.expect(")");
                  if (this.match(";")) {
                    this.nextToken();
                  }
                }
                return this.finalize(node, new Node.DoWhileStatement(body, test));
              };
              Parser2.prototype.parseWhileStatement = function() {
                var node = this.createNode();
                var body;
                this.expectKeyword("while");
                this.expect("(");
                var test = this.parseExpression();
                if (!this.match(")") && this.config.tolerant) {
                  this.tolerateUnexpectedToken(this.nextToken());
                  body = this.finalize(this.createNode(), new Node.EmptyStatement());
                } else {
                  this.expect(")");
                  var previousInIteration = this.context.inIteration;
                  this.context.inIteration = true;
                  body = this.parseStatement();
                  this.context.inIteration = previousInIteration;
                }
                return this.finalize(node, new Node.WhileStatement(test, body));
              };
              Parser2.prototype.parseForStatement = function() {
                var init = null;
                var test = null;
                var update = null;
                var forIn = true;
                var left, right;
                var node = this.createNode();
                this.expectKeyword("for");
                this.expect("(");
                if (this.match(";")) {
                  this.nextToken();
                } else {
                  if (this.matchKeyword("var")) {
                    init = this.createNode();
                    this.nextToken();
                    var previousAllowIn = this.context.allowIn;
                    this.context.allowIn = false;
                    var declarations = this.parseVariableDeclarationList({ inFor: true });
                    this.context.allowIn = previousAllowIn;
                    if (declarations.length === 1 && this.matchKeyword("in")) {
                      var decl = declarations[0];
                      if (decl.init && (decl.id.type === syntax_1.Syntax.ArrayPattern || decl.id.type === syntax_1.Syntax.ObjectPattern || this.context.strict)) {
                        this.tolerateError(messages_1.Messages.ForInOfLoopInitializer, "for-in");
                      }
                      init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
                      this.nextToken();
                      left = init;
                      right = this.parseExpression();
                      init = null;
                    } else if (declarations.length === 1 && declarations[0].init === null && this.matchContextualKeyword("of")) {
                      init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
                      this.nextToken();
                      left = init;
                      right = this.parseAssignmentExpression();
                      init = null;
                      forIn = false;
                    } else {
                      init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
                      this.expect(";");
                    }
                  } else if (this.matchKeyword("const") || this.matchKeyword("let")) {
                    init = this.createNode();
                    var kind = this.nextToken().value;
                    if (!this.context.strict && this.lookahead.value === "in") {
                      init = this.finalize(init, new Node.Identifier(kind));
                      this.nextToken();
                      left = init;
                      right = this.parseExpression();
                      init = null;
                    } else {
                      var previousAllowIn = this.context.allowIn;
                      this.context.allowIn = false;
                      var declarations = this.parseBindingList(kind, { inFor: true });
                      this.context.allowIn = previousAllowIn;
                      if (declarations.length === 1 && declarations[0].init === null && this.matchKeyword("in")) {
                        init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
                        this.nextToken();
                        left = init;
                        right = this.parseExpression();
                        init = null;
                      } else if (declarations.length === 1 && declarations[0].init === null && this.matchContextualKeyword("of")) {
                        init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
                        this.nextToken();
                        left = init;
                        right = this.parseAssignmentExpression();
                        init = null;
                        forIn = false;
                      } else {
                        this.consumeSemicolon();
                        init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
                      }
                    }
                  } else {
                    var initStartToken = this.lookahead;
                    var previousAllowIn = this.context.allowIn;
                    this.context.allowIn = false;
                    init = this.inheritCoverGrammar(this.parseAssignmentExpression);
                    this.context.allowIn = previousAllowIn;
                    if (this.matchKeyword("in")) {
                      if (!this.context.isAssignmentTarget || init.type === syntax_1.Syntax.AssignmentExpression) {
                        this.tolerateError(messages_1.Messages.InvalidLHSInForIn);
                      }
                      this.nextToken();
                      this.reinterpretExpressionAsPattern(init);
                      left = init;
                      right = this.parseExpression();
                      init = null;
                    } else if (this.matchContextualKeyword("of")) {
                      if (!this.context.isAssignmentTarget || init.type === syntax_1.Syntax.AssignmentExpression) {
                        this.tolerateError(messages_1.Messages.InvalidLHSInForLoop);
                      }
                      this.nextToken();
                      this.reinterpretExpressionAsPattern(init);
                      left = init;
                      right = this.parseAssignmentExpression();
                      init = null;
                      forIn = false;
                    } else {
                      if (this.match(",")) {
                        var initSeq = [init];
                        while (this.match(",")) {
                          this.nextToken();
                          initSeq.push(this.isolateCoverGrammar(this.parseAssignmentExpression));
                        }
                        init = this.finalize(this.startNode(initStartToken), new Node.SequenceExpression(initSeq));
                      }
                      this.expect(";");
                    }
                  }
                }
                if (typeof left === "undefined") {
                  if (!this.match(";")) {
                    test = this.parseExpression();
                  }
                  this.expect(";");
                  if (!this.match(")")) {
                    update = this.parseExpression();
                  }
                }
                var body;
                if (!this.match(")") && this.config.tolerant) {
                  this.tolerateUnexpectedToken(this.nextToken());
                  body = this.finalize(this.createNode(), new Node.EmptyStatement());
                } else {
                  this.expect(")");
                  var previousInIteration = this.context.inIteration;
                  this.context.inIteration = true;
                  body = this.isolateCoverGrammar(this.parseStatement);
                  this.context.inIteration = previousInIteration;
                }
                return typeof left === "undefined" ? this.finalize(node, new Node.ForStatement(init, test, update, body)) : forIn ? this.finalize(node, new Node.ForInStatement(left, right, body)) : this.finalize(node, new Node.ForOfStatement(left, right, body));
              };
              Parser2.prototype.parseContinueStatement = function() {
                var node = this.createNode();
                this.expectKeyword("continue");
                var label = null;
                if (this.lookahead.type === 3 && !this.hasLineTerminator) {
                  var id = this.parseVariableIdentifier();
                  label = id;
                  var key = "$" + id.name;
                  if (!Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) {
                    this.throwError(messages_1.Messages.UnknownLabel, id.name);
                  }
                }
                this.consumeSemicolon();
                if (label === null && !this.context.inIteration) {
                  this.throwError(messages_1.Messages.IllegalContinue);
                }
                return this.finalize(node, new Node.ContinueStatement(label));
              };
              Parser2.prototype.parseBreakStatement = function() {
                var node = this.createNode();
                this.expectKeyword("break");
                var label = null;
                if (this.lookahead.type === 3 && !this.hasLineTerminator) {
                  var id = this.parseVariableIdentifier();
                  var key = "$" + id.name;
                  if (!Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) {
                    this.throwError(messages_1.Messages.UnknownLabel, id.name);
                  }
                  label = id;
                }
                this.consumeSemicolon();
                if (label === null && !this.context.inIteration && !this.context.inSwitch) {
                  this.throwError(messages_1.Messages.IllegalBreak);
                }
                return this.finalize(node, new Node.BreakStatement(label));
              };
              Parser2.prototype.parseReturnStatement = function() {
                if (!this.context.inFunctionBody) {
                  this.tolerateError(messages_1.Messages.IllegalReturn);
                }
                var node = this.createNode();
                this.expectKeyword("return");
                var hasArgument = !this.match(";") && !this.match("}") && !this.hasLineTerminator && this.lookahead.type !== 2 || this.lookahead.type === 8 || this.lookahead.type === 10;
                var argument = hasArgument ? this.parseExpression() : null;
                this.consumeSemicolon();
                return this.finalize(node, new Node.ReturnStatement(argument));
              };
              Parser2.prototype.parseWithStatement = function() {
                if (this.context.strict) {
                  this.tolerateError(messages_1.Messages.StrictModeWith);
                }
                var node = this.createNode();
                var body;
                this.expectKeyword("with");
                this.expect("(");
                var object = this.parseExpression();
                if (!this.match(")") && this.config.tolerant) {
                  this.tolerateUnexpectedToken(this.nextToken());
                  body = this.finalize(this.createNode(), new Node.EmptyStatement());
                } else {
                  this.expect(")");
                  body = this.parseStatement();
                }
                return this.finalize(node, new Node.WithStatement(object, body));
              };
              Parser2.prototype.parseSwitchCase = function() {
                var node = this.createNode();
                var test;
                if (this.matchKeyword("default")) {
                  this.nextToken();
                  test = null;
                } else {
                  this.expectKeyword("case");
                  test = this.parseExpression();
                }
                this.expect(":");
                var consequent = [];
                while (true) {
                  if (this.match("}") || this.matchKeyword("default") || this.matchKeyword("case")) {
                    break;
                  }
                  consequent.push(this.parseStatementListItem());
                }
                return this.finalize(node, new Node.SwitchCase(test, consequent));
              };
              Parser2.prototype.parseSwitchStatement = function() {
                var node = this.createNode();
                this.expectKeyword("switch");
                this.expect("(");
                var discriminant = this.parseExpression();
                this.expect(")");
                var previousInSwitch = this.context.inSwitch;
                this.context.inSwitch = true;
                var cases = [];
                var defaultFound = false;
                this.expect("{");
                while (true) {
                  if (this.match("}")) {
                    break;
                  }
                  var clause = this.parseSwitchCase();
                  if (clause.test === null) {
                    if (defaultFound) {
                      this.throwError(messages_1.Messages.MultipleDefaultsInSwitch);
                    }
                    defaultFound = true;
                  }
                  cases.push(clause);
                }
                this.expect("}");
                this.context.inSwitch = previousInSwitch;
                return this.finalize(node, new Node.SwitchStatement(discriminant, cases));
              };
              Parser2.prototype.parseLabelledStatement = function() {
                var node = this.createNode();
                var expr = this.parseExpression();
                var statement;
                if (expr.type === syntax_1.Syntax.Identifier && this.match(":")) {
                  this.nextToken();
                  var id = expr;
                  var key = "$" + id.name;
                  if (Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) {
                    this.throwError(messages_1.Messages.Redeclaration, "Label", id.name);
                  }
                  this.context.labelSet[key] = true;
                  var body = void 0;
                  if (this.matchKeyword("class")) {
                    this.tolerateUnexpectedToken(this.lookahead);
                    body = this.parseClassDeclaration();
                  } else if (this.matchKeyword("function")) {
                    var token = this.lookahead;
                    var declaration = this.parseFunctionDeclaration();
                    if (this.context.strict) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunction);
                    } else if (declaration.generator) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.GeneratorInLegacyContext);
                    }
                    body = declaration;
                  } else {
                    body = this.parseStatement();
                  }
                  delete this.context.labelSet[key];
                  statement = new Node.LabeledStatement(id, body);
                } else {
                  this.consumeSemicolon();
                  statement = new Node.ExpressionStatement(expr);
                }
                return this.finalize(node, statement);
              };
              Parser2.prototype.parseThrowStatement = function() {
                var node = this.createNode();
                this.expectKeyword("throw");
                if (this.hasLineTerminator) {
                  this.throwError(messages_1.Messages.NewlineAfterThrow);
                }
                var argument = this.parseExpression();
                this.consumeSemicolon();
                return this.finalize(node, new Node.ThrowStatement(argument));
              };
              Parser2.prototype.parseCatchClause = function() {
                var node = this.createNode();
                this.expectKeyword("catch");
                this.expect("(");
                if (this.match(")")) {
                  this.throwUnexpectedToken(this.lookahead);
                }
                var params = [];
                var param = this.parsePattern(params);
                var paramMap = {};
                for (var i = 0; i < params.length; i++) {
                  var key = "$" + params[i].value;
                  if (Object.prototype.hasOwnProperty.call(paramMap, key)) {
                    this.tolerateError(messages_1.Messages.DuplicateBinding, params[i].value);
                  }
                  paramMap[key] = true;
                }
                if (this.context.strict && param.type === syntax_1.Syntax.Identifier) {
                  if (this.scanner.isRestrictedWord(param.name)) {
                    this.tolerateError(messages_1.Messages.StrictCatchVariable);
                  }
                }
                this.expect(")");
                var body = this.parseBlock();
                return this.finalize(node, new Node.CatchClause(param, body));
              };
              Parser2.prototype.parseFinallyClause = function() {
                this.expectKeyword("finally");
                return this.parseBlock();
              };
              Parser2.prototype.parseTryStatement = function() {
                var node = this.createNode();
                this.expectKeyword("try");
                var block = this.parseBlock();
                var handler = this.matchKeyword("catch") ? this.parseCatchClause() : null;
                var finalizer = this.matchKeyword("finally") ? this.parseFinallyClause() : null;
                if (!handler && !finalizer) {
                  this.throwError(messages_1.Messages.NoCatchOrFinally);
                }
                return this.finalize(node, new Node.TryStatement(block, handler, finalizer));
              };
              Parser2.prototype.parseDebuggerStatement = function() {
                var node = this.createNode();
                this.expectKeyword("debugger");
                this.consumeSemicolon();
                return this.finalize(node, new Node.DebuggerStatement());
              };
              Parser2.prototype.parseStatement = function() {
                var statement;
                switch (this.lookahead.type) {
                  case 1:
                  case 5:
                  case 6:
                  case 8:
                  case 10:
                  case 9:
                    statement = this.parseExpressionStatement();
                    break;
                  case 7:
                    var value = this.lookahead.value;
                    if (value === "{") {
                      statement = this.parseBlock();
                    } else if (value === "(") {
                      statement = this.parseExpressionStatement();
                    } else if (value === ";") {
                      statement = this.parseEmptyStatement();
                    } else {
                      statement = this.parseExpressionStatement();
                    }
                    break;
                  case 3:
                    statement = this.matchAsyncFunction() ? this.parseFunctionDeclaration() : this.parseLabelledStatement();
                    break;
                  case 4:
                    switch (this.lookahead.value) {
                      case "break":
                        statement = this.parseBreakStatement();
                        break;
                      case "continue":
                        statement = this.parseContinueStatement();
                        break;
                      case "debugger":
                        statement = this.parseDebuggerStatement();
                        break;
                      case "do":
                        statement = this.parseDoWhileStatement();
                        break;
                      case "for":
                        statement = this.parseForStatement();
                        break;
                      case "function":
                        statement = this.parseFunctionDeclaration();
                        break;
                      case "if":
                        statement = this.parseIfStatement();
                        break;
                      case "return":
                        statement = this.parseReturnStatement();
                        break;
                      case "switch":
                        statement = this.parseSwitchStatement();
                        break;
                      case "throw":
                        statement = this.parseThrowStatement();
                        break;
                      case "try":
                        statement = this.parseTryStatement();
                        break;
                      case "var":
                        statement = this.parseVariableStatement();
                        break;
                      case "while":
                        statement = this.parseWhileStatement();
                        break;
                      case "with":
                        statement = this.parseWithStatement();
                        break;
                      default:
                        statement = this.parseExpressionStatement();
                        break;
                    }
                    break;
                  default:
                    statement = this.throwUnexpectedToken(this.lookahead);
                }
                return statement;
              };
              Parser2.prototype.parseFunctionSourceElements = function() {
                var node = this.createNode();
                this.expect("{");
                var body = this.parseDirectivePrologues();
                var previousLabelSet = this.context.labelSet;
                var previousInIteration = this.context.inIteration;
                var previousInSwitch = this.context.inSwitch;
                var previousInFunctionBody = this.context.inFunctionBody;
                this.context.labelSet = {};
                this.context.inIteration = false;
                this.context.inSwitch = false;
                this.context.inFunctionBody = true;
                while (this.lookahead.type !== 2) {
                  if (this.match("}")) {
                    break;
                  }
                  body.push(this.parseStatementListItem());
                }
                this.expect("}");
                this.context.labelSet = previousLabelSet;
                this.context.inIteration = previousInIteration;
                this.context.inSwitch = previousInSwitch;
                this.context.inFunctionBody = previousInFunctionBody;
                return this.finalize(node, new Node.BlockStatement(body));
              };
              Parser2.prototype.validateParam = function(options, param, name) {
                var key = "$" + name;
                if (this.context.strict) {
                  if (this.scanner.isRestrictedWord(name)) {
                    options.stricted = param;
                    options.message = messages_1.Messages.StrictParamName;
                  }
                  if (Object.prototype.hasOwnProperty.call(options.paramSet, key)) {
                    options.stricted = param;
                    options.message = messages_1.Messages.StrictParamDupe;
                  }
                } else if (!options.firstRestricted) {
                  if (this.scanner.isRestrictedWord(name)) {
                    options.firstRestricted = param;
                    options.message = messages_1.Messages.StrictParamName;
                  } else if (this.scanner.isStrictModeReservedWord(name)) {
                    options.firstRestricted = param;
                    options.message = messages_1.Messages.StrictReservedWord;
                  } else if (Object.prototype.hasOwnProperty.call(options.paramSet, key)) {
                    options.stricted = param;
                    options.message = messages_1.Messages.StrictParamDupe;
                  }
                }
                if (typeof Object.defineProperty === "function") {
                  Object.defineProperty(options.paramSet, key, { value: true, enumerable: true, writable: true, configurable: true });
                } else {
                  options.paramSet[key] = true;
                }
              };
              Parser2.prototype.parseRestElement = function(params) {
                var node = this.createNode();
                this.expect("...");
                var arg = this.parsePattern(params);
                if (this.match("=")) {
                  this.throwError(messages_1.Messages.DefaultRestParameter);
                }
                if (!this.match(")")) {
                  this.throwError(messages_1.Messages.ParameterAfterRestParameter);
                }
                return this.finalize(node, new Node.RestElement(arg));
              };
              Parser2.prototype.parseFormalParameter = function(options) {
                var params = [];
                var param = this.match("...") ? this.parseRestElement(params) : this.parsePatternWithDefault(params);
                for (var i = 0; i < params.length; i++) {
                  this.validateParam(options, params[i], params[i].value);
                }
                options.simple = options.simple && param instanceof Node.Identifier;
                options.params.push(param);
              };
              Parser2.prototype.parseFormalParameters = function(firstRestricted) {
                var options;
                options = {
                  simple: true,
                  params: [],
                  firstRestricted
                };
                this.expect("(");
                if (!this.match(")")) {
                  options.paramSet = {};
                  while (this.lookahead.type !== 2) {
                    this.parseFormalParameter(options);
                    if (this.match(")")) {
                      break;
                    }
                    this.expect(",");
                    if (this.match(")")) {
                      break;
                    }
                  }
                }
                this.expect(")");
                return {
                  simple: options.simple,
                  params: options.params,
                  stricted: options.stricted,
                  firstRestricted: options.firstRestricted,
                  message: options.message
                };
              };
              Parser2.prototype.matchAsyncFunction = function() {
                var match = this.matchContextualKeyword("async");
                if (match) {
                  var state = this.scanner.saveState();
                  this.scanner.scanComments();
                  var next = this.scanner.lex();
                  this.scanner.restoreState(state);
                  match = state.lineNumber === next.lineNumber && next.type === 4 && next.value === "function";
                }
                return match;
              };
              Parser2.prototype.parseFunctionDeclaration = function(identifierIsOptional) {
                var node = this.createNode();
                var isAsync = this.matchContextualKeyword("async");
                if (isAsync) {
                  this.nextToken();
                }
                this.expectKeyword("function");
                var isGenerator = isAsync ? false : this.match("*");
                if (isGenerator) {
                  this.nextToken();
                }
                var message;
                var id = null;
                var firstRestricted = null;
                if (!identifierIsOptional || !this.match("(")) {
                  var token = this.lookahead;
                  id = this.parseVariableIdentifier();
                  if (this.context.strict) {
                    if (this.scanner.isRestrictedWord(token.value)) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunctionName);
                    }
                  } else {
                    if (this.scanner.isRestrictedWord(token.value)) {
                      firstRestricted = token;
                      message = messages_1.Messages.StrictFunctionName;
                    } else if (this.scanner.isStrictModeReservedWord(token.value)) {
                      firstRestricted = token;
                      message = messages_1.Messages.StrictReservedWord;
                    }
                  }
                }
                var previousAllowAwait = this.context.await;
                var previousAllowYield = this.context.allowYield;
                this.context.await = isAsync;
                this.context.allowYield = !isGenerator;
                var formalParameters = this.parseFormalParameters(firstRestricted);
                var params = formalParameters.params;
                var stricted = formalParameters.stricted;
                firstRestricted = formalParameters.firstRestricted;
                if (formalParameters.message) {
                  message = formalParameters.message;
                }
                var previousStrict = this.context.strict;
                var previousAllowStrictDirective = this.context.allowStrictDirective;
                this.context.allowStrictDirective = formalParameters.simple;
                var body = this.parseFunctionSourceElements();
                if (this.context.strict && firstRestricted) {
                  this.throwUnexpectedToken(firstRestricted, message);
                }
                if (this.context.strict && stricted) {
                  this.tolerateUnexpectedToken(stricted, message);
                }
                this.context.strict = previousStrict;
                this.context.allowStrictDirective = previousAllowStrictDirective;
                this.context.await = previousAllowAwait;
                this.context.allowYield = previousAllowYield;
                return isAsync ? this.finalize(node, new Node.AsyncFunctionDeclaration(id, params, body)) : this.finalize(node, new Node.FunctionDeclaration(id, params, body, isGenerator));
              };
              Parser2.prototype.parseFunctionExpression = function() {
                var node = this.createNode();
                var isAsync = this.matchContextualKeyword("async");
                if (isAsync) {
                  this.nextToken();
                }
                this.expectKeyword("function");
                var isGenerator = isAsync ? false : this.match("*");
                if (isGenerator) {
                  this.nextToken();
                }
                var message;
                var id = null;
                var firstRestricted;
                var previousAllowAwait = this.context.await;
                var previousAllowYield = this.context.allowYield;
                this.context.await = isAsync;
                this.context.allowYield = !isGenerator;
                if (!this.match("(")) {
                  var token = this.lookahead;
                  id = !this.context.strict && !isGenerator && this.matchKeyword("yield") ? this.parseIdentifierName() : this.parseVariableIdentifier();
                  if (this.context.strict) {
                    if (this.scanner.isRestrictedWord(token.value)) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunctionName);
                    }
                  } else {
                    if (this.scanner.isRestrictedWord(token.value)) {
                      firstRestricted = token;
                      message = messages_1.Messages.StrictFunctionName;
                    } else if (this.scanner.isStrictModeReservedWord(token.value)) {
                      firstRestricted = token;
                      message = messages_1.Messages.StrictReservedWord;
                    }
                  }
                }
                var formalParameters = this.parseFormalParameters(firstRestricted);
                var params = formalParameters.params;
                var stricted = formalParameters.stricted;
                firstRestricted = formalParameters.firstRestricted;
                if (formalParameters.message) {
                  message = formalParameters.message;
                }
                var previousStrict = this.context.strict;
                var previousAllowStrictDirective = this.context.allowStrictDirective;
                this.context.allowStrictDirective = formalParameters.simple;
                var body = this.parseFunctionSourceElements();
                if (this.context.strict && firstRestricted) {
                  this.throwUnexpectedToken(firstRestricted, message);
                }
                if (this.context.strict && stricted) {
                  this.tolerateUnexpectedToken(stricted, message);
                }
                this.context.strict = previousStrict;
                this.context.allowStrictDirective = previousAllowStrictDirective;
                this.context.await = previousAllowAwait;
                this.context.allowYield = previousAllowYield;
                return isAsync ? this.finalize(node, new Node.AsyncFunctionExpression(id, params, body)) : this.finalize(node, new Node.FunctionExpression(id, params, body, isGenerator));
              };
              Parser2.prototype.parseDirective = function() {
                var token = this.lookahead;
                var node = this.createNode();
                var expr = this.parseExpression();
                var directive = expr.type === syntax_1.Syntax.Literal ? this.getTokenRaw(token).slice(1, -1) : null;
                this.consumeSemicolon();
                return this.finalize(node, directive ? new Node.Directive(expr, directive) : new Node.ExpressionStatement(expr));
              };
              Parser2.prototype.parseDirectivePrologues = function() {
                var firstRestricted = null;
                var body = [];
                while (true) {
                  var token = this.lookahead;
                  if (token.type !== 8) {
                    break;
                  }
                  var statement = this.parseDirective();
                  body.push(statement);
                  var directive = statement.directive;
                  if (typeof directive !== "string") {
                    break;
                  }
                  if (directive === "use strict") {
                    this.context.strict = true;
                    if (firstRestricted) {
                      this.tolerateUnexpectedToken(firstRestricted, messages_1.Messages.StrictOctalLiteral);
                    }
                    if (!this.context.allowStrictDirective) {
                      this.tolerateUnexpectedToken(token, messages_1.Messages.IllegalLanguageModeDirective);
                    }
                  } else {
                    if (!firstRestricted && token.octal) {
                      firstRestricted = token;
                    }
                  }
                }
                return body;
              };
              Parser2.prototype.qualifiedPropertyName = function(token) {
                switch (token.type) {
                  case 3:
                  case 8:
                  case 1:
                  case 5:
                  case 6:
                  case 4:
                    return true;
                  case 7:
                    return token.value === "[";
                  default:
                    break;
                }
                return false;
              };
              Parser2.prototype.parseGetterMethod = function() {
                var node = this.createNode();
                var isGenerator = false;
                var previousAllowYield = this.context.allowYield;
                this.context.allowYield = !isGenerator;
                var formalParameters = this.parseFormalParameters();
                if (formalParameters.params.length > 0) {
                  this.tolerateError(messages_1.Messages.BadGetterArity);
                }
                var method = this.parsePropertyMethod(formalParameters);
                this.context.allowYield = previousAllowYield;
                return this.finalize(node, new Node.FunctionExpression(null, formalParameters.params, method, isGenerator));
              };
              Parser2.prototype.parseSetterMethod = function() {
                var node = this.createNode();
                var isGenerator = false;
                var previousAllowYield = this.context.allowYield;
                this.context.allowYield = !isGenerator;
                var formalParameters = this.parseFormalParameters();
                if (formalParameters.params.length !== 1) {
                  this.tolerateError(messages_1.Messages.BadSetterArity);
                } else if (formalParameters.params[0] instanceof Node.RestElement) {
                  this.tolerateError(messages_1.Messages.BadSetterRestParameter);
                }
                var method = this.parsePropertyMethod(formalParameters);
                this.context.allowYield = previousAllowYield;
                return this.finalize(node, new Node.FunctionExpression(null, formalParameters.params, method, isGenerator));
              };
              Parser2.prototype.parseGeneratorMethod = function() {
                var node = this.createNode();
                var isGenerator = true;
                var previousAllowYield = this.context.allowYield;
                this.context.allowYield = true;
                var params = this.parseFormalParameters();
                this.context.allowYield = false;
                var method = this.parsePropertyMethod(params);
                this.context.allowYield = previousAllowYield;
                return this.finalize(node, new Node.FunctionExpression(null, params.params, method, isGenerator));
              };
              Parser2.prototype.isStartOfExpression = function() {
                var start = true;
                var value = this.lookahead.value;
                switch (this.lookahead.type) {
                  case 7:
                    start = value === "[" || value === "(" || value === "{" || value === "+" || value === "-" || value === "!" || value === "~" || value === "++" || value === "--" || value === "/" || value === "/=";
                    break;
                  case 4:
                    start = value === "class" || value === "delete" || value === "function" || value === "let" || value === "new" || value === "super" || value === "this" || value === "typeof" || value === "void" || value === "yield";
                    break;
                  default:
                    break;
                }
                return start;
              };
              Parser2.prototype.parseYieldExpression = function() {
                var node = this.createNode();
                this.expectKeyword("yield");
                var argument = null;
                var delegate = false;
                if (!this.hasLineTerminator) {
                  var previousAllowYield = this.context.allowYield;
                  this.context.allowYield = false;
                  delegate = this.match("*");
                  if (delegate) {
                    this.nextToken();
                    argument = this.parseAssignmentExpression();
                  } else if (this.isStartOfExpression()) {
                    argument = this.parseAssignmentExpression();
                  }
                  this.context.allowYield = previousAllowYield;
                }
                return this.finalize(node, new Node.YieldExpression(argument, delegate));
              };
              Parser2.prototype.parseClassElement = function(hasConstructor) {
                var token = this.lookahead;
                var node = this.createNode();
                var kind = "";
                var key = null;
                var value = null;
                var computed = false;
                var method = false;
                var isStatic = false;
                var isAsync = false;
                if (this.match("*")) {
                  this.nextToken();
                } else {
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  var id = key;
                  if (id.name === "static" && (this.qualifiedPropertyName(this.lookahead) || this.match("*"))) {
                    token = this.lookahead;
                    isStatic = true;
                    computed = this.match("[");
                    if (this.match("*")) {
                      this.nextToken();
                    } else {
                      key = this.parseObjectPropertyKey();
                    }
                  }
                  if (token.type === 3 && !this.hasLineTerminator && token.value === "async") {
                    var punctuator = this.lookahead.value;
                    if (punctuator !== ":" && punctuator !== "(" && punctuator !== "*") {
                      isAsync = true;
                      token = this.lookahead;
                      key = this.parseObjectPropertyKey();
                      if (token.type === 3 && token.value === "constructor") {
                        this.tolerateUnexpectedToken(token, messages_1.Messages.ConstructorIsAsync);
                      }
                    }
                  }
                }
                var lookaheadPropertyKey = this.qualifiedPropertyName(this.lookahead);
                if (token.type === 3) {
                  if (token.value === "get" && lookaheadPropertyKey) {
                    kind = "get";
                    computed = this.match("[");
                    key = this.parseObjectPropertyKey();
                    this.context.allowYield = false;
                    value = this.parseGetterMethod();
                  } else if (token.value === "set" && lookaheadPropertyKey) {
                    kind = "set";
                    computed = this.match("[");
                    key = this.parseObjectPropertyKey();
                    value = this.parseSetterMethod();
                  }
                } else if (token.type === 7 && token.value === "*" && lookaheadPropertyKey) {
                  kind = "init";
                  computed = this.match("[");
                  key = this.parseObjectPropertyKey();
                  value = this.parseGeneratorMethod();
                  method = true;
                }
                if (!kind && key && this.match("(")) {
                  kind = "init";
                  value = isAsync ? this.parsePropertyMethodAsyncFunction() : this.parsePropertyMethodFunction();
                  method = true;
                }
                if (!kind) {
                  this.throwUnexpectedToken(this.lookahead);
                }
                if (kind === "init") {
                  kind = "method";
                }
                if (!computed) {
                  if (isStatic && this.isPropertyKey(key, "prototype")) {
                    this.throwUnexpectedToken(token, messages_1.Messages.StaticPrototype);
                  }
                  if (!isStatic && this.isPropertyKey(key, "constructor")) {
                    if (kind !== "method" || !method || value && value.generator) {
                      this.throwUnexpectedToken(token, messages_1.Messages.ConstructorSpecialMethod);
                    }
                    if (hasConstructor.value) {
                      this.throwUnexpectedToken(token, messages_1.Messages.DuplicateConstructor);
                    } else {
                      hasConstructor.value = true;
                    }
                    kind = "constructor";
                  }
                }
                return this.finalize(node, new Node.MethodDefinition(key, computed, value, kind, isStatic));
              };
              Parser2.prototype.parseClassElementList = function() {
                var body = [];
                var hasConstructor = { value: false };
                this.expect("{");
                while (!this.match("}")) {
                  if (this.match(";")) {
                    this.nextToken();
                  } else {
                    body.push(this.parseClassElement(hasConstructor));
                  }
                }
                this.expect("}");
                return body;
              };
              Parser2.prototype.parseClassBody = function() {
                var node = this.createNode();
                var elementList = this.parseClassElementList();
                return this.finalize(node, new Node.ClassBody(elementList));
              };
              Parser2.prototype.parseClassDeclaration = function(identifierIsOptional) {
                var node = this.createNode();
                var previousStrict = this.context.strict;
                this.context.strict = true;
                this.expectKeyword("class");
                var id = identifierIsOptional && this.lookahead.type !== 3 ? null : this.parseVariableIdentifier();
                var superClass = null;
                if (this.matchKeyword("extends")) {
                  this.nextToken();
                  superClass = this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
                }
                var classBody = this.parseClassBody();
                this.context.strict = previousStrict;
                return this.finalize(node, new Node.ClassDeclaration(id, superClass, classBody));
              };
              Parser2.prototype.parseClassExpression = function() {
                var node = this.createNode();
                var previousStrict = this.context.strict;
                this.context.strict = true;
                this.expectKeyword("class");
                var id = this.lookahead.type === 3 ? this.parseVariableIdentifier() : null;
                var superClass = null;
                if (this.matchKeyword("extends")) {
                  this.nextToken();
                  superClass = this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
                }
                var classBody = this.parseClassBody();
                this.context.strict = previousStrict;
                return this.finalize(node, new Node.ClassExpression(id, superClass, classBody));
              };
              Parser2.prototype.parseModule = function() {
                this.context.strict = true;
                this.context.isModule = true;
                this.scanner.isModule = true;
                var node = this.createNode();
                var body = this.parseDirectivePrologues();
                while (this.lookahead.type !== 2) {
                  body.push(this.parseStatementListItem());
                }
                return this.finalize(node, new Node.Module(body));
              };
              Parser2.prototype.parseScript = function() {
                var node = this.createNode();
                var body = this.parseDirectivePrologues();
                while (this.lookahead.type !== 2) {
                  body.push(this.parseStatementListItem());
                }
                return this.finalize(node, new Node.Script(body));
              };
              Parser2.prototype.parseModuleSpecifier = function() {
                var node = this.createNode();
                if (this.lookahead.type !== 8) {
                  this.throwError(messages_1.Messages.InvalidModuleSpecifier);
                }
                var token = this.nextToken();
                var raw = this.getTokenRaw(token);
                return this.finalize(node, new Node.Literal(token.value, raw));
              };
              Parser2.prototype.parseImportSpecifier = function() {
                var node = this.createNode();
                var imported;
                var local;
                if (this.lookahead.type === 3) {
                  imported = this.parseVariableIdentifier();
                  local = imported;
                  if (this.matchContextualKeyword("as")) {
                    this.nextToken();
                    local = this.parseVariableIdentifier();
                  }
                } else {
                  imported = this.parseIdentifierName();
                  local = imported;
                  if (this.matchContextualKeyword("as")) {
                    this.nextToken();
                    local = this.parseVariableIdentifier();
                  } else {
                    this.throwUnexpectedToken(this.nextToken());
                  }
                }
                return this.finalize(node, new Node.ImportSpecifier(local, imported));
              };
              Parser2.prototype.parseNamedImports = function() {
                this.expect("{");
                var specifiers = [];
                while (!this.match("}")) {
                  specifiers.push(this.parseImportSpecifier());
                  if (!this.match("}")) {
                    this.expect(",");
                  }
                }
                this.expect("}");
                return specifiers;
              };
              Parser2.prototype.parseImportDefaultSpecifier = function() {
                var node = this.createNode();
                var local = this.parseIdentifierName();
                return this.finalize(node, new Node.ImportDefaultSpecifier(local));
              };
              Parser2.prototype.parseImportNamespaceSpecifier = function() {
                var node = this.createNode();
                this.expect("*");
                if (!this.matchContextualKeyword("as")) {
                  this.throwError(messages_1.Messages.NoAsAfterImportNamespace);
                }
                this.nextToken();
                var local = this.parseIdentifierName();
                return this.finalize(node, new Node.ImportNamespaceSpecifier(local));
              };
              Parser2.prototype.parseImportDeclaration = function() {
                if (this.context.inFunctionBody) {
                  this.throwError(messages_1.Messages.IllegalImportDeclaration);
                }
                var node = this.createNode();
                this.expectKeyword("import");
                var src;
                var specifiers = [];
                if (this.lookahead.type === 8) {
                  src = this.parseModuleSpecifier();
                } else {
                  if (this.match("{")) {
                    specifiers = specifiers.concat(this.parseNamedImports());
                  } else if (this.match("*")) {
                    specifiers.push(this.parseImportNamespaceSpecifier());
                  } else if (this.isIdentifierName(this.lookahead) && !this.matchKeyword("default")) {
                    specifiers.push(this.parseImportDefaultSpecifier());
                    if (this.match(",")) {
                      this.nextToken();
                      if (this.match("*")) {
                        specifiers.push(this.parseImportNamespaceSpecifier());
                      } else if (this.match("{")) {
                        specifiers = specifiers.concat(this.parseNamedImports());
                      } else {
                        this.throwUnexpectedToken(this.lookahead);
                      }
                    }
                  } else {
                    this.throwUnexpectedToken(this.nextToken());
                  }
                  if (!this.matchContextualKeyword("from")) {
                    var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
                    this.throwError(message, this.lookahead.value);
                  }
                  this.nextToken();
                  src = this.parseModuleSpecifier();
                }
                this.consumeSemicolon();
                return this.finalize(node, new Node.ImportDeclaration(specifiers, src));
              };
              Parser2.prototype.parseExportSpecifier = function() {
                var node = this.createNode();
                var local = this.parseIdentifierName();
                var exported = local;
                if (this.matchContextualKeyword("as")) {
                  this.nextToken();
                  exported = this.parseIdentifierName();
                }
                return this.finalize(node, new Node.ExportSpecifier(local, exported));
              };
              Parser2.prototype.parseExportDeclaration = function() {
                if (this.context.inFunctionBody) {
                  this.throwError(messages_1.Messages.IllegalExportDeclaration);
                }
                var node = this.createNode();
                this.expectKeyword("export");
                var exportDeclaration;
                if (this.matchKeyword("default")) {
                  this.nextToken();
                  if (this.matchKeyword("function")) {
                    var declaration = this.parseFunctionDeclaration(true);
                    exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
                  } else if (this.matchKeyword("class")) {
                    var declaration = this.parseClassDeclaration(true);
                    exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
                  } else if (this.matchContextualKeyword("async")) {
                    var declaration = this.matchAsyncFunction() ? this.parseFunctionDeclaration(true) : this.parseAssignmentExpression();
                    exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
                  } else {
                    if (this.matchContextualKeyword("from")) {
                      this.throwError(messages_1.Messages.UnexpectedToken, this.lookahead.value);
                    }
                    var declaration = this.match("{") ? this.parseObjectInitializer() : this.match("[") ? this.parseArrayInitializer() : this.parseAssignmentExpression();
                    this.consumeSemicolon();
                    exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
                  }
                } else if (this.match("*")) {
                  this.nextToken();
                  if (!this.matchContextualKeyword("from")) {
                    var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
                    this.throwError(message, this.lookahead.value);
                  }
                  this.nextToken();
                  var src = this.parseModuleSpecifier();
                  this.consumeSemicolon();
                  exportDeclaration = this.finalize(node, new Node.ExportAllDeclaration(src));
                } else if (this.lookahead.type === 4) {
                  var declaration = void 0;
                  switch (this.lookahead.value) {
                    case "let":
                    case "const":
                      declaration = this.parseLexicalDeclaration({ inFor: false });
                      break;
                    case "var":
                    case "class":
                    case "function":
                      declaration = this.parseStatementListItem();
                      break;
                    default:
                      this.throwUnexpectedToken(this.lookahead);
                  }
                  exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(declaration, [], null));
                } else if (this.matchAsyncFunction()) {
                  var declaration = this.parseFunctionDeclaration();
                  exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(declaration, [], null));
                } else {
                  var specifiers = [];
                  var source = null;
                  var isExportFromIdentifier = false;
                  this.expect("{");
                  while (!this.match("}")) {
                    isExportFromIdentifier = isExportFromIdentifier || this.matchKeyword("default");
                    specifiers.push(this.parseExportSpecifier());
                    if (!this.match("}")) {
                      this.expect(",");
                    }
                  }
                  this.expect("}");
                  if (this.matchContextualKeyword("from")) {
                    this.nextToken();
                    source = this.parseModuleSpecifier();
                    this.consumeSemicolon();
                  } else if (isExportFromIdentifier) {
                    var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
                    this.throwError(message, this.lookahead.value);
                  } else {
                    this.consumeSemicolon();
                  }
                  exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(null, specifiers, source));
                }
                return exportDeclaration;
              };
              return Parser2;
            })();
            exports2.Parser = Parser;
          },
          /* 9 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            function assert(condition, message) {
              if (!condition) {
                throw new Error("ASSERT: " + message);
              }
            }
            exports2.assert = assert;
          },
          /* 10 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var ErrorHandler = (function() {
              function ErrorHandler2() {
                this.errors = [];
                this.tolerant = false;
              }
              ErrorHandler2.prototype.recordError = function(error) {
                this.errors.push(error);
              };
              ErrorHandler2.prototype.tolerate = function(error) {
                if (this.tolerant) {
                  this.recordError(error);
                } else {
                  throw error;
                }
              };
              ErrorHandler2.prototype.constructError = function(msg, column) {
                var error = new Error(msg);
                try {
                  throw error;
                } catch (base) {
                  if (Object.create && Object.defineProperty) {
                    error = Object.create(base);
                    Object.defineProperty(error, "column", { value: column });
                  }
                }
                return error;
              };
              ErrorHandler2.prototype.createError = function(index, line, col, description) {
                var msg = "Line " + line + ": " + description;
                var error = this.constructError(msg, col);
                error.index = index;
                error.lineNumber = line;
                error.description = description;
                return error;
              };
              ErrorHandler2.prototype.throwError = function(index, line, col, description) {
                throw this.createError(index, line, col, description);
              };
              ErrorHandler2.prototype.tolerateError = function(index, line, col, description) {
                var error = this.createError(index, line, col, description);
                if (this.tolerant) {
                  this.recordError(error);
                } else {
                  throw error;
                }
              };
              return ErrorHandler2;
            })();
            exports2.ErrorHandler = ErrorHandler;
          },
          /* 11 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            exports2.Messages = {
              BadGetterArity: "Getter must not have any formal parameters",
              BadSetterArity: "Setter must have exactly one formal parameter",
              BadSetterRestParameter: "Setter function argument must not be a rest parameter",
              ConstructorIsAsync: "Class constructor may not be an async method",
              ConstructorSpecialMethod: "Class constructor may not be an accessor",
              DeclarationMissingInitializer: "Missing initializer in %0 declaration",
              DefaultRestParameter: "Unexpected token =",
              DuplicateBinding: "Duplicate binding %0",
              DuplicateConstructor: "A class may only have one constructor",
              DuplicateProtoProperty: "Duplicate __proto__ fields are not allowed in object literals",
              ForInOfLoopInitializer: "%0 loop variable declaration may not have an initializer",
              GeneratorInLegacyContext: "Generator declarations are not allowed in legacy contexts",
              IllegalBreak: "Illegal break statement",
              IllegalContinue: "Illegal continue statement",
              IllegalExportDeclaration: "Unexpected token",
              IllegalImportDeclaration: "Unexpected token",
              IllegalLanguageModeDirective: "Illegal 'use strict' directive in function with non-simple parameter list",
              IllegalReturn: "Illegal return statement",
              InvalidEscapedReservedWord: "Keyword must not contain escaped characters",
              InvalidHexEscapeSequence: "Invalid hexadecimal escape sequence",
              InvalidLHSInAssignment: "Invalid left-hand side in assignment",
              InvalidLHSInForIn: "Invalid left-hand side in for-in",
              InvalidLHSInForLoop: "Invalid left-hand side in for-loop",
              InvalidModuleSpecifier: "Unexpected token",
              InvalidRegExp: "Invalid regular expression",
              LetInLexicalBinding: "let is disallowed as a lexically bound name",
              MissingFromClause: "Unexpected token",
              MultipleDefaultsInSwitch: "More than one default clause in switch statement",
              NewlineAfterThrow: "Illegal newline after throw",
              NoAsAfterImportNamespace: "Unexpected token",
              NoCatchOrFinally: "Missing catch or finally after try",
              ParameterAfterRestParameter: "Rest parameter must be last formal parameter",
              Redeclaration: "%0 '%1' has already been declared",
              StaticPrototype: "Classes may not have static property named prototype",
              StrictCatchVariable: "Catch variable may not be eval or arguments in strict mode",
              StrictDelete: "Delete of an unqualified identifier in strict mode.",
              StrictFunction: "In strict mode code, functions can only be declared at top level or inside a block",
              StrictFunctionName: "Function name may not be eval or arguments in strict mode",
              StrictLHSAssignment: "Assignment to eval or arguments is not allowed in strict mode",
              StrictLHSPostfix: "Postfix increment/decrement may not have eval or arguments operand in strict mode",
              StrictLHSPrefix: "Prefix increment/decrement may not have eval or arguments operand in strict mode",
              StrictModeWith: "Strict mode code may not include a with statement",
              StrictOctalLiteral: "Octal literals are not allowed in strict mode.",
              StrictParamDupe: "Strict mode function may not have duplicate parameter names",
              StrictParamName: "Parameter name eval or arguments is not allowed in strict mode",
              StrictReservedWord: "Use of future reserved word in strict mode",
              StrictVarName: "Variable name may not be eval or arguments in strict mode",
              TemplateOctalLiteral: "Octal literals are not allowed in template strings.",
              UnexpectedEOS: "Unexpected end of input",
              UnexpectedIdentifier: "Unexpected identifier",
              UnexpectedNumber: "Unexpected number",
              UnexpectedReserved: "Unexpected reserved word",
              UnexpectedString: "Unexpected string",
              UnexpectedTemplate: "Unexpected quasi %0",
              UnexpectedToken: "Unexpected token %0",
              UnexpectedTokenIllegal: "Unexpected token ILLEGAL",
              UnknownLabel: "Undefined label '%0'",
              UnterminatedRegExp: "Invalid regular expression: missing /"
            };
          },
          /* 12 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var assert_1 = __webpack_require__(9);
            var character_1 = __webpack_require__(4);
            var messages_1 = __webpack_require__(11);
            function hexValue(ch) {
              return "0123456789abcdef".indexOf(ch.toLowerCase());
            }
            function octalValue(ch) {
              return "01234567".indexOf(ch);
            }
            var Scanner = (function() {
              function Scanner2(code, handler) {
                this.source = code;
                this.errorHandler = handler;
                this.trackComment = false;
                this.isModule = false;
                this.length = code.length;
                this.index = 0;
                this.lineNumber = code.length > 0 ? 1 : 0;
                this.lineStart = 0;
                this.curlyStack = [];
              }
              Scanner2.prototype.saveState = function() {
                return {
                  index: this.index,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart
                };
              };
              Scanner2.prototype.restoreState = function(state) {
                this.index = state.index;
                this.lineNumber = state.lineNumber;
                this.lineStart = state.lineStart;
              };
              Scanner2.prototype.eof = function() {
                return this.index >= this.length;
              };
              Scanner2.prototype.throwUnexpectedToken = function(message) {
                if (message === void 0) {
                  message = messages_1.Messages.UnexpectedTokenIllegal;
                }
                return this.errorHandler.throwError(this.index, this.lineNumber, this.index - this.lineStart + 1, message);
              };
              Scanner2.prototype.tolerateUnexpectedToken = function(message) {
                if (message === void 0) {
                  message = messages_1.Messages.UnexpectedTokenIllegal;
                }
                this.errorHandler.tolerateError(this.index, this.lineNumber, this.index - this.lineStart + 1, message);
              };
              Scanner2.prototype.skipSingleLineComment = function(offset) {
                var comments = [];
                var start, loc;
                if (this.trackComment) {
                  comments = [];
                  start = this.index - offset;
                  loc = {
                    start: {
                      line: this.lineNumber,
                      column: this.index - this.lineStart - offset
                    },
                    end: {}
                  };
                }
                while (!this.eof()) {
                  var ch = this.source.charCodeAt(this.index);
                  ++this.index;
                  if (character_1.Character.isLineTerminator(ch)) {
                    if (this.trackComment) {
                      loc.end = {
                        line: this.lineNumber,
                        column: this.index - this.lineStart - 1
                      };
                      var entry = {
                        multiLine: false,
                        slice: [start + offset, this.index - 1],
                        range: [start, this.index - 1],
                        loc
                      };
                      comments.push(entry);
                    }
                    if (ch === 13 && this.source.charCodeAt(this.index) === 10) {
                      ++this.index;
                    }
                    ++this.lineNumber;
                    this.lineStart = this.index;
                    return comments;
                  }
                }
                if (this.trackComment) {
                  loc.end = {
                    line: this.lineNumber,
                    column: this.index - this.lineStart
                  };
                  var entry = {
                    multiLine: false,
                    slice: [start + offset, this.index],
                    range: [start, this.index],
                    loc
                  };
                  comments.push(entry);
                }
                return comments;
              };
              Scanner2.prototype.skipMultiLineComment = function() {
                var comments = [];
                var start, loc;
                if (this.trackComment) {
                  comments = [];
                  start = this.index - 2;
                  loc = {
                    start: {
                      line: this.lineNumber,
                      column: this.index - this.lineStart - 2
                    },
                    end: {}
                  };
                }
                while (!this.eof()) {
                  var ch = this.source.charCodeAt(this.index);
                  if (character_1.Character.isLineTerminator(ch)) {
                    if (ch === 13 && this.source.charCodeAt(this.index + 1) === 10) {
                      ++this.index;
                    }
                    ++this.lineNumber;
                    ++this.index;
                    this.lineStart = this.index;
                  } else if (ch === 42) {
                    if (this.source.charCodeAt(this.index + 1) === 47) {
                      this.index += 2;
                      if (this.trackComment) {
                        loc.end = {
                          line: this.lineNumber,
                          column: this.index - this.lineStart
                        };
                        var entry = {
                          multiLine: true,
                          slice: [start + 2, this.index - 2],
                          range: [start, this.index],
                          loc
                        };
                        comments.push(entry);
                      }
                      return comments;
                    }
                    ++this.index;
                  } else {
                    ++this.index;
                  }
                }
                if (this.trackComment) {
                  loc.end = {
                    line: this.lineNumber,
                    column: this.index - this.lineStart
                  };
                  var entry = {
                    multiLine: true,
                    slice: [start + 2, this.index],
                    range: [start, this.index],
                    loc
                  };
                  comments.push(entry);
                }
                this.tolerateUnexpectedToken();
                return comments;
              };
              Scanner2.prototype.scanComments = function() {
                var comments;
                if (this.trackComment) {
                  comments = [];
                }
                var start = this.index === 0;
                while (!this.eof()) {
                  var ch = this.source.charCodeAt(this.index);
                  if (character_1.Character.isWhiteSpace(ch)) {
                    ++this.index;
                  } else if (character_1.Character.isLineTerminator(ch)) {
                    ++this.index;
                    if (ch === 13 && this.source.charCodeAt(this.index) === 10) {
                      ++this.index;
                    }
                    ++this.lineNumber;
                    this.lineStart = this.index;
                    start = true;
                  } else if (ch === 47) {
                    ch = this.source.charCodeAt(this.index + 1);
                    if (ch === 47) {
                      this.index += 2;
                      var comment = this.skipSingleLineComment(2);
                      if (this.trackComment) {
                        comments = comments.concat(comment);
                      }
                      start = true;
                    } else if (ch === 42) {
                      this.index += 2;
                      var comment = this.skipMultiLineComment();
                      if (this.trackComment) {
                        comments = comments.concat(comment);
                      }
                    } else {
                      break;
                    }
                  } else if (start && ch === 45) {
                    if (this.source.charCodeAt(this.index + 1) === 45 && this.source.charCodeAt(this.index + 2) === 62) {
                      this.index += 3;
                      var comment = this.skipSingleLineComment(3);
                      if (this.trackComment) {
                        comments = comments.concat(comment);
                      }
                    } else {
                      break;
                    }
                  } else if (ch === 60 && !this.isModule) {
                    if (this.source.slice(this.index + 1, this.index + 4) === "!--") {
                      this.index += 4;
                      var comment = this.skipSingleLineComment(4);
                      if (this.trackComment) {
                        comments = comments.concat(comment);
                      }
                    } else {
                      break;
                    }
                  } else {
                    break;
                  }
                }
                return comments;
              };
              Scanner2.prototype.isFutureReservedWord = function(id) {
                switch (id) {
                  case "enum":
                  case "export":
                  case "import":
                  case "super":
                    return true;
                  default:
                    return false;
                }
              };
              Scanner2.prototype.isStrictModeReservedWord = function(id) {
                switch (id) {
                  case "implements":
                  case "interface":
                  case "package":
                  case "private":
                  case "protected":
                  case "public":
                  case "static":
                  case "yield":
                  case "let":
                    return true;
                  default:
                    return false;
                }
              };
              Scanner2.prototype.isRestrictedWord = function(id) {
                return id === "eval" || id === "arguments";
              };
              Scanner2.prototype.isKeyword = function(id) {
                switch (id.length) {
                  case 2:
                    return id === "if" || id === "in" || id === "do";
                  case 3:
                    return id === "var" || id === "for" || id === "new" || id === "try" || id === "let";
                  case 4:
                    return id === "this" || id === "else" || id === "case" || id === "void" || id === "with" || id === "enum";
                  case 5:
                    return id === "while" || id === "break" || id === "catch" || id === "throw" || id === "const" || id === "yield" || id === "class" || id === "super";
                  case 6:
                    return id === "return" || id === "typeof" || id === "delete" || id === "switch" || id === "export" || id === "import";
                  case 7:
                    return id === "default" || id === "finally" || id === "extends";
                  case 8:
                    return id === "function" || id === "continue" || id === "debugger";
                  case 10:
                    return id === "instanceof";
                  default:
                    return false;
                }
              };
              Scanner2.prototype.codePointAt = function(i) {
                var cp = this.source.charCodeAt(i);
                if (cp >= 55296 && cp <= 56319) {
                  var second = this.source.charCodeAt(i + 1);
                  if (second >= 56320 && second <= 57343) {
                    var first = cp;
                    cp = (first - 55296) * 1024 + second - 56320 + 65536;
                  }
                }
                return cp;
              };
              Scanner2.prototype.scanHexEscape = function(prefix) {
                var len = prefix === "u" ? 4 : 2;
                var code = 0;
                for (var i = 0; i < len; ++i) {
                  if (!this.eof() && character_1.Character.isHexDigit(this.source.charCodeAt(this.index))) {
                    code = code * 16 + hexValue(this.source[this.index++]);
                  } else {
                    return null;
                  }
                }
                return String.fromCharCode(code);
              };
              Scanner2.prototype.scanUnicodeCodePointEscape = function() {
                var ch = this.source[this.index];
                var code = 0;
                if (ch === "}") {
                  this.throwUnexpectedToken();
                }
                while (!this.eof()) {
                  ch = this.source[this.index++];
                  if (!character_1.Character.isHexDigit(ch.charCodeAt(0))) {
                    break;
                  }
                  code = code * 16 + hexValue(ch);
                }
                if (code > 1114111 || ch !== "}") {
                  this.throwUnexpectedToken();
                }
                return character_1.Character.fromCodePoint(code);
              };
              Scanner2.prototype.getIdentifier = function() {
                var start = this.index++;
                while (!this.eof()) {
                  var ch = this.source.charCodeAt(this.index);
                  if (ch === 92) {
                    this.index = start;
                    return this.getComplexIdentifier();
                  } else if (ch >= 55296 && ch < 57343) {
                    this.index = start;
                    return this.getComplexIdentifier();
                  }
                  if (character_1.Character.isIdentifierPart(ch)) {
                    ++this.index;
                  } else {
                    break;
                  }
                }
                return this.source.slice(start, this.index);
              };
              Scanner2.prototype.getComplexIdentifier = function() {
                var cp = this.codePointAt(this.index);
                var id = character_1.Character.fromCodePoint(cp);
                this.index += id.length;
                var ch;
                if (cp === 92) {
                  if (this.source.charCodeAt(this.index) !== 117) {
                    this.throwUnexpectedToken();
                  }
                  ++this.index;
                  if (this.source[this.index] === "{") {
                    ++this.index;
                    ch = this.scanUnicodeCodePointEscape();
                  } else {
                    ch = this.scanHexEscape("u");
                    if (ch === null || ch === "\\" || !character_1.Character.isIdentifierStart(ch.charCodeAt(0))) {
                      this.throwUnexpectedToken();
                    }
                  }
                  id = ch;
                }
                while (!this.eof()) {
                  cp = this.codePointAt(this.index);
                  if (!character_1.Character.isIdentifierPart(cp)) {
                    break;
                  }
                  ch = character_1.Character.fromCodePoint(cp);
                  id += ch;
                  this.index += ch.length;
                  if (cp === 92) {
                    id = id.substr(0, id.length - 1);
                    if (this.source.charCodeAt(this.index) !== 117) {
                      this.throwUnexpectedToken();
                    }
                    ++this.index;
                    if (this.source[this.index] === "{") {
                      ++this.index;
                      ch = this.scanUnicodeCodePointEscape();
                    } else {
                      ch = this.scanHexEscape("u");
                      if (ch === null || ch === "\\" || !character_1.Character.isIdentifierPart(ch.charCodeAt(0))) {
                        this.throwUnexpectedToken();
                      }
                    }
                    id += ch;
                  }
                }
                return id;
              };
              Scanner2.prototype.octalToDecimal = function(ch) {
                var octal = ch !== "0";
                var code = octalValue(ch);
                if (!this.eof() && character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) {
                  octal = true;
                  code = code * 8 + octalValue(this.source[this.index++]);
                  if ("0123".indexOf(ch) >= 0 && !this.eof() && character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) {
                    code = code * 8 + octalValue(this.source[this.index++]);
                  }
                }
                return {
                  code,
                  octal
                };
              };
              Scanner2.prototype.scanIdentifier = function() {
                var type;
                var start = this.index;
                var id = this.source.charCodeAt(start) === 92 ? this.getComplexIdentifier() : this.getIdentifier();
                if (id.length === 1) {
                  type = 3;
                } else if (this.isKeyword(id)) {
                  type = 4;
                } else if (id === "null") {
                  type = 5;
                } else if (id === "true" || id === "false") {
                  type = 1;
                } else {
                  type = 3;
                }
                if (type !== 3 && start + id.length !== this.index) {
                  var restore = this.index;
                  this.index = start;
                  this.tolerateUnexpectedToken(messages_1.Messages.InvalidEscapedReservedWord);
                  this.index = restore;
                }
                return {
                  type,
                  value: id,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanPunctuator = function() {
                var start = this.index;
                var str = this.source[this.index];
                switch (str) {
                  case "(":
                  case "{":
                    if (str === "{") {
                      this.curlyStack.push("{");
                    }
                    ++this.index;
                    break;
                  case ".":
                    ++this.index;
                    if (this.source[this.index] === "." && this.source[this.index + 1] === ".") {
                      this.index += 2;
                      str = "...";
                    }
                    break;
                  case "}":
                    ++this.index;
                    this.curlyStack.pop();
                    break;
                  case ")":
                  case ";":
                  case ",":
                  case "[":
                  case "]":
                  case ":":
                  case "?":
                  case "~":
                    ++this.index;
                    break;
                  default:
                    str = this.source.substr(this.index, 4);
                    if (str === ">>>=") {
                      this.index += 4;
                    } else {
                      str = str.substr(0, 3);
                      if (str === "===" || str === "!==" || str === ">>>" || str === "<<=" || str === ">>=" || str === "**=") {
                        this.index += 3;
                      } else {
                        str = str.substr(0, 2);
                        if (str === "&&" || str === "||" || str === "==" || str === "!=" || str === "+=" || str === "-=" || str === "*=" || str === "/=" || str === "++" || str === "--" || str === "<<" || str === ">>" || str === "&=" || str === "|=" || str === "^=" || str === "%=" || str === "<=" || str === ">=" || str === "=>" || str === "**") {
                          this.index += 2;
                        } else {
                          str = this.source[this.index];
                          if ("<>=!+-*%&|^/".indexOf(str) >= 0) {
                            ++this.index;
                          }
                        }
                      }
                    }
                }
                if (this.index === start) {
                  this.throwUnexpectedToken();
                }
                return {
                  type: 7,
                  value: str,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanHexLiteral = function(start) {
                var num = "";
                while (!this.eof()) {
                  if (!character_1.Character.isHexDigit(this.source.charCodeAt(this.index))) {
                    break;
                  }
                  num += this.source[this.index++];
                }
                if (num.length === 0) {
                  this.throwUnexpectedToken();
                }
                if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))) {
                  this.throwUnexpectedToken();
                }
                return {
                  type: 6,
                  value: parseInt("0x" + num, 16),
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanBinaryLiteral = function(start) {
                var num = "";
                var ch;
                while (!this.eof()) {
                  ch = this.source[this.index];
                  if (ch !== "0" && ch !== "1") {
                    break;
                  }
                  num += this.source[this.index++];
                }
                if (num.length === 0) {
                  this.throwUnexpectedToken();
                }
                if (!this.eof()) {
                  ch = this.source.charCodeAt(this.index);
                  if (character_1.Character.isIdentifierStart(ch) || character_1.Character.isDecimalDigit(ch)) {
                    this.throwUnexpectedToken();
                  }
                }
                return {
                  type: 6,
                  value: parseInt(num, 2),
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanOctalLiteral = function(prefix, start) {
                var num = "";
                var octal = false;
                if (character_1.Character.isOctalDigit(prefix.charCodeAt(0))) {
                  octal = true;
                  num = "0" + this.source[this.index++];
                } else {
                  ++this.index;
                }
                while (!this.eof()) {
                  if (!character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) {
                    break;
                  }
                  num += this.source[this.index++];
                }
                if (!octal && num.length === 0) {
                  this.throwUnexpectedToken();
                }
                if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index)) || character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                  this.throwUnexpectedToken();
                }
                return {
                  type: 6,
                  value: parseInt(num, 8),
                  octal,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.isImplicitOctalLiteral = function() {
                for (var i = this.index + 1; i < this.length; ++i) {
                  var ch = this.source[i];
                  if (ch === "8" || ch === "9") {
                    return false;
                  }
                  if (!character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
                    return true;
                  }
                }
                return true;
              };
              Scanner2.prototype.scanNumericLiteral = function() {
                var start = this.index;
                var ch = this.source[start];
                assert_1.assert(character_1.Character.isDecimalDigit(ch.charCodeAt(0)) || ch === ".", "Numeric literal must start with a decimal digit or a decimal point");
                var num = "";
                if (ch !== ".") {
                  num = this.source[this.index++];
                  ch = this.source[this.index];
                  if (num === "0") {
                    if (ch === "x" || ch === "X") {
                      ++this.index;
                      return this.scanHexLiteral(start);
                    }
                    if (ch === "b" || ch === "B") {
                      ++this.index;
                      return this.scanBinaryLiteral(start);
                    }
                    if (ch === "o" || ch === "O") {
                      return this.scanOctalLiteral(ch, start);
                    }
                    if (ch && character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
                      if (this.isImplicitOctalLiteral()) {
                        return this.scanOctalLiteral(ch, start);
                      }
                    }
                  }
                  while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                    num += this.source[this.index++];
                  }
                  ch = this.source[this.index];
                }
                if (ch === ".") {
                  num += this.source[this.index++];
                  while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                    num += this.source[this.index++];
                  }
                  ch = this.source[this.index];
                }
                if (ch === "e" || ch === "E") {
                  num += this.source[this.index++];
                  ch = this.source[this.index];
                  if (ch === "+" || ch === "-") {
                    num += this.source[this.index++];
                  }
                  if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                    while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                      num += this.source[this.index++];
                    }
                  } else {
                    this.throwUnexpectedToken();
                  }
                }
                if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))) {
                  this.throwUnexpectedToken();
                }
                return {
                  type: 6,
                  value: parseFloat(num),
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanStringLiteral = function() {
                var start = this.index;
                var quote = this.source[start];
                assert_1.assert(quote === "'" || quote === '"', "String literal must starts with a quote");
                ++this.index;
                var octal = false;
                var str = "";
                while (!this.eof()) {
                  var ch = this.source[this.index++];
                  if (ch === quote) {
                    quote = "";
                    break;
                  } else if (ch === "\\") {
                    ch = this.source[this.index++];
                    if (!ch || !character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                      switch (ch) {
                        case "u":
                          if (this.source[this.index] === "{") {
                            ++this.index;
                            str += this.scanUnicodeCodePointEscape();
                          } else {
                            var unescaped_1 = this.scanHexEscape(ch);
                            if (unescaped_1 === null) {
                              this.throwUnexpectedToken();
                            }
                            str += unescaped_1;
                          }
                          break;
                        case "x":
                          var unescaped = this.scanHexEscape(ch);
                          if (unescaped === null) {
                            this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);
                          }
                          str += unescaped;
                          break;
                        case "n":
                          str += "\n";
                          break;
                        case "r":
                          str += "\r";
                          break;
                        case "t":
                          str += "	";
                          break;
                        case "b":
                          str += "\b";
                          break;
                        case "f":
                          str += "\f";
                          break;
                        case "v":
                          str += "\v";
                          break;
                        case "8":
                        case "9":
                          str += ch;
                          this.tolerateUnexpectedToken();
                          break;
                        default:
                          if (ch && character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
                            var octToDec = this.octalToDecimal(ch);
                            octal = octToDec.octal || octal;
                            str += String.fromCharCode(octToDec.code);
                          } else {
                            str += ch;
                          }
                          break;
                      }
                    } else {
                      ++this.lineNumber;
                      if (ch === "\r" && this.source[this.index] === "\n") {
                        ++this.index;
                      }
                      this.lineStart = this.index;
                    }
                  } else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                    break;
                  } else {
                    str += ch;
                  }
                }
                if (quote !== "") {
                  this.index = start;
                  this.throwUnexpectedToken();
                }
                return {
                  type: 8,
                  value: str,
                  octal,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.scanTemplate = function() {
                var cooked = "";
                var terminated = false;
                var start = this.index;
                var head = this.source[start] === "`";
                var tail = false;
                var rawOffset = 2;
                ++this.index;
                while (!this.eof()) {
                  var ch = this.source[this.index++];
                  if (ch === "`") {
                    rawOffset = 1;
                    tail = true;
                    terminated = true;
                    break;
                  } else if (ch === "$") {
                    if (this.source[this.index] === "{") {
                      this.curlyStack.push("${");
                      ++this.index;
                      terminated = true;
                      break;
                    }
                    cooked += ch;
                  } else if (ch === "\\") {
                    ch = this.source[this.index++];
                    if (!character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                      switch (ch) {
                        case "n":
                          cooked += "\n";
                          break;
                        case "r":
                          cooked += "\r";
                          break;
                        case "t":
                          cooked += "	";
                          break;
                        case "u":
                          if (this.source[this.index] === "{") {
                            ++this.index;
                            cooked += this.scanUnicodeCodePointEscape();
                          } else {
                            var restore = this.index;
                            var unescaped_2 = this.scanHexEscape(ch);
                            if (unescaped_2 !== null) {
                              cooked += unescaped_2;
                            } else {
                              this.index = restore;
                              cooked += ch;
                            }
                          }
                          break;
                        case "x":
                          var unescaped = this.scanHexEscape(ch);
                          if (unescaped === null) {
                            this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);
                          }
                          cooked += unescaped;
                          break;
                        case "b":
                          cooked += "\b";
                          break;
                        case "f":
                          cooked += "\f";
                          break;
                        case "v":
                          cooked += "\v";
                          break;
                        default:
                          if (ch === "0") {
                            if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) {
                              this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);
                            }
                            cooked += "\0";
                          } else if (character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
                            this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);
                          } else {
                            cooked += ch;
                          }
                          break;
                      }
                    } else {
                      ++this.lineNumber;
                      if (ch === "\r" && this.source[this.index] === "\n") {
                        ++this.index;
                      }
                      this.lineStart = this.index;
                    }
                  } else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                    ++this.lineNumber;
                    if (ch === "\r" && this.source[this.index] === "\n") {
                      ++this.index;
                    }
                    this.lineStart = this.index;
                    cooked += "\n";
                  } else {
                    cooked += ch;
                  }
                }
                if (!terminated) {
                  this.throwUnexpectedToken();
                }
                if (!head) {
                  this.curlyStack.pop();
                }
                return {
                  type: 10,
                  value: this.source.slice(start + 1, this.index - rawOffset),
                  cooked,
                  head,
                  tail,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.testRegExp = function(pattern, flags) {
                var astralSubstitute = "\uFFFF";
                var tmp = pattern;
                var self2 = this;
                if (flags.indexOf("u") >= 0) {
                  tmp = tmp.replace(/\\u\{([0-9a-fA-F]+)\}|\\u([a-fA-F0-9]{4})/g, function($0, $1, $2) {
                    var codePoint = parseInt($1 || $2, 16);
                    if (codePoint > 1114111) {
                      self2.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);
                    }
                    if (codePoint <= 65535) {
                      return String.fromCharCode(codePoint);
                    }
                    return astralSubstitute;
                  }).replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, astralSubstitute);
                }
                try {
                  RegExp(tmp);
                } catch (e) {
                  this.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);
                }
                try {
                  return new RegExp(pattern, flags);
                } catch (exception) {
                  return null;
                }
              };
              Scanner2.prototype.scanRegExpBody = function() {
                var ch = this.source[this.index];
                assert_1.assert(ch === "/", "Regular expression literal must start with a slash");
                var str = this.source[this.index++];
                var classMarker = false;
                var terminated = false;
                while (!this.eof()) {
                  ch = this.source[this.index++];
                  str += ch;
                  if (ch === "\\") {
                    ch = this.source[this.index++];
                    if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                      this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
                    }
                    str += ch;
                  } else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
                    this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
                  } else if (classMarker) {
                    if (ch === "]") {
                      classMarker = false;
                    }
                  } else {
                    if (ch === "/") {
                      terminated = true;
                      break;
                    } else if (ch === "[") {
                      classMarker = true;
                    }
                  }
                }
                if (!terminated) {
                  this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
                }
                return str.substr(1, str.length - 2);
              };
              Scanner2.prototype.scanRegExpFlags = function() {
                var str = "";
                var flags = "";
                while (!this.eof()) {
                  var ch = this.source[this.index];
                  if (!character_1.Character.isIdentifierPart(ch.charCodeAt(0))) {
                    break;
                  }
                  ++this.index;
                  if (ch === "\\" && !this.eof()) {
                    ch = this.source[this.index];
                    if (ch === "u") {
                      ++this.index;
                      var restore = this.index;
                      var char = this.scanHexEscape("u");
                      if (char !== null) {
                        flags += char;
                        for (str += "\\u"; restore < this.index; ++restore) {
                          str += this.source[restore];
                        }
                      } else {
                        this.index = restore;
                        flags += "u";
                        str += "\\u";
                      }
                      this.tolerateUnexpectedToken();
                    } else {
                      str += "\\";
                      this.tolerateUnexpectedToken();
                    }
                  } else {
                    flags += ch;
                    str += ch;
                  }
                }
                return flags;
              };
              Scanner2.prototype.scanRegExp = function() {
                var start = this.index;
                var pattern = this.scanRegExpBody();
                var flags = this.scanRegExpFlags();
                var value = this.testRegExp(pattern, flags);
                return {
                  type: 9,
                  value: "",
                  pattern,
                  flags,
                  regex: value,
                  lineNumber: this.lineNumber,
                  lineStart: this.lineStart,
                  start,
                  end: this.index
                };
              };
              Scanner2.prototype.lex = function() {
                if (this.eof()) {
                  return {
                    type: 2,
                    value: "",
                    lineNumber: this.lineNumber,
                    lineStart: this.lineStart,
                    start: this.index,
                    end: this.index
                  };
                }
                var cp = this.source.charCodeAt(this.index);
                if (character_1.Character.isIdentifierStart(cp)) {
                  return this.scanIdentifier();
                }
                if (cp === 40 || cp === 41 || cp === 59) {
                  return this.scanPunctuator();
                }
                if (cp === 39 || cp === 34) {
                  return this.scanStringLiteral();
                }
                if (cp === 46) {
                  if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index + 1))) {
                    return this.scanNumericLiteral();
                  }
                  return this.scanPunctuator();
                }
                if (character_1.Character.isDecimalDigit(cp)) {
                  return this.scanNumericLiteral();
                }
                if (cp === 96 || cp === 125 && this.curlyStack[this.curlyStack.length - 1] === "${") {
                  return this.scanTemplate();
                }
                if (cp >= 55296 && cp < 57343) {
                  if (character_1.Character.isIdentifierStart(this.codePointAt(this.index))) {
                    return this.scanIdentifier();
                  }
                }
                return this.scanPunctuator();
              };
              return Scanner2;
            })();
            exports2.Scanner = Scanner;
          },
          /* 13 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            exports2.TokenName = {};
            exports2.TokenName[
              1
              /* BooleanLiteral */
            ] = "Boolean";
            exports2.TokenName[
              2
              /* EOF */
            ] = "<end>";
            exports2.TokenName[
              3
              /* Identifier */
            ] = "Identifier";
            exports2.TokenName[
              4
              /* Keyword */
            ] = "Keyword";
            exports2.TokenName[
              5
              /* NullLiteral */
            ] = "Null";
            exports2.TokenName[
              6
              /* NumericLiteral */
            ] = "Numeric";
            exports2.TokenName[
              7
              /* Punctuator */
            ] = "Punctuator";
            exports2.TokenName[
              8
              /* StringLiteral */
            ] = "String";
            exports2.TokenName[
              9
              /* RegularExpression */
            ] = "RegularExpression";
            exports2.TokenName[
              10
              /* Template */
            ] = "Template";
          },
          /* 14 */
          /***/
          function(module2, exports2) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            exports2.XHTMLEntities = {
              quot: '"',
              amp: "&",
              apos: "'",
              gt: ">",
              nbsp: "\xA0",
              iexcl: "\xA1",
              cent: "\xA2",
              pound: "\xA3",
              curren: "\xA4",
              yen: "\xA5",
              brvbar: "\xA6",
              sect: "\xA7",
              uml: "\xA8",
              copy: "\xA9",
              ordf: "\xAA",
              laquo: "\xAB",
              not: "\xAC",
              shy: "\xAD",
              reg: "\xAE",
              macr: "\xAF",
              deg: "\xB0",
              plusmn: "\xB1",
              sup2: "\xB2",
              sup3: "\xB3",
              acute: "\xB4",
              micro: "\xB5",
              para: "\xB6",
              middot: "\xB7",
              cedil: "\xB8",
              sup1: "\xB9",
              ordm: "\xBA",
              raquo: "\xBB",
              frac14: "\xBC",
              frac12: "\xBD",
              frac34: "\xBE",
              iquest: "\xBF",
              Agrave: "\xC0",
              Aacute: "\xC1",
              Acirc: "\xC2",
              Atilde: "\xC3",
              Auml: "\xC4",
              Aring: "\xC5",
              AElig: "\xC6",
              Ccedil: "\xC7",
              Egrave: "\xC8",
              Eacute: "\xC9",
              Ecirc: "\xCA",
              Euml: "\xCB",
              Igrave: "\xCC",
              Iacute: "\xCD",
              Icirc: "\xCE",
              Iuml: "\xCF",
              ETH: "\xD0",
              Ntilde: "\xD1",
              Ograve: "\xD2",
              Oacute: "\xD3",
              Ocirc: "\xD4",
              Otilde: "\xD5",
              Ouml: "\xD6",
              times: "\xD7",
              Oslash: "\xD8",
              Ugrave: "\xD9",
              Uacute: "\xDA",
              Ucirc: "\xDB",
              Uuml: "\xDC",
              Yacute: "\xDD",
              THORN: "\xDE",
              szlig: "\xDF",
              agrave: "\xE0",
              aacute: "\xE1",
              acirc: "\xE2",
              atilde: "\xE3",
              auml: "\xE4",
              aring: "\xE5",
              aelig: "\xE6",
              ccedil: "\xE7",
              egrave: "\xE8",
              eacute: "\xE9",
              ecirc: "\xEA",
              euml: "\xEB",
              igrave: "\xEC",
              iacute: "\xED",
              icirc: "\xEE",
              iuml: "\xEF",
              eth: "\xF0",
              ntilde: "\xF1",
              ograve: "\xF2",
              oacute: "\xF3",
              ocirc: "\xF4",
              otilde: "\xF5",
              ouml: "\xF6",
              divide: "\xF7",
              oslash: "\xF8",
              ugrave: "\xF9",
              uacute: "\xFA",
              ucirc: "\xFB",
              uuml: "\xFC",
              yacute: "\xFD",
              thorn: "\xFE",
              yuml: "\xFF",
              OElig: "\u0152",
              oelig: "\u0153",
              Scaron: "\u0160",
              scaron: "\u0161",
              Yuml: "\u0178",
              fnof: "\u0192",
              circ: "\u02C6",
              tilde: "\u02DC",
              Alpha: "\u0391",
              Beta: "\u0392",
              Gamma: "\u0393",
              Delta: "\u0394",
              Epsilon: "\u0395",
              Zeta: "\u0396",
              Eta: "\u0397",
              Theta: "\u0398",
              Iota: "\u0399",
              Kappa: "\u039A",
              Lambda: "\u039B",
              Mu: "\u039C",
              Nu: "\u039D",
              Xi: "\u039E",
              Omicron: "\u039F",
              Pi: "\u03A0",
              Rho: "\u03A1",
              Sigma: "\u03A3",
              Tau: "\u03A4",
              Upsilon: "\u03A5",
              Phi: "\u03A6",
              Chi: "\u03A7",
              Psi: "\u03A8",
              Omega: "\u03A9",
              alpha: "\u03B1",
              beta: "\u03B2",
              gamma: "\u03B3",
              delta: "\u03B4",
              epsilon: "\u03B5",
              zeta: "\u03B6",
              eta: "\u03B7",
              theta: "\u03B8",
              iota: "\u03B9",
              kappa: "\u03BA",
              lambda: "\u03BB",
              mu: "\u03BC",
              nu: "\u03BD",
              xi: "\u03BE",
              omicron: "\u03BF",
              pi: "\u03C0",
              rho: "\u03C1",
              sigmaf: "\u03C2",
              sigma: "\u03C3",
              tau: "\u03C4",
              upsilon: "\u03C5",
              phi: "\u03C6",
              chi: "\u03C7",
              psi: "\u03C8",
              omega: "\u03C9",
              thetasym: "\u03D1",
              upsih: "\u03D2",
              piv: "\u03D6",
              ensp: "\u2002",
              emsp: "\u2003",
              thinsp: "\u2009",
              zwnj: "\u200C",
              zwj: "\u200D",
              lrm: "\u200E",
              rlm: "\u200F",
              ndash: "\u2013",
              mdash: "\u2014",
              lsquo: "\u2018",
              rsquo: "\u2019",
              sbquo: "\u201A",
              ldquo: "\u201C",
              rdquo: "\u201D",
              bdquo: "\u201E",
              dagger: "\u2020",
              Dagger: "\u2021",
              bull: "\u2022",
              hellip: "\u2026",
              permil: "\u2030",
              prime: "\u2032",
              Prime: "\u2033",
              lsaquo: "\u2039",
              rsaquo: "\u203A",
              oline: "\u203E",
              frasl: "\u2044",
              euro: "\u20AC",
              image: "\u2111",
              weierp: "\u2118",
              real: "\u211C",
              trade: "\u2122",
              alefsym: "\u2135",
              larr: "\u2190",
              uarr: "\u2191",
              rarr: "\u2192",
              darr: "\u2193",
              harr: "\u2194",
              crarr: "\u21B5",
              lArr: "\u21D0",
              uArr: "\u21D1",
              rArr: "\u21D2",
              dArr: "\u21D3",
              hArr: "\u21D4",
              forall: "\u2200",
              part: "\u2202",
              exist: "\u2203",
              empty: "\u2205",
              nabla: "\u2207",
              isin: "\u2208",
              notin: "\u2209",
              ni: "\u220B",
              prod: "\u220F",
              sum: "\u2211",
              minus: "\u2212",
              lowast: "\u2217",
              radic: "\u221A",
              prop: "\u221D",
              infin: "\u221E",
              ang: "\u2220",
              and: "\u2227",
              or: "\u2228",
              cap: "\u2229",
              cup: "\u222A",
              int: "\u222B",
              there4: "\u2234",
              sim: "\u223C",
              cong: "\u2245",
              asymp: "\u2248",
              ne: "\u2260",
              equiv: "\u2261",
              le: "\u2264",
              ge: "\u2265",
              sub: "\u2282",
              sup: "\u2283",
              nsub: "\u2284",
              sube: "\u2286",
              supe: "\u2287",
              oplus: "\u2295",
              otimes: "\u2297",
              perp: "\u22A5",
              sdot: "\u22C5",
              lceil: "\u2308",
              rceil: "\u2309",
              lfloor: "\u230A",
              rfloor: "\u230B",
              loz: "\u25CA",
              spades: "\u2660",
              clubs: "\u2663",
              hearts: "\u2665",
              diams: "\u2666",
              lang: "\u27E8",
              rang: "\u27E9"
            };
          },
          /* 15 */
          /***/
          function(module2, exports2, __webpack_require__) {
            "use strict";
            Object.defineProperty(exports2, "__esModule", { value: true });
            var error_handler_1 = __webpack_require__(10);
            var scanner_1 = __webpack_require__(12);
            var token_1 = __webpack_require__(13);
            var Reader = (function() {
              function Reader2() {
                this.values = [];
                this.curly = this.paren = -1;
              }
              Reader2.prototype.beforeFunctionExpression = function(t) {
                return [
                  "(",
                  "{",
                  "[",
                  "in",
                  "typeof",
                  "instanceof",
                  "new",
                  "return",
                  "case",
                  "delete",
                  "throw",
                  "void",
                  // assignment operators
                  "=",
                  "+=",
                  "-=",
                  "*=",
                  "**=",
                  "/=",
                  "%=",
                  "<<=",
                  ">>=",
                  ">>>=",
                  "&=",
                  "|=",
                  "^=",
                  ",",
                  // binary/unary operators
                  "+",
                  "-",
                  "*",
                  "**",
                  "/",
                  "%",
                  "++",
                  "--",
                  "<<",
                  ">>",
                  ">>>",
                  "&",
                  "|",
                  "^",
                  "!",
                  "~",
                  "&&",
                  "||",
                  "?",
                  ":",
                  "===",
                  "==",
                  ">=",
                  "<=",
                  "<",
                  ">",
                  "!=",
                  "!=="
                ].indexOf(t) >= 0;
              };
              Reader2.prototype.isRegexStart = function() {
                var previous = this.values[this.values.length - 1];
                var regex2 = previous !== null;
                switch (previous) {
                  case "this":
                  case "]":
                    regex2 = false;
                    break;
                  case ")":
                    var keyword = this.values[this.paren - 1];
                    regex2 = keyword === "if" || keyword === "while" || keyword === "for" || keyword === "with";
                    break;
                  case "}":
                    regex2 = false;
                    if (this.values[this.curly - 3] === "function") {
                      var check = this.values[this.curly - 4];
                      regex2 = check ? !this.beforeFunctionExpression(check) : false;
                    } else if (this.values[this.curly - 4] === "function") {
                      var check = this.values[this.curly - 5];
                      regex2 = check ? !this.beforeFunctionExpression(check) : true;
                    }
                    break;
                  default:
                    break;
                }
                return regex2;
              };
              Reader2.prototype.push = function(token) {
                if (token.type === 7 || token.type === 4) {
                  if (token.value === "{") {
                    this.curly = this.values.length;
                  } else if (token.value === "(") {
                    this.paren = this.values.length;
                  }
                  this.values.push(token.value);
                } else {
                  this.values.push(null);
                }
              };
              return Reader2;
            })();
            var Tokenizer = (function() {
              function Tokenizer2(code, config) {
                this.errorHandler = new error_handler_1.ErrorHandler();
                this.errorHandler.tolerant = config ? typeof config.tolerant === "boolean" && config.tolerant : false;
                this.scanner = new scanner_1.Scanner(code, this.errorHandler);
                this.scanner.trackComment = config ? typeof config.comment === "boolean" && config.comment : false;
                this.trackRange = config ? typeof config.range === "boolean" && config.range : false;
                this.trackLoc = config ? typeof config.loc === "boolean" && config.loc : false;
                this.buffer = [];
                this.reader = new Reader();
              }
              Tokenizer2.prototype.errors = function() {
                return this.errorHandler.errors;
              };
              Tokenizer2.prototype.getNextToken = function() {
                if (this.buffer.length === 0) {
                  var comments = this.scanner.scanComments();
                  if (this.scanner.trackComment) {
                    for (var i = 0; i < comments.length; ++i) {
                      var e = comments[i];
                      var value = this.scanner.source.slice(e.slice[0], e.slice[1]);
                      var comment = {
                        type: e.multiLine ? "BlockComment" : "LineComment",
                        value
                      };
                      if (this.trackRange) {
                        comment.range = e.range;
                      }
                      if (this.trackLoc) {
                        comment.loc = e.loc;
                      }
                      this.buffer.push(comment);
                    }
                  }
                  if (!this.scanner.eof()) {
                    var loc = void 0;
                    if (this.trackLoc) {
                      loc = {
                        start: {
                          line: this.scanner.lineNumber,
                          column: this.scanner.index - this.scanner.lineStart
                        },
                        end: {}
                      };
                    }
                    var startRegex = this.scanner.source[this.scanner.index] === "/" && this.reader.isRegexStart();
                    var token = startRegex ? this.scanner.scanRegExp() : this.scanner.lex();
                    this.reader.push(token);
                    var entry = {
                      type: token_1.TokenName[token.type],
                      value: this.scanner.source.slice(token.start, token.end)
                    };
                    if (this.trackRange) {
                      entry.range = [token.start, token.end];
                    }
                    if (this.trackLoc) {
                      loc.end = {
                        line: this.scanner.lineNumber,
                        column: this.scanner.index - this.scanner.lineStart
                      };
                      entry.loc = loc;
                    }
                    if (token.type === 9) {
                      var pattern = token.pattern;
                      var flags = token.flags;
                      entry.regex = { pattern, flags };
                    }
                    this.buffer.push(entry);
                  }
                }
                return this.buffer.shift();
              };
              return Tokenizer2;
            })();
            exports2.Tokenizer = Tokenizer;
          }
          /******/
        ])
      );
    });
  }
});

// node_modules/array-timsort/src/index.js
var require_src = __commonJS({
  "node_modules/array-timsort/src/index.js"(exports, module) {
    var DEFAULT_MIN_MERGE = 32;
    var DEFAULT_MIN_GALLOPING = 7;
    var DEFAULT_TMP_STORAGE_LENGTH = 256;
    var POWERS_OF_TEN = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9];
    var results;
    var log10 = (x) => x < 1e5 ? x < 100 ? x < 10 ? 0 : 1 : x < 1e4 ? x < 1e3 ? 2 : 3 : 4 : x < 1e7 ? x < 1e6 ? 5 : 6 : x < 1e9 ? x < 1e8 ? 7 : 8 : 9;
    function alphabeticalCompare(a, b) {
      if (a === b) {
        return 0;
      }
      if (~~a === a && ~~b === b) {
        if (a === 0 || b === 0) {
          return a < b ? -1 : 1;
        }
        if (a < 0 || b < 0) {
          if (b >= 0) {
            return -1;
          }
          if (a >= 0) {
            return 1;
          }
          a = -a;
          b = -b;
        }
        const al = log10(a);
        const bl = log10(b);
        let t = 0;
        if (al < bl) {
          a *= POWERS_OF_TEN[bl - al - 1];
          b /= 10;
          t = -1;
        } else if (al > bl) {
          b *= POWERS_OF_TEN[al - bl - 1];
          a /= 10;
          t = 1;
        }
        if (a === b) {
          return t;
        }
        return a < b ? -1 : 1;
      }
      const aStr = String(a);
      const bStr = String(b);
      if (aStr === bStr) {
        return 0;
      }
      return aStr < bStr ? -1 : 1;
    }
    function minRunLength(n) {
      let r = 0;
      while (n >= DEFAULT_MIN_MERGE) {
        r |= n & 1;
        n >>= 1;
      }
      return n + r;
    }
    function makeAscendingRun(array, lo, hi, compare) {
      let runHi = lo + 1;
      if (runHi === hi) {
        return 1;
      }
      if (compare(array[runHi++], array[lo]) < 0) {
        while (runHi < hi && compare(array[runHi], array[runHi - 1]) < 0) {
          runHi++;
        }
        reverseRun(array, lo, runHi);
        reverseRun(results, lo, runHi);
      } else {
        while (runHi < hi && compare(array[runHi], array[runHi - 1]) >= 0) {
          runHi++;
        }
      }
      return runHi - lo;
    }
    function reverseRun(array, lo, hi) {
      hi--;
      while (lo < hi) {
        const t = array[lo];
        array[lo++] = array[hi];
        array[hi--] = t;
      }
    }
    function binaryInsertionSort(array, lo, hi, start, compare) {
      if (start === lo) {
        start++;
      }
      for (; start < hi; start++) {
        const pivot = array[start];
        const pivotIndex = results[start];
        let left = lo;
        let right = start;
        while (left < right) {
          const mid = left + right >>> 1;
          if (compare(pivot, array[mid]) < 0) {
            right = mid;
          } else {
            left = mid + 1;
          }
        }
        let n = start - left;
        switch (n) {
          case 3:
            array[left + 3] = array[left + 2];
            results[left + 3] = results[left + 2];
          /* falls through */
          case 2:
            array[left + 2] = array[left + 1];
            results[left + 2] = results[left + 1];
          /* falls through */
          case 1:
            array[left + 1] = array[left];
            results[left + 1] = results[left];
            break;
          default:
            while (n > 0) {
              array[left + n] = array[left + n - 1];
              results[left + n] = results[left + n - 1];
              n--;
            }
        }
        array[left] = pivot;
        results[left] = pivotIndex;
      }
    }
    function gallopLeft(value, array, start, length, hint, compare) {
      let lastOffset = 0;
      let maxOffset = 0;
      let offset = 1;
      if (compare(value, array[start + hint]) > 0) {
        maxOffset = length - hint;
        while (offset < maxOffset && compare(value, array[start + hint + offset]) > 0) {
          lastOffset = offset;
          offset = (offset << 1) + 1;
          if (offset <= 0) {
            offset = maxOffset;
          }
        }
        if (offset > maxOffset) {
          offset = maxOffset;
        }
        lastOffset += hint;
        offset += hint;
      } else {
        maxOffset = hint + 1;
        while (offset < maxOffset && compare(value, array[start + hint - offset]) <= 0) {
          lastOffset = offset;
          offset = (offset << 1) + 1;
          if (offset <= 0) {
            offset = maxOffset;
          }
        }
        if (offset > maxOffset) {
          offset = maxOffset;
        }
        const tmp = lastOffset;
        lastOffset = hint - offset;
        offset = hint - tmp;
      }
      lastOffset++;
      while (lastOffset < offset) {
        const m = lastOffset + (offset - lastOffset >>> 1);
        if (compare(value, array[start + m]) > 0) {
          lastOffset = m + 1;
        } else {
          offset = m;
        }
      }
      return offset;
    }
    function gallopRight(value, array, start, length, hint, compare) {
      let lastOffset = 0;
      let maxOffset = 0;
      let offset = 1;
      if (compare(value, array[start + hint]) < 0) {
        maxOffset = hint + 1;
        while (offset < maxOffset && compare(value, array[start + hint - offset]) < 0) {
          lastOffset = offset;
          offset = (offset << 1) + 1;
          if (offset <= 0) {
            offset = maxOffset;
          }
        }
        if (offset > maxOffset) {
          offset = maxOffset;
        }
        const tmp = lastOffset;
        lastOffset = hint - offset;
        offset = hint - tmp;
      } else {
        maxOffset = length - hint;
        while (offset < maxOffset && compare(value, array[start + hint + offset]) >= 0) {
          lastOffset = offset;
          offset = (offset << 1) + 1;
          if (offset <= 0) {
            offset = maxOffset;
          }
        }
        if (offset > maxOffset) {
          offset = maxOffset;
        }
        lastOffset += hint;
        offset += hint;
      }
      lastOffset++;
      while (lastOffset < offset) {
        const m = lastOffset + (offset - lastOffset >>> 1);
        if (compare(value, array[start + m]) < 0) {
          offset = m;
        } else {
          lastOffset = m + 1;
        }
      }
      return offset;
    }
    var TimSort = class {
      constructor(array, compare) {
        this.array = array;
        this.compare = compare;
        const { length } = array;
        this.length = length;
        this.minGallop = DEFAULT_MIN_GALLOPING;
        this.tmpStorageLength = length < 2 * DEFAULT_TMP_STORAGE_LENGTH ? length >>> 1 : DEFAULT_TMP_STORAGE_LENGTH;
        this.tmp = new Array(this.tmpStorageLength);
        this.tmpIndex = new Array(this.tmpStorageLength);
        this.stackLength = length < 120 ? 5 : length < 1542 ? 10 : length < 119151 ? 19 : 40;
        this.runStart = new Array(this.stackLength);
        this.runLength = new Array(this.stackLength);
        this.stackSize = 0;
      }
      /**
       * Push a new run on TimSort's stack.
       *
       * @param {number} runStart - Start index of the run in the original array.
       * @param {number} runLength - Length of the run;
       */
      pushRun(runStart, runLength) {
        this.runStart[this.stackSize] = runStart;
        this.runLength[this.stackSize] = runLength;
        this.stackSize += 1;
      }
      /**
       * Merge runs on TimSort's stack so that the following holds for all i:
       * 1) runLength[i - 3] > runLength[i - 2] + runLength[i - 1]
       * 2) runLength[i - 2] > runLength[i - 1]
       */
      mergeRuns() {
        while (this.stackSize > 1) {
          let n = this.stackSize - 2;
          if (n >= 1 && this.runLength[n - 1] <= this.runLength[n] + this.runLength[n + 1] || n >= 2 && this.runLength[n - 2] <= this.runLength[n] + this.runLength[n - 1]) {
            if (this.runLength[n - 1] < this.runLength[n + 1]) {
              n--;
            }
          } else if (this.runLength[n] > this.runLength[n + 1]) {
            break;
          }
          this.mergeAt(n);
        }
      }
      /**
       * Merge all runs on TimSort's stack until only one remains.
       */
      forceMergeRuns() {
        while (this.stackSize > 1) {
          let n = this.stackSize - 2;
          if (n > 0 && this.runLength[n - 1] < this.runLength[n + 1]) {
            n--;
          }
          this.mergeAt(n);
        }
      }
      /**
       * Merge the runs on the stack at positions i and i+1. Must be always be called
       * with i=stackSize-2 or i=stackSize-3 (that is, we merge on top of the stack).
       *
       * @param {number} i - Index of the run to merge in TimSort's stack.
       */
      mergeAt(i) {
        const { compare } = this;
        const { array } = this;
        let start1 = this.runStart[i];
        let length1 = this.runLength[i];
        const start2 = this.runStart[i + 1];
        let length2 = this.runLength[i + 1];
        this.runLength[i] = length1 + length2;
        if (i === this.stackSize - 3) {
          this.runStart[i + 1] = this.runStart[i + 2];
          this.runLength[i + 1] = this.runLength[i + 2];
        }
        this.stackSize--;
        const k = gallopRight(array[start2], array, start1, length1, 0, compare);
        start1 += k;
        length1 -= k;
        if (length1 === 0) {
          return;
        }
        length2 = gallopLeft(
          array[start1 + length1 - 1],
          array,
          start2,
          length2,
          length2 - 1,
          compare
        );
        if (length2 === 0) {
          return;
        }
        if (length1 <= length2) {
          this.mergeLow(start1, length1, start2, length2);
        } else {
          this.mergeHigh(start1, length1, start2, length2);
        }
      }
      /**
       * Merge two adjacent runs in a stable way. The runs must be such that the
       * first element of run1 is bigger than the first element in run2 and the
       * last element of run1 is greater than all the elements in run2.
       * The method should be called when run1.length <= run2.length as it uses
       * TimSort temporary array to store run1. Use mergeHigh if run1.length >
       * run2.length.
       *
       * @param {number} start1 - First element in run1.
       * @param {number} length1 - Length of run1.
       * @param {number} start2 - First element in run2.
       * @param {number} length2 - Length of run2.
       */
      mergeLow(start1, length1, start2, length2) {
        const { compare } = this;
        const { array } = this;
        const { tmp } = this;
        const { tmpIndex } = this;
        let i = 0;
        for (i = 0; i < length1; i++) {
          tmp[i] = array[start1 + i];
          tmpIndex[i] = results[start1 + i];
        }
        let cursor1 = 0;
        let cursor2 = start2;
        let dest = start1;
        array[dest] = array[cursor2];
        results[dest] = results[cursor2];
        dest++;
        cursor2++;
        if (--length2 === 0) {
          for (i = 0; i < length1; i++) {
            array[dest + i] = tmp[cursor1 + i];
            results[dest + i] = tmpIndex[cursor1 + i];
          }
          return;
        }
        if (length1 === 1) {
          for (i = 0; i < length2; i++) {
            array[dest + i] = array[cursor2 + i];
            results[dest + i] = results[cursor2 + i];
          }
          array[dest + length2] = tmp[cursor1];
          results[dest + length2] = tmpIndex[cursor1];
          return;
        }
        let { minGallop } = this;
        while (true) {
          let count1 = 0;
          let count2 = 0;
          let exit = false;
          do {
            if (compare(array[cursor2], tmp[cursor1]) < 0) {
              array[dest] = array[cursor2];
              results[dest] = results[cursor2];
              dest++;
              cursor2++;
              count2++;
              count1 = 0;
              if (--length2 === 0) {
                exit = true;
                break;
              }
            } else {
              array[dest] = tmp[cursor1];
              results[dest] = tmpIndex[cursor1];
              dest++;
              cursor1++;
              count1++;
              count2 = 0;
              if (--length1 === 1) {
                exit = true;
                break;
              }
            }
          } while ((count1 | count2) < minGallop);
          if (exit) {
            break;
          }
          do {
            count1 = gallopRight(array[cursor2], tmp, cursor1, length1, 0, compare);
            if (count1 !== 0) {
              for (i = 0; i < count1; i++) {
                array[dest + i] = tmp[cursor1 + i];
                results[dest + i] = tmpIndex[cursor1 + i];
              }
              dest += count1;
              cursor1 += count1;
              length1 -= count1;
              if (length1 <= 1) {
                exit = true;
                break;
              }
            }
            array[dest] = array[cursor2];
            results[dest] = results[cursor2];
            dest++;
            cursor2++;
            if (--length2 === 0) {
              exit = true;
              break;
            }
            count2 = gallopLeft(tmp[cursor1], array, cursor2, length2, 0, compare);
            if (count2 !== 0) {
              for (i = 0; i < count2; i++) {
                array[dest + i] = array[cursor2 + i];
                results[dest + i] = results[cursor2 + i];
              }
              dest += count2;
              cursor2 += count2;
              length2 -= count2;
              if (length2 === 0) {
                exit = true;
                break;
              }
            }
            array[dest] = tmp[cursor1];
            results[dest] = tmpIndex[cursor1];
            dest++;
            cursor1++;
            if (--length1 === 1) {
              exit = true;
              break;
            }
            minGallop--;
          } while (count1 >= DEFAULT_MIN_GALLOPING || count2 >= DEFAULT_MIN_GALLOPING);
          if (exit) {
            break;
          }
          if (minGallop < 0) {
            minGallop = 0;
          }
          minGallop += 2;
        }
        this.minGallop = minGallop;
        if (minGallop < 1) {
          this.minGallop = 1;
        }
        if (length1 === 1) {
          for (i = 0; i < length2; i++) {
            array[dest + i] = array[cursor2 + i];
            results[dest + i] = results[cursor2 + i];
          }
          array[dest + length2] = tmp[cursor1];
          results[dest + length2] = tmpIndex[cursor1];
        } else if (length1 === 0) {
          throw new Error("mergeLow preconditions were not respected");
        } else {
          for (i = 0; i < length1; i++) {
            array[dest + i] = tmp[cursor1 + i];
            results[dest + i] = tmpIndex[cursor1 + i];
          }
        }
      }
      /**
       * Merge two adjacent runs in a stable way. The runs must be such that the
       * first element of run1 is bigger than the first element in run2 and the
       * last element of run1 is greater than all the elements in run2.
       * The method should be called when run1.length > run2.length as it uses
       * TimSort temporary array to store run2. Use mergeLow if run1.length <=
       * run2.length.
       *
       * @param {number} start1 - First element in run1.
       * @param {number} length1 - Length of run1.
       * @param {number} start2 - First element in run2.
       * @param {number} length2 - Length of run2.
       */
      mergeHigh(start1, length1, start2, length2) {
        const { compare } = this;
        const { array } = this;
        const { tmp } = this;
        const { tmpIndex } = this;
        let i = 0;
        for (i = 0; i < length2; i++) {
          tmp[i] = array[start2 + i];
          tmpIndex[i] = results[start2 + i];
        }
        let cursor1 = start1 + length1 - 1;
        let cursor2 = length2 - 1;
        let dest = start2 + length2 - 1;
        let customCursor = 0;
        let customDest = 0;
        array[dest] = array[cursor1];
        results[dest] = results[cursor1];
        dest--;
        cursor1--;
        if (--length1 === 0) {
          customCursor = dest - (length2 - 1);
          for (i = 0; i < length2; i++) {
            array[customCursor + i] = tmp[i];
            results[customCursor + i] = tmpIndex[i];
          }
          return;
        }
        if (length2 === 1) {
          dest -= length1;
          cursor1 -= length1;
          customDest = dest + 1;
          customCursor = cursor1 + 1;
          for (i = length1 - 1; i >= 0; i--) {
            array[customDest + i] = array[customCursor + i];
            results[customDest + i] = results[customCursor + i];
          }
          array[dest] = tmp[cursor2];
          results[dest] = tmpIndex[cursor2];
          return;
        }
        let { minGallop } = this;
        while (true) {
          let count1 = 0;
          let count2 = 0;
          let exit = false;
          do {
            if (compare(tmp[cursor2], array[cursor1]) < 0) {
              array[dest] = array[cursor1];
              results[dest] = results[cursor1];
              dest--;
              cursor1--;
              count1++;
              count2 = 0;
              if (--length1 === 0) {
                exit = true;
                break;
              }
            } else {
              array[dest] = tmp[cursor2];
              results[dest] = tmpIndex[cursor2];
              dest--;
              cursor2--;
              count2++;
              count1 = 0;
              if (--length2 === 1) {
                exit = true;
                break;
              }
            }
          } while ((count1 | count2) < minGallop);
          if (exit) {
            break;
          }
          do {
            count1 = length1 - gallopRight(
              tmp[cursor2],
              array,
              start1,
              length1,
              length1 - 1,
              compare
            );
            if (count1 !== 0) {
              dest -= count1;
              cursor1 -= count1;
              length1 -= count1;
              customDest = dest + 1;
              customCursor = cursor1 + 1;
              for (i = count1 - 1; i >= 0; i--) {
                array[customDest + i] = array[customCursor + i];
                results[customDest + i] = results[customCursor + i];
              }
              if (length1 === 0) {
                exit = true;
                break;
              }
            }
            array[dest] = tmp[cursor2];
            results[dest] = tmpIndex[cursor2];
            dest--;
            cursor2--;
            if (--length2 === 1) {
              exit = true;
              break;
            }
            count2 = length2 - gallopLeft(
              array[cursor1],
              tmp,
              0,
              length2,
              length2 - 1,
              compare
            );
            if (count2 !== 0) {
              dest -= count2;
              cursor2 -= count2;
              length2 -= count2;
              customDest = dest + 1;
              customCursor = cursor2 + 1;
              for (i = 0; i < count2; i++) {
                array[customDest + i] = tmp[customCursor + i];
                results[customDest + i] = tmpIndex[customCursor + i];
              }
              if (length2 <= 1) {
                exit = true;
                break;
              }
            }
            array[dest] = array[cursor1];
            results[dest] = results[cursor1];
            dest--;
            cursor1--;
            if (--length1 === 0) {
              exit = true;
              break;
            }
            minGallop--;
          } while (count1 >= DEFAULT_MIN_GALLOPING || count2 >= DEFAULT_MIN_GALLOPING);
          if (exit) {
            break;
          }
          if (minGallop < 0) {
            minGallop = 0;
          }
          minGallop += 2;
        }
        this.minGallop = minGallop;
        if (minGallop < 1) {
          this.minGallop = 1;
        }
        if (length2 === 1) {
          dest -= length1;
          cursor1 -= length1;
          customDest = dest + 1;
          customCursor = cursor1 + 1;
          for (i = length1 - 1; i >= 0; i--) {
            array[customDest + i] = array[customCursor + i];
            results[customDest + i] = results[customCursor + i];
          }
          array[dest] = tmp[cursor2];
          results[dest] = tmpIndex[cursor2];
        } else if (length2 === 0) {
          throw new Error("mergeHigh preconditions were not respected");
        } else {
          customCursor = dest - (length2 - 1);
          for (i = 0; i < length2; i++) {
            array[customCursor + i] = tmp[i];
            results[customCursor + i] = tmpIndex[i];
          }
        }
      }
    };
    function sort(array, compare, lo, hi) {
      if (!Array.isArray(array)) {
        throw new TypeError(
          `The "array" argument must be an array. Received ${array}`
        );
      }
      results = [];
      const { length } = array;
      let i = 0;
      while (i < length) {
        results[i] = i++;
      }
      if (!compare) {
        compare = alphabeticalCompare;
      } else if (typeof compare !== "function") {
        hi = lo;
        lo = compare;
        compare = alphabeticalCompare;
      }
      if (!lo) {
        lo = 0;
      }
      if (!hi) {
        hi = length;
      }
      let remaining = hi - lo;
      if (remaining < 2) {
        return results;
      }
      let runLength = 0;
      if (remaining < DEFAULT_MIN_MERGE) {
        runLength = makeAscendingRun(array, lo, hi, compare);
        binaryInsertionSort(array, lo, hi, lo + runLength, compare);
        return results;
      }
      const ts = new TimSort(array, compare);
      const minRun = minRunLength(remaining);
      do {
        runLength = makeAscendingRun(array, lo, hi, compare);
        if (runLength < minRun) {
          let force = remaining;
          if (force > minRun) {
            force = minRun;
          }
          binaryInsertionSort(array, lo, lo + force, lo + runLength, compare);
          runLength = force;
        }
        ts.pushRun(lo, runLength);
        ts.mergeRuns();
        remaining -= runLength;
        lo += runLength;
      } while (remaining !== 0);
      ts.forceMergeRuns();
      return results;
    }
    module.exports = {
      sort
    };
  }
});

// node_modules/comment-json/src/common.js
var require_common = __commonJS({
  "node_modules/comment-json/src/common.js"(exports, module) {
    var PREFIX_BEFORE = "before";
    var PREFIX_AFTER_PROP = "after-prop";
    var PREFIX_AFTER_COLON = "after-colon";
    var PREFIX_AFTER_VALUE = "after-value";
    var PREFIX_AFTER = "after";
    var PREFIX_BEFORE_ALL = "before-all";
    var PREFIX_AFTER_ALL = "after-all";
    var BRACKET_OPEN = "[";
    var BRACKET_CLOSE = "]";
    var CURLY_BRACKET_OPEN = "{";
    var CURLY_BRACKET_CLOSE = "}";
    var COMMA = ",";
    var EMPTY = "";
    var MINUS = "-";
    var PROP_SYMBOL_PREFIXES = [
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER
    ];
    var NON_PROP_SYMBOL_PREFIXES = [
      PREFIX_BEFORE,
      PREFIX_AFTER,
      PREFIX_BEFORE_ALL,
      PREFIX_AFTER_ALL
    ];
    var NON_PROP_SYMBOL_KEYS = NON_PROP_SYMBOL_PREFIXES.map(Symbol.for);
    var COLON = ":";
    var UNDEFINED = void 0;
    var LINE_BREAKS_BEFORE = /* @__PURE__ */ new WeakMap();
    var LINE_BREAKS_AFTER = /* @__PURE__ */ new WeakMap();
    var RAW_STRING_LITERALS = /* @__PURE__ */ new WeakMap();
    var is_string = (subject) => typeof subject === "string";
    var is_number = (subject) => typeof subject === "number";
    var is_object = (v) => typeof v === "object" && v !== null;
    var normalize_key = (key) => is_string(key) || is_number(key) ? String(key) : null;
    var set_raw_string_literal = (host, key, raw) => {
      if (!is_object(host) || !is_string(raw)) {
        return;
      }
      const normalized = normalize_key(key);
      if (normalized === null) {
        return;
      }
      let map = RAW_STRING_LITERALS.get(host);
      if (!map) {
        map = /* @__PURE__ */ new Map();
        RAW_STRING_LITERALS.set(host, map);
      }
      map.set(normalized, raw);
    };
    var get_raw_string_literal = (host, key) => {
      if (!is_object(host)) {
        return;
      }
      const normalized = normalize_key(key);
      if (normalized === null) {
        return;
      }
      const map = RAW_STRING_LITERALS.get(host);
      return map ? map.get(normalized) : void 0;
    };
    var symbol = (prefix, key) => Symbol.for(prefix + COLON + key);
    var symbol_checked = (prefix, key) => {
      if (key) {
        if (PROP_SYMBOL_PREFIXES.includes(prefix)) {
          return symbol(prefix, key);
        }
        throw new RangeError(
          `Unsupported comment position ${prefix} with key ${key}`
        );
      }
      if (NON_PROP_SYMBOL_PREFIXES.includes(prefix)) {
        return Symbol.for(prefix);
      }
      throw new RangeError(`Unsupported comment position ${prefix}`);
    };
    var define2 = (target, key, value) => Object.defineProperty(target, key, {
      value,
      writable: true,
      configurable: true
    });
    var copy_comments_by_kind = (target, source, target_key, source_key, prefix, remove_source) => {
      const source_prop = symbol(prefix, source_key);
      if (!Object.hasOwn(source, source_prop)) {
        return;
      }
      const target_prop = target_key === source_key ? source_prop : symbol(prefix, target_key);
      define2(target, target_prop, source[source_prop]);
      if (remove_source) {
        delete source[source_prop];
      }
    };
    var copy_comments = (target, source, target_key, source_key, remove_source) => {
      PROP_SYMBOL_PREFIXES.forEach((prefix) => {
        copy_comments_by_kind(
          target,
          source,
          target_key,
          source_key,
          prefix,
          remove_source
        );
      });
    };
    var swap_comments = (array, from, to) => {
      if (from === to) {
        return;
      }
      PROP_SYMBOL_PREFIXES.forEach((prefix) => {
        const target_prop = symbol(prefix, to);
        if (!Object.hasOwn(array, target_prop)) {
          copy_comments_by_kind(array, array, to, from, prefix, true);
          return;
        }
        const comments = array[target_prop];
        delete array[target_prop];
        copy_comments_by_kind(array, array, to, from, prefix, true);
        define2(array, symbol(prefix, from), comments);
      });
    };
    var assign_non_prop_comments = (target, source) => {
      NON_PROP_SYMBOL_KEYS.forEach((key) => {
        const comments = source[key];
        if (comments) {
          define2(target, key, comments);
        }
      });
    };
    var assign = (target, source, keys) => {
      keys.forEach((key) => {
        if (typeof key !== "string" && typeof key !== "number") {
          return;
        }
        if (!Object.hasOwn(source, key)) {
          return;
        }
        target[key] = source[key];
        copy_comments(target, source, key, key);
      });
      return target;
    };
    var is_raw_json = typeof JSON.isRawJSON === "function" ? JSON.isRawJSON : () => false;
    var set_comment_line_breaks = (comment, before, after) => {
      if (is_number(before) && before >= 0) {
        LINE_BREAKS_BEFORE.set(comment, before);
      }
      if (is_number(after) && after >= 0) {
        LINE_BREAKS_AFTER.set(comment, after);
      }
    };
    var get_comment_line_breaks_before = (comment) => LINE_BREAKS_BEFORE.get(comment);
    var get_comment_line_breaks_after = (comment) => LINE_BREAKS_AFTER.get(comment);
    module.exports = {
      PROP_SYMBOL_PREFIXES,
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER,
      PREFIX_BEFORE_ALL,
      PREFIX_AFTER_ALL,
      BRACKET_OPEN,
      BRACKET_CLOSE,
      CURLY_BRACKET_OPEN,
      CURLY_BRACKET_CLOSE,
      COLON,
      COMMA,
      MINUS,
      EMPTY,
      UNDEFINED,
      symbol,
      define: define2,
      copy_comments,
      swap_comments,
      assign_non_prop_comments,
      is_string,
      is_number,
      is_object,
      is_raw_json,
      set_raw_string_literal,
      get_raw_string_literal,
      set_comment_line_breaks,
      get_comment_line_breaks_before,
      get_comment_line_breaks_after,
      /**
       * Assign properties and comments from source to target object.
       *
       * @param {Object} target The target object to assign properties and comments
       *   to.
       * @param {Object} source The source object to copy properties and comments
       *   from.
       * @param {Array<string|number>} [keys] Optional array of keys to assign. If
       *   not provided, all keys and non-property comments are assigned. If empty
       *   array, only non-property comments are assigned.
       * @returns {Object} The target object with assigned properties and comments.
       *
       * @throws {TypeError} If target cannot be converted to object or keys is not
       *   array or undefined.
       *
       * @example
       * const source = parse('{"a": 1 // comment a, "b": 2 // comment b}')
       * const target = {}
       *
       * // Copy all properties and comments
       * assign(target, source)
       *
       * // Copy only specific properties and their comments
       * assign(target, source, ['a'])
       *
       * // Copy only non-property comments
       * assign(target, source, [])
       */
      assign(target, source, keys) {
        if (!is_object(target)) {
          throw new TypeError("Cannot convert undefined or null to object");
        }
        if (!is_object(source)) {
          return target;
        }
        if (keys === UNDEFINED) {
          keys = Object.keys(source);
          assign_non_prop_comments(target, source);
        } else if (!Array.isArray(keys)) {
          throw new TypeError("keys must be array or undefined");
        } else if (keys.length === 0) {
          assign_non_prop_comments(target, source);
        }
        return assign(target, source, keys);
      },
      /**
       * Move comments from one location to another within objects.
       *
       * @param {Object} source The source object containing comments to move.
       * @param {Object} [target] The target object to move comments to. If not
       *   provided, defaults to source (move within same object).
       * @param {Object} from The source comment location.
       * @param {string} from.where The comment position (e.g., 'before',
       *   'after', 'before-all', etc.).
       * @param {string} [from.key] The property key for property-specific comments.
       *   Omit for non-property comments.
       * @param {Object} to The target comment location.
       * @param {string} to.where The comment position (e.g., 'before',
       *   'after', 'before-all', etc.).
       * @param {string} [to.key] The property key for property-specific comments.
       *   Omit for non-property comments.
       * @param {boolean} [override=false] Whether to override existing comments at
       *   the target location. If false, comments will be appended.
       *
       * @throws {TypeError} If source is not an object.
       * @throws {RangeError} If where parameter is invalid or incompatible with key.
       *
       * @example
       * const obj = parse('{"a": 1 // comment on a}')
       *
       * // Move comment from after 'a' to before 'a'
       * moveComments(obj, obj,
       *   { where: 'after', key: 'a' },
       *   { where: 'before', key: 'a' }
       * )
       *
       * @example
       * // Move non-property comment
       * moveComments(obj, obj,
       *   { where: 'before-all' },
       *   { where: 'after-all' }
       * )
       */
      moveComments(source, target, {
        where: from_where,
        key: from_key
      }, {
        where: to_where,
        key: to_key
      }, override = false) {
        if (!is_object(source)) {
          throw new TypeError("source must be an object");
        }
        if (!target) {
          target = source;
        }
        if (!is_object(target)) {
          return;
        }
        const from_prop = symbol_checked(from_where, from_key);
        const to_prop = symbol_checked(to_where, to_key);
        if (!Object.hasOwn(source, from_prop)) {
          return;
        }
        const source_comments = source[from_prop];
        delete source[from_prop];
        if (override || !Object.hasOwn(target, to_prop)) {
          define2(target, to_prop, source_comments);
          return;
        }
        const target_comments = target[to_prop];
        if (target_comments) {
          target_comments.push(...source_comments);
        }
      },
      /**
       * Remove comments from a specific location within an object.
       *
       * @param {Object} target The target object to remove comments from.
       * @param {Object} location The comment location to remove.
       * @param {string} location.where The comment position (e.g., 'before',
       *   'after', 'before-all', etc.).
       * @param {string} [location.key] The property key for property-specific
       *   comments. Omit for non-property comments.
       *
       * @throws {TypeError} If target is not an object.
       * @throws {RangeError} If where parameter is invalid or incompatible with key.
       *
       * @example
       * const obj = parse('{"a": 1 // comment on a}')
       *
       * // Remove comment after 'a'
       * removeComments(obj, { where: 'after', key: 'a' })
       *
       * @example
       * // Remove non-property comment
       * removeComments(obj, { where: 'before-all' })
       */
      removeComments(target, {
        where,
        key
      }) {
        if (!is_object(target)) {
          throw new TypeError("target must be an object");
        }
        const prop = symbol_checked(where, key);
        if (!Object.hasOwn(target, prop)) {
          return;
        }
        delete target[prop];
      }
    };
  }
});

// node_modules/comment-json/src/array.js
var require_array = __commonJS({
  "node_modules/comment-json/src/array.js"(exports, module) {
    var { sort } = require_src();
    var {
      PROP_SYMBOL_PREFIXES,
      UNDEFINED,
      symbol,
      copy_comments,
      swap_comments
    } = require_common();
    var reverse_comments = (array) => {
      const { length } = array;
      let i = 0;
      const max = length / 2;
      for (; i < max; i++) {
        swap_comments(array, i, length - i - 1);
      }
    };
    var move_comment = (target, source, i, offset, remove) => {
      copy_comments(target, source, i + offset, i, remove);
    };
    var move_comments = (target, source, start, count, offset, remove) => {
      if (offset > 0) {
        let i2 = count;
        while (i2-- > 0) {
          move_comment(target, source, start + i2, offset, remove);
        }
        return;
      }
      let i = 0;
      while (i < count) {
        const ii = i++;
        move_comment(target, source, start + ii, offset, remove);
      }
    };
    var remove_comments = (array, key) => {
      PROP_SYMBOL_PREFIXES.forEach((prefix) => {
        const prop = symbol(prefix, key);
        delete array[prop];
      });
    };
    var get_mapped = (map, key) => {
      let mapped = key;
      while (mapped in map) {
        mapped = map[mapped];
      }
      return mapped;
    };
    var CommentArray = class _CommentArray extends Array {
      // - deleteCount + items.length
      // We should avoid `splice(begin, deleteCount, ...items)`,
      // because `splice(0, undefined)` is not equivalent to `splice(0)`,
      // as well as:
      // - slice
      /**
       * Changes the contents of an array by removing or replacing existing
       *   elements and/or adding new elements in place.
       * Comments are automatically preserved and repositioned during the operation.
       *
       * @param {...*} args Arguments passed to Array.prototype.splice
       * @returns {CommentArray} A new CommentArray containing the deleted elements.
       */
      splice(...args) {
        const { length } = this;
        const ret = super.splice(...args);
        let [begin, deleteCount, ...items] = args;
        if (begin < 0) {
          begin += length;
        }
        if (arguments.length === 1) {
          deleteCount = length - begin;
        } else {
          deleteCount = Math.min(length - begin, deleteCount);
        }
        const {
          length: item_length
        } = items;
        const offset = item_length - deleteCount;
        const start = begin + deleteCount;
        const count = length - start;
        move_comments(this, this, start, count, offset, true);
        return ret;
      }
      /**
       * Returns a shallow copy of a portion of an array into a new CommentArray object.
       * Comments are copied to the appropriate positions in the new array.
       *
       * @param {...*} args Arguments passed to Array.prototype.slice
       * @returns {CommentArray} A new CommentArray containing the extracted
       *   elements with their comments.
       */
      slice(...args) {
        const { length } = this;
        const array = super.slice(...args);
        if (!array.length) {
          return new _CommentArray();
        }
        let [begin, before] = args;
        if (before === UNDEFINED) {
          before = length;
        } else if (before < 0) {
          before += length;
        }
        if (begin < 0) {
          begin += length;
        } else if (begin === UNDEFINED) {
          begin = 0;
        }
        move_comments(array, this, begin, before - begin, -begin);
        return array;
      }
      unshift(...items) {
        const { length } = this;
        const ret = super.unshift(...items);
        const {
          length: items_length
        } = items;
        if (items_length > 0) {
          move_comments(this, this, 0, length, items_length, true);
        }
        return ret;
      }
      shift() {
        const ret = super.shift();
        const { length } = this;
        remove_comments(this, 0);
        move_comments(this, this, 1, length, -1, true);
        return ret;
      }
      reverse() {
        super.reverse();
        reverse_comments(this);
        return this;
      }
      pop() {
        const ret = super.pop();
        remove_comments(this, this.length);
        return ret;
      }
      concat(...items) {
        let { length } = this;
        const ret = super.concat(...items);
        if (!items.length) {
          return ret;
        }
        move_comments(ret, this, 0, this.length, 0);
        items.forEach((item) => {
          const prev = length;
          length += Array.isArray(item) ? item.length : 1;
          if (!(item instanceof _CommentArray)) {
            return;
          }
          move_comments(ret, item, 0, item.length, prev);
        });
        return ret;
      }
      sort(...args) {
        const result = sort(
          this,
          ...args.slice(0, 1)
        );
        const map = /* @__PURE__ */ Object.create(null);
        result.forEach((source_index, index) => {
          if (source_index === index) {
            return;
          }
          const real_source_index = get_mapped(map, source_index);
          if (real_source_index === index) {
            return;
          }
          map[index] = real_source_index;
          swap_comments(this, index, real_source_index);
        });
        return this;
      }
    };
    module.exports = {
      CommentArray
    };
  }
});

// node_modules/comment-json/src/parse.js
var require_parse = __commonJS({
  "node_modules/comment-json/src/parse.js"(exports, module) {
    var esprima = require_esprima();
    var {
      CommentArray
    } = require_array();
    var {
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER,
      PREFIX_BEFORE_ALL,
      PREFIX_AFTER_ALL,
      BRACKET_OPEN,
      BRACKET_CLOSE,
      CURLY_BRACKET_OPEN,
      CURLY_BRACKET_CLOSE,
      COLON,
      COMMA,
      MINUS,
      EMPTY,
      UNDEFINED,
      is_object,
      define: define2,
      set_raw_string_literal,
      set_comment_line_breaks,
      assign_non_prop_comments
    } = require_common();
    var tokenize = (code) => esprima.tokenize(code, {
      comment: true,
      loc: true
    });
    var current_code;
    var previous_hosts = [];
    var comments_host = null;
    var unassigned_comments = null;
    var previous_props = [];
    var last_prop;
    var remove_comments = false;
    var inline = false;
    var tokens = null;
    var last = null;
    var current = null;
    var index;
    var reviver = null;
    var clean = () => {
      current_code = UNDEFINED;
      previous_props.length = previous_hosts.length = 0;
      last = null;
      last_prop = UNDEFINED;
    };
    var free = () => {
      clean();
      tokens.length = 0;
      unassigned_comments = comments_host = tokens = last = current = reviver = null;
      current_code = UNDEFINED;
    };
    var symbolFor = (prefix) => Symbol.for(
      last_prop !== UNDEFINED ? prefix + COLON + last_prop : prefix
    );
    var transform = (k, { value, context = {} }) => reviver ? reviver(k, value, context) : value;
    var unexpected = () => {
      const error = new SyntaxError(`Unexpected token '${current.value.slice(0, 1)}', "${current_code}" is not valid JSON`);
      Object.assign(error, current.loc.start);
      free();
      throw error;
    };
    var unexpected_end = () => {
      const error = new SyntaxError("Unexpected end of JSON input");
      Object.assign(error, last ? last.loc.end : {
        line: 1,
        column: 0
      });
      free();
      throw error;
    };
    var next = () => {
      const new_token = tokens[++index];
      inline = current && new_token && current.loc.end.line === new_token.loc.start.line || false;
      last = current;
      current = new_token;
    };
    var type = () => {
      if (!current) {
        unexpected_end();
      }
      return current.type === "Punctuator" ? current.value : current.type;
    };
    var is = (t) => type() === t;
    var expect = (a) => {
      if (!is(a)) {
        unexpected();
      }
    };
    var set_comments_host = (new_host) => {
      previous_hosts.push(comments_host);
      comments_host = new_host;
    };
    var restore_comments_host = () => {
      comments_host = previous_hosts.pop();
    };
    var assign_after_comments = () => {
      if (!unassigned_comments) {
        return;
      }
      const after_comments = [];
      for (const comment of unassigned_comments) {
        if (comment.inline) {
          after_comments.push(comment);
        } else {
          break;
        }
      }
      const { length } = after_comments;
      if (!length) {
        return;
      }
      if (length === unassigned_comments.length) {
        unassigned_comments = null;
      } else {
        unassigned_comments.splice(0, length);
      }
      define2(comments_host, symbolFor(PREFIX_AFTER), after_comments);
    };
    var assign_comments = (prefix) => {
      if (!unassigned_comments) {
        return;
      }
      define2(comments_host, symbolFor(prefix), unassigned_comments);
      unassigned_comments = null;
    };
    var parse_comments = (prefix) => {
      const comments = [];
      while (current && (is("LineComment") || is("BlockComment"))) {
        const comment = {
          ...current,
          inline
        };
        const previous_line = last ? last.loc.end.line : 1;
        set_comment_line_breaks(
          comment,
          Math.max(0, comment.loc.start.line - previous_line)
        );
        comments.push(comment);
        next();
      }
      const { length } = comments;
      if (length) {
        const comment = comments[length - 1];
        const current_line = current ? current.loc.start.line : comment.loc.end.line;
        set_comment_line_breaks(
          comment,
          void 0,
          Math.max(0, current_line - comment.loc.end.line)
        );
      }
      if (remove_comments) {
        return;
      }
      if (!length) {
        return;
      }
      if (prefix) {
        define2(comments_host, symbolFor(prefix), comments);
        return;
      }
      unassigned_comments = comments;
    };
    var set_prop = (prop, push) => {
      if (push) {
        previous_props.push(last_prop);
      }
      last_prop = prop;
    };
    var restore_prop = () => {
      last_prop = previous_props.pop();
    };
    var parse_object = () => {
      const obj = {};
      set_comments_host(obj);
      set_prop(UNDEFINED, true);
      let started = false;
      let name;
      parse_comments();
      while (!is(CURLY_BRACKET_CLOSE)) {
        if (started) {
          assign_comments(PREFIX_AFTER_VALUE);
          expect(COMMA);
          next();
          parse_comments();
          assign_after_comments();
          if (is(CURLY_BRACKET_CLOSE)) {
            break;
          }
        }
        started = true;
        expect("String");
        name = JSON.parse(current.value);
        set_prop(name);
        assign_comments(PREFIX_BEFORE);
        next();
        parse_comments(PREFIX_AFTER_PROP);
        expect(COLON);
        next();
        parse_comments(PREFIX_AFTER_COLON);
        obj[name] = transform(name, walk());
        parse_comments();
      }
      if (started) {
        assign_comments(PREFIX_AFTER);
      }
      next();
      last_prop = void 0;
      if (!started) {
        assign_comments(PREFIX_BEFORE);
      }
      restore_comments_host();
      restore_prop();
      return obj;
    };
    var parse_array = () => {
      const array = new CommentArray();
      set_comments_host(array);
      set_prop(UNDEFINED, true);
      let started = false;
      let i = 0;
      parse_comments();
      while (!is(BRACKET_CLOSE)) {
        if (started) {
          assign_comments(PREFIX_AFTER_VALUE);
          expect(COMMA);
          next();
          parse_comments();
          assign_after_comments();
          if (is(BRACKET_CLOSE)) {
            break;
          }
        }
        started = true;
        set_prop(i);
        assign_comments(PREFIX_BEFORE);
        array[i] = transform(i, walk());
        i++;
        parse_comments();
      }
      if (started) {
        assign_comments(PREFIX_AFTER);
      }
      next();
      last_prop = void 0;
      if (!started) {
        assign_comments(PREFIX_BEFORE);
      }
      restore_comments_host();
      restore_prop();
      return array;
    };
    function walk() {
      let tt = type();
      if (tt === CURLY_BRACKET_OPEN) {
        next();
        return {
          value: parse_object()
        };
      }
      if (tt === BRACKET_OPEN) {
        next();
        return {
          value: parse_array()
        };
      }
      let negative = EMPTY;
      if (tt === MINUS) {
        next();
        tt = type();
        negative = MINUS;
      }
      let v;
      let source;
      switch (tt) {
        case "String":
          set_raw_string_literal(comments_host, last_prop, current.value);
        // falls through
        case "Boolean":
        case "Null":
        case "Numeric":
          v = current.value;
          next();
          source = negative + v;
          return {
            value: JSON.parse(source),
            context: {
              source
            }
          };
        default:
          return {};
      }
    }
    var parse3 = (code, rev, no_comments) => {
      clean();
      current_code = code;
      tokens = tokenize(code);
      reviver = rev;
      remove_comments = no_comments;
      if (!tokens.length) {
        unexpected_end();
      }
      index = -1;
      next();
      set_comments_host({});
      parse_comments(PREFIX_BEFORE_ALL);
      const final = walk();
      parse_comments(PREFIX_AFTER_ALL);
      if (current) {
        unexpected();
      }
      let result = transform("", final);
      if (!no_comments && result !== null) {
        if (!is_object(result)) {
          result = new Object(result);
        }
        assign_non_prop_comments(result, comments_host);
      }
      restore_comments_host();
      free();
      return result;
    };
    module.exports = {
      parse: parse3,
      tokenize
    };
  }
});

// node_modules/comment-json/src/stringify.js
var require_stringify = __commonJS({
  "node_modules/comment-json/src/stringify.js"(exports, module) {
    var {
      PREFIX_BEFORE_ALL,
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER,
      PREFIX_AFTER_ALL,
      BRACKET_OPEN,
      BRACKET_CLOSE,
      CURLY_BRACKET_OPEN,
      CURLY_BRACKET_CLOSE,
      COLON,
      COMMA,
      EMPTY,
      UNDEFINED,
      is_string,
      is_number,
      is_object,
      get_raw_string_literal,
      get_comment_line_breaks_before,
      get_comment_line_breaks_after,
      is_raw_json
    } = require_common();
    var SPACE = " ";
    var LF = "\n";
    var STR_NULL = "null";
    var BEFORE = (prop) => `${PREFIX_BEFORE}:${prop}`;
    var AFTER_PROP = (prop) => `${PREFIX_AFTER_PROP}:${prop}`;
    var AFTER_COLON = (prop) => `${PREFIX_AFTER_COLON}:${prop}`;
    var AFTER_VALUE = (prop) => `${PREFIX_AFTER_VALUE}:${prop}`;
    var AFTER = (prop) => `${PREFIX_AFTER}:${prop}`;
    var quote = JSON.stringify;
    var comment_stringify = (value, line) => line ? `//${value}` : `/*${value}*/`;
    var repeat_line_breaks = (line_breaks, gap) => (LF + gap).repeat(line_breaks);
    var read_line_breaks = (line_breaks) => is_number(line_breaks) && line_breaks >= 0 ? line_breaks : null;
    var read_line_breaks_from_loc = (previous_comment, comment) => {
      if (!previous_comment || !previous_comment.loc || !comment.loc) {
        return null;
      }
      const { end } = previous_comment.loc;
      const { start } = comment.loc;
      if (!end || !start || !is_number(end.line) || !is_number(start.line)) {
        return null;
      }
      const line_breaks = start.line - end.line;
      return line_breaks >= 0 ? line_breaks : null;
    };
    var count_trailing_line_breaks = (str, gap) => {
      const unit = LF + gap;
      const { length } = unit;
      let i = str.length;
      let count = 0;
      while (i >= length && str.slice(i - length, i) === unit) {
        i -= length;
        count++;
      }
      return count;
    };
    var process_comments = (host, symbol_tag, deeper_gap, display_block) => {
      const comments = host[Symbol.for(symbol_tag)];
      if (!comments || !comments.length) {
        return EMPTY;
      }
      let str = EMPTY;
      let last_comment = null;
      comments.forEach((comment, i) => {
        const {
          inline,
          type,
          value
        } = comment;
        let line_breaks_before = read_line_breaks(
          get_comment_line_breaks_before(comment)
        );
        if (line_breaks_before === null) {
          line_breaks_before = read_line_breaks_from_loc(last_comment, comment);
        }
        if (line_breaks_before === null) {
          line_breaks_before = inline ? 0 : 1;
        }
        const delimiter = line_breaks_before > 0 ? repeat_line_breaks(line_breaks_before, deeper_gap) : inline ? SPACE : i === 0 ? EMPTY : LF + deeper_gap;
        const is_line_comment = type === "LineComment";
        str += delimiter + comment_stringify(value, is_line_comment);
        last_comment = comment;
      });
      const default_line_breaks_after = display_block || last_comment.type === "LineComment" ? 1 : 0;
      const line_breaks_after = Math.max(
        default_line_breaks_after,
        read_line_breaks(get_comment_line_breaks_after(last_comment)) || 0
      );
      return str + repeat_line_breaks(line_breaks_after, deeper_gap);
    };
    var replacer = null;
    var indent = EMPTY;
    var clean = () => {
      replacer = null;
      indent = EMPTY;
    };
    var join3 = (one, two, gap) => one ? two ? one + two.trim() + LF + gap : one.trimRight() + repeat_line_breaks(
      Math.max(1, count_trailing_line_breaks(one, gap)),
      gap
    ) : two ? two.trimRight() + repeat_line_breaks(
      Math.max(1, count_trailing_line_breaks(two, gap)),
      gap
    ) : EMPTY;
    var join_content = (inside, value, gap) => {
      const comment = process_comments(value, PREFIX_BEFORE, gap + indent, true);
      return join3(comment, inside, gap);
    };
    var stringify_string = (holder, key, value) => {
      const raw = get_raw_string_literal(holder, key);
      if (is_string(raw)) {
        try {
          if (JSON.parse(raw) === value) {
            return raw;
          }
        } catch (e) {
        }
      }
      return quote(value);
    };
    var array_stringify = (value, gap) => {
      const deeper_gap = gap + indent;
      const { length } = value;
      let inside = EMPTY;
      let after_comma = EMPTY;
      for (let i = 0; i < length; i++) {
        if (i !== 0) {
          inside += COMMA;
        }
        const before = join3(
          after_comma,
          process_comments(value, BEFORE(i), deeper_gap),
          deeper_gap
        );
        inside += before || LF + deeper_gap;
        inside += stringify2(i, value, deeper_gap) || STR_NULL;
        inside += process_comments(value, AFTER_VALUE(i), deeper_gap);
        after_comma = process_comments(value, AFTER(i), deeper_gap);
      }
      inside += join3(
        after_comma,
        process_comments(value, PREFIX_AFTER, deeper_gap),
        deeper_gap
      );
      return BRACKET_OPEN + join_content(inside, value, gap) + BRACKET_CLOSE;
    };
    var object_stringify = (value, gap) => {
      if (!value) {
        return "null";
      }
      const deeper_gap = gap + indent;
      let inside = EMPTY;
      let after_comma = EMPTY;
      let first = true;
      const keys = Array.isArray(replacer) ? replacer : Object.keys(value);
      const iteratee = (key) => {
        const sv = stringify2(key, value, deeper_gap);
        if (sv === UNDEFINED) {
          return;
        }
        if (!first) {
          inside += COMMA;
        }
        first = false;
        const before = join3(
          after_comma,
          process_comments(value, BEFORE(key), deeper_gap),
          deeper_gap
        );
        inside += before || LF + deeper_gap;
        inside += quote(key) + process_comments(value, AFTER_PROP(key), deeper_gap) + COLON + process_comments(value, AFTER_COLON(key), deeper_gap) + SPACE + sv + process_comments(value, AFTER_VALUE(key), deeper_gap);
        after_comma = process_comments(value, AFTER(key), deeper_gap);
      };
      keys.forEach(iteratee);
      inside += join3(
        after_comma,
        process_comments(value, PREFIX_AFTER, deeper_gap),
        deeper_gap
      );
      return CURLY_BRACKET_OPEN + join_content(inside, value, gap) + CURLY_BRACKET_CLOSE;
    };
    function stringify2(key, holder, gap) {
      let value = holder[key];
      if (is_object(value) && typeof value.toJSON === "function") {
        value = value.toJSON(key);
      }
      if (typeof replacer === "function") {
        value = replacer.call(holder, key, value);
      }
      switch (typeof value) {
        case "string":
          return stringify_string(holder, key, value);
        case "number":
          return Number.isFinite(value) ? String(value) : STR_NULL;
        case "boolean":
        case "null":
          return String(value);
        // If the type is 'object', we might be dealing with an object or an array or
        // null.
        case "object":
          if (is_raw_json(value)) {
            return value.rawJSON;
          }
          return Array.isArray(value) ? array_stringify(value, gap) : object_stringify(value, gap);
        // undefined
        default:
      }
    }
    var get_indent = (space) => typeof space === "string" ? space : typeof space === "number" ? SPACE.repeat(space) : EMPTY;
    var { toString: toString2 } = Object.prototype;
    var PRIMITIVE_OBJECT_TYPES = [
      "[object Number]",
      "[object String]",
      "[object Boolean]"
    ];
    var is_primitive_object = (subject) => {
      if (typeof subject !== "object") {
        return false;
      }
      const str = toString2.call(subject);
      return PRIMITIVE_OBJECT_TYPES.includes(str);
    };
    module.exports = (value, replacer_, space) => {
      const indent_ = get_indent(space);
      if (!indent_) {
        return JSON.stringify(value, replacer_);
      }
      if (typeof replacer_ !== "function" && !Array.isArray(replacer_)) {
        replacer_ = null;
      }
      replacer = replacer_;
      indent = indent_;
      const str = is_primitive_object(value) ? JSON.stringify(value) : stringify2("", { "": value }, EMPTY);
      clean();
      return is_object(value) ? process_comments(value, PREFIX_BEFORE_ALL, EMPTY, true).trimLeft() + str + process_comments(value, PREFIX_AFTER_ALL, EMPTY).trimRight() : str;
    };
  }
});

// node_modules/comment-json/src/index.js
var require_src2 = __commonJS({
  "node_modules/comment-json/src/index.js"(exports, module) {
    var { parse: parse3, tokenize } = require_parse();
    var stringify2 = require_stringify();
    var { CommentArray } = require_array();
    var {
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER,
      PREFIX_BEFORE_ALL,
      PREFIX_AFTER_ALL,
      assign,
      moveComments,
      removeComments
    } = require_common();
    module.exports = {
      PREFIX_BEFORE,
      PREFIX_AFTER_PROP,
      PREFIX_AFTER_COLON,
      PREFIX_AFTER_VALUE,
      PREFIX_AFTER,
      PREFIX_BEFORE_ALL,
      PREFIX_AFTER_ALL,
      parse: parse3,
      stringify: stringify2,
      tokenize,
      CommentArray,
      assign,
      moveComments,
      removeComments
    };
  }
});

// packages/cli/src/config/trustedFolders.ts
function isFolderTrustEnabled(settings) {
  const folderTrustSetting = settings.security?.folderTrust?.enabled ?? true;
  return folderTrustSetting;
}
function loadTrustedFolders2() {
  return loadTrustedFolders();
}
function isWorkspaceTrusted(settings, workspaceDir = process.cwd(), headlessOptions) {
  return checkPathTrust({
    path: workspaceDir,
    isFolderTrustEnabled: isFolderTrustEnabled(settings),
    isHeadless: isHeadlessMode(headlessOptions)
  });
}

// packages/cli/src/utils/sessionUtils.ts
import * as fs from "node:fs/promises";
import path from "node:path";

// packages/cli/src/ui/utils/textUtils.ts
import { stripVTControlCharacters } from "node:util";

// node_modules/get-east-asian-width/lookup-data.js
var ambiguousMinimalCodePoint = 161;
var ambiguousMaximumCodePoint = 1114109;
var ambiguousRanges = [161, 161, 164, 164, 167, 168, 170, 170, 173, 174, 176, 180, 182, 186, 188, 191, 198, 198, 208, 208, 215, 216, 222, 225, 230, 230, 232, 234, 236, 237, 240, 240, 242, 243, 247, 250, 252, 252, 254, 254, 257, 257, 273, 273, 275, 275, 283, 283, 294, 295, 299, 299, 305, 307, 312, 312, 319, 322, 324, 324, 328, 331, 333, 333, 338, 339, 358, 359, 363, 363, 462, 462, 464, 464, 466, 466, 468, 468, 470, 470, 472, 472, 474, 474, 476, 476, 593, 593, 609, 609, 708, 708, 711, 711, 713, 715, 717, 717, 720, 720, 728, 731, 733, 733, 735, 735, 768, 879, 913, 929, 931, 937, 945, 961, 963, 969, 1025, 1025, 1040, 1103, 1105, 1105, 8208, 8208, 8211, 8214, 8216, 8217, 8220, 8221, 8224, 8226, 8228, 8231, 8240, 8240, 8242, 8243, 8245, 8245, 8251, 8251, 8254, 8254, 8308, 8308, 8319, 8319, 8321, 8324, 8364, 8364, 8451, 8451, 8453, 8453, 8457, 8457, 8467, 8467, 8470, 8470, 8481, 8482, 8486, 8486, 8491, 8491, 8531, 8532, 8539, 8542, 8544, 8555, 8560, 8569, 8585, 8585, 8592, 8601, 8632, 8633, 8658, 8658, 8660, 8660, 8679, 8679, 8704, 8704, 8706, 8707, 8711, 8712, 8715, 8715, 8719, 8719, 8721, 8721, 8725, 8725, 8730, 8730, 8733, 8736, 8739, 8739, 8741, 8741, 8743, 8748, 8750, 8750, 8756, 8759, 8764, 8765, 8776, 8776, 8780, 8780, 8786, 8786, 8800, 8801, 8804, 8807, 8810, 8811, 8814, 8815, 8834, 8835, 8838, 8839, 8853, 8853, 8857, 8857, 8869, 8869, 8895, 8895, 8978, 8978, 9312, 9449, 9451, 9547, 9552, 9587, 9600, 9615, 9618, 9621, 9632, 9633, 9635, 9641, 9650, 9651, 9654, 9655, 9660, 9661, 9664, 9665, 9670, 9672, 9675, 9675, 9678, 9681, 9698, 9701, 9711, 9711, 9733, 9734, 9737, 9737, 9742, 9743, 9756, 9756, 9758, 9758, 9792, 9792, 9794, 9794, 9824, 9825, 9827, 9829, 9831, 9834, 9836, 9837, 9839, 9839, 9886, 9887, 9919, 9919, 9926, 9933, 9935, 9939, 9941, 9953, 9955, 9955, 9960, 9961, 9963, 9969, 9972, 9972, 9974, 9977, 9979, 9980, 9982, 9983, 10045, 10045, 10102, 10111, 11094, 11097, 12872, 12879, 57344, 63743, 65024, 65039, 65533, 65533, 127232, 127242, 127248, 127277, 127280, 127337, 127344, 127373, 127375, 127376, 127387, 127404, 917760, 917999, 983040, 1048573, 1048576, 1114109];
var fullwidthMinimalCodePoint = 12288;
var fullwidthMaximumCodePoint = 65510;
var fullwidthRanges = [12288, 12288, 65281, 65376, 65504, 65510];
var wideMinimalCodePoint = 4352;
var wideMaximumCodePoint = 262141;
var wideRanges = [4352, 4447, 8986, 8987, 9001, 9002, 9193, 9196, 9200, 9200, 9203, 9203, 9725, 9726, 9748, 9749, 9776, 9783, 9800, 9811, 9855, 9855, 9866, 9871, 9875, 9875, 9889, 9889, 9898, 9899, 9917, 9918, 9924, 9925, 9934, 9934, 9940, 9940, 9962, 9962, 9970, 9971, 9973, 9973, 9978, 9978, 9981, 9981, 9989, 9989, 9994, 9995, 10024, 10024, 10060, 10060, 10062, 10062, 10067, 10069, 10071, 10071, 10133, 10135, 10160, 10160, 10175, 10175, 11035, 11036, 11088, 11088, 11093, 11093, 11904, 11929, 11931, 12019, 12032, 12245, 12272, 12287, 12289, 12350, 12353, 12438, 12441, 12543, 12549, 12591, 12593, 12686, 12688, 12773, 12783, 12830, 12832, 12871, 12880, 42124, 42128, 42182, 43360, 43388, 44032, 55203, 63744, 64255, 65040, 65049, 65072, 65106, 65108, 65126, 65128, 65131, 94176, 94180, 94192, 94198, 94208, 101589, 101631, 101662, 101760, 101874, 110576, 110579, 110581, 110587, 110589, 110590, 110592, 110882, 110898, 110898, 110928, 110930, 110933, 110933, 110948, 110951, 110960, 111355, 119552, 119638, 119648, 119670, 126980, 126980, 127183, 127183, 127374, 127374, 127377, 127386, 127488, 127490, 127504, 127547, 127552, 127560, 127568, 127569, 127584, 127589, 127744, 127776, 127789, 127797, 127799, 127868, 127870, 127891, 127904, 127946, 127951, 127955, 127968, 127984, 127988, 127988, 127992, 128062, 128064, 128064, 128066, 128252, 128255, 128317, 128331, 128334, 128336, 128359, 128378, 128378, 128405, 128406, 128420, 128420, 128507, 128591, 128640, 128709, 128716, 128716, 128720, 128722, 128725, 128728, 128732, 128735, 128747, 128748, 128756, 128764, 128992, 129003, 129008, 129008, 129292, 129338, 129340, 129349, 129351, 129535, 129648, 129660, 129664, 129674, 129678, 129734, 129736, 129736, 129741, 129756, 129759, 129770, 129775, 129784, 131072, 196605, 196608, 262141];

// node_modules/get-east-asian-width/utilities.js
var isInRange = (ranges, codePoint) => {
  let low = 0;
  let high = Math.floor(ranges.length / 2) - 1;
  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    const i = mid * 2;
    if (codePoint < ranges[i]) {
      high = mid - 1;
    } else if (codePoint > ranges[i + 1]) {
      low = mid + 1;
    } else {
      return true;
    }
  }
  return false;
};

// node_modules/get-east-asian-width/lookup.js
var commonCjkCodePoint = 19968;
var [wideFastPathStart, wideFastPathEnd] = /* @__PURE__ */ findWideFastPathRange(wideRanges);
function findWideFastPathRange(ranges) {
  let fastPathStart = ranges[0];
  let fastPathEnd = ranges[1];
  for (let index = 0; index < ranges.length; index += 2) {
    const start = ranges[index];
    const end = ranges[index + 1];
    if (commonCjkCodePoint >= start && commonCjkCodePoint <= end) {
      return [start, end];
    }
    if (end - start > fastPathEnd - fastPathStart) {
      fastPathStart = start;
      fastPathEnd = end;
    }
  }
  return [fastPathStart, fastPathEnd];
}
var isAmbiguous = (codePoint) => {
  if (codePoint < ambiguousMinimalCodePoint || codePoint > ambiguousMaximumCodePoint) {
    return false;
  }
  return isInRange(ambiguousRanges, codePoint);
};
var isFullWidth = (codePoint) => {
  if (codePoint < fullwidthMinimalCodePoint || codePoint > fullwidthMaximumCodePoint) {
    return false;
  }
  return isInRange(fullwidthRanges, codePoint);
};
var isWide = (codePoint) => {
  if (codePoint >= wideFastPathStart && codePoint <= wideFastPathEnd) {
    return true;
  }
  if (codePoint < wideMinimalCodePoint || codePoint > wideMaximumCodePoint) {
    return false;
  }
  return isInRange(wideRanges, codePoint);
};

// node_modules/get-east-asian-width/index.js
function validate(codePoint) {
  if (!Number.isSafeInteger(codePoint)) {
    throw new TypeError(`Expected a code point, got \`${typeof codePoint}\`.`);
  }
}
function eastAsianWidth(codePoint, { ambiguousAsWide = false } = {}) {
  validate(codePoint);
  if (isFullWidth(codePoint) || isWide(codePoint) || ambiguousAsWide && isAmbiguous(codePoint)) {
    return 2;
  }
  return 1;
}

// node_modules/string-width/index.js
var segmenter = new Intl.Segmenter();
var zeroWidthClusterRegex = /^(?:\p{Default_Ignorable_Code_Point}|\p{Control}|\p{Format}|\p{Mark}|\p{Surrogate})+$/v;
var leadingNonPrintingRegex = /^[\p{Default_Ignorable_Code_Point}\p{Control}\p{Format}\p{Mark}\p{Surrogate}]+/v;
var rgiEmojiRegex = /^\p{RGI_Emoji}$/v;
var unqualifiedKeycapRegex = /^[\d#*]\u20E3$/;
var extendedPictographicRegex = /\p{Extended_Pictographic}/gu;
function isDoubleWidthNonRgiEmojiSequence(segment) {
  if (segment.length > 50) {
    return false;
  }
  if (unqualifiedKeycapRegex.test(segment)) {
    return true;
  }
  if (segment.includes("\u200D")) {
    const pictographics = segment.match(extendedPictographicRegex);
    return pictographics !== null && pictographics.length >= 2;
  }
  return false;
}
function baseVisible(segment) {
  return segment.replace(leadingNonPrintingRegex, "");
}
function isZeroWidthCluster(segment) {
  return zeroWidthClusterRegex.test(segment);
}
function isHangulLeadingJamo(codePoint) {
  return codePoint >= 4352 && codePoint <= 4447 || codePoint >= 43360 && codePoint <= 43388;
}
function isHangulVowelJamo(codePoint) {
  return codePoint >= 4448 && codePoint <= 4519 || codePoint >= 55216 && codePoint <= 55238;
}
function isHangulTrailingJamo(codePoint) {
  return codePoint >= 4520 && codePoint <= 4607 || codePoint >= 55243 && codePoint <= 55291;
}
function isHangulJamo(codePoint) {
  return isHangulLeadingJamo(codePoint) || isHangulVowelJamo(codePoint) || isHangulTrailingJamo(codePoint);
}
function hangulClusterWidth(visibleSegment, eastAsianWidthOptions) {
  const codePoints = [];
  for (const character of visibleSegment) {
    if (zeroWidthClusterRegex.test(character)) {
      continue;
    }
    codePoints.push(character.codePointAt(0));
  }
  if (codePoints.length === 0) {
    return void 0;
  }
  let width = 0;
  for (let index = 0; index < codePoints.length; index++) {
    const codePoint = codePoints[index];
    if (!isHangulJamo(codePoint)) {
      if (width === 0) {
        return void 0;
      }
      for (let remaining = index; remaining < codePoints.length; remaining++) {
        width += eastAsianWidth(codePoints[remaining], eastAsianWidthOptions);
      }
      return width;
    }
    if (isHangulLeadingJamo(codePoint) && isHangulVowelJamo(codePoints[index + 1])) {
      width += 2;
      index += isHangulTrailingJamo(codePoints[index + 2]) ? 2 : 1;
      continue;
    }
    width += eastAsianWidth(codePoint, eastAsianWidthOptions);
  }
  return width;
}
function trailingHalfwidthWidth(visibleSegment, eastAsianWidthOptions) {
  let extra = 0;
  let first = true;
  for (const character of visibleSegment) {
    if (first) {
      first = false;
      continue;
    }
    if (character >= "\uFF00" && character <= "\uFFEF") {
      extra += eastAsianWidth(character.codePointAt(0), eastAsianWidthOptions);
    }
  }
  return extra;
}
function stringWidth(input, options = {}) {
  if (typeof input !== "string" || input.length === 0) {
    return 0;
  }
  const {
    ambiguousIsNarrow = true,
    countAnsiEscapeCodes = false
  } = options;
  let string = input;
  if (!countAnsiEscapeCodes && (string.includes("\x1B") || string.includes("\x9B"))) {
    string = stripAnsi(string);
  }
  if (string.length === 0) {
    return 0;
  }
  if (/^[\u0020-\u007E]*$/.test(string)) {
    return string.length;
  }
  let width = 0;
  const eastAsianWidthOptions = { ambiguousAsWide: !ambiguousIsNarrow };
  for (const { segment } of segmenter.segment(string)) {
    if (isZeroWidthCluster(segment)) {
      continue;
    }
    if (rgiEmojiRegex.test(segment) || isDoubleWidthNonRgiEmojiSequence(segment)) {
      width += 2;
      continue;
    }
    const visibleSegment = baseVisible(segment);
    const hangulWidth = hangulClusterWidth(visibleSegment, eastAsianWidthOptions);
    if (hangulWidth !== void 0) {
      width += hangulWidth;
      continue;
    }
    const codePoint = visibleSegment.codePointAt(0);
    width += eastAsianWidth(codePoint, eastAsianWidthOptions);
    width += trailingHalfwidthWidth(visibleSegment, eastAsianWidthOptions);
  }
  return width;
}

// packages/cli/src/ui/constants.ts
var SHELL_COMMAND_NAME = "Shell Command";
var SHELL_NAME = "Shell";
var MAX_GEMINI_MESSAGE_LINES = 65536;
var SHELL_FOCUS_HINT_DELAY_MS = 5e3;
var TOOL_STATUS = {
  SUCCESS: "\u2713",
  PENDING: "o",
  EXECUTING: "\u22B7",
  CONFIRMING: "?",
  CANCELED: "-",
  ERROR: "x"
};
var MAX_MCP_RESOURCES_TO_SHOW = 10;
var WARNING_PROMPT_DURATION_MS = 3e3;
var QUEUE_ERROR_DISPLAY_DURATION_MS = 3e3;
var SHELL_ACTION_REQUIRED_TITLE_DELAY_MS = 3e4;
var SHELL_SILENT_WORKING_TITLE_DELAY_MS = 12e4;
var EXPAND_HINT_DURATION_MS = 5e3;
var DEFAULT_BACKGROUND_OPACITY = 0.16;
var DEFAULT_INPUT_BACKGROUND_OPACITY = 0.24;
var DEFAULT_SELECTION_OPACITY = 0.2;
var DEFAULT_BORDER_OPACITY = 0.4;
var KEYBOARD_SHORTCUTS_URL = "https://geminicli.com/docs/cli/keyboard-shortcuts/";
var LRU_BUFFER_PERF_CACHE_LIMIT = 2e4;
var ACTIVE_SHELL_MAX_LINES = 15;
var COMPLETED_SHELL_MAX_LINES = 15;
var SUBAGENT_MAX_LINES = 15;
var MIN_TERMINAL_WIDTH_FOR_FULL_LABEL = 100;
var DEFAULT_COMPRESSION_THRESHOLD = 0.5;
var SKILLS_DOCS_URL = "https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/skills.md";
var COMPACT_TOOL_SUBVIEW_MAX_LINES = 15;
var MAX_SHELL_OUTPUT_SIZE = 1e7;
var SHELL_OUTPUT_TRUNCATION_BUFFER = 1e6;

// packages/cli/src/ui/utils/textUtils.ts
var getAsciiArtWidth = (asciiArt) => {
  if (!asciiArt) {
    return 0;
  }
  const lines = asciiArt.split("\n");
  return Math.max(...lines.map((line) => line.length));
};
function isAscii(str) {
  for (let i = 0; i < str.length; i++) {
    if (str.charCodeAt(i) > 127) {
      return false;
    }
  }
  return true;
}
var MAX_STRING_LENGTH_TO_CACHE = 1e3;
var codePointsCache = new import_lru_cache.default(
  LRU_BUFFER_PERF_CACHE_LIMIT
);
function toCodePoints(str) {
  if (isAscii(str)) {
    return str.split("");
  }
  if (str.length <= MAX_STRING_LENGTH_TO_CACHE) {
    const cached = codePointsCache.get(str);
    if (cached !== void 0) {
      return cached;
    }
  }
  const result = Array.from(str);
  if (str.length <= MAX_STRING_LENGTH_TO_CACHE) {
    codePointsCache.set(str, result);
  }
  return result;
}
function cpLen(str) {
  if (isAscii(str)) {
    return str.length;
  }
  return toCodePoints(str).length;
}
function cpIndexToOffset(str, cpIndex) {
  return cpSlice(str, 0, cpIndex).length;
}
function cpSlice(str, start, end) {
  if (isAscii(str)) {
    return str.slice(start, end);
  }
  const arr = toCodePoints(str).slice(start, end);
  return arr.join("");
}
function stripUnsafeCharacters(str) {
  const strippedAnsi = stripAnsi(str);
  const strippedWithRegex = strippedAnsi.replace(
    // eslint-disable-next-line no-control-regex
    /[\x00-\x08\x0B\x0C\x0E-\x1F\x80-\x9F\u200E\u200F\u202A-\u202E\u2066-\u2069\u200B\uFEFF]/g,
    ""
  );
  return stripVTControlCharacters(strippedWithRegex);
}
function sanitizeForDisplay(str, maxLength) {
  if (!str) {
    return "";
  }
  let sanitized = stripUnsafeCharacters(str).replace(/\s+/g, " ");
  if (maxLength && sanitized.length > maxLength) {
    sanitized = sanitized.substring(0, maxLength - 3) + "...";
  }
  return sanitized;
}
function normalizeEscapedNewlines(value) {
  return value.replace(/\\r\\n/g, "\n").replace(/\\n/g, "\n");
}
var stringWidthCache = new import_lru_cache.default(
  LRU_BUFFER_PERF_CACHE_LIMIT
);
var getCachedStringWidth = (str) => {
  if (str.length === 1) {
    const code = str.charCodeAt(0);
    if (code >= 32 && code <= 126) {
      return 1;
    }
  }
  const cached = stringWidthCache.get(str);
  if (cached !== void 0) {
    return cached;
  }
  let width;
  try {
    width = stringWidth(str);
  } catch {
    width = toCodePoints(stripAnsi(str)).length;
  }
  stringWidthCache.set(str, width);
  return width;
};
var regex = ansiRegex();
function escapeAnsiCtrlCodes(obj) {
  if (typeof obj === "string") {
    if (obj.search(regex) === -1) {
      return obj;
    }
    regex.lastIndex = 0;
    return obj.replace(
      regex,
      (match) => JSON.stringify(match).slice(1, -1)
    );
  }
  if (obj === null || typeof obj !== "object") {
    return obj;
  }
  if (Array.isArray(obj)) {
    let newArr = null;
    for (let i = 0; i < obj.length; i++) {
      const value = obj[i];
      const escapedValue = escapeAnsiCtrlCodes(value);
      if (escapedValue !== value) {
        if (newArr === null) {
          newArr = [...obj];
        }
        newArr[i] = escapedValue;
      }
    }
    return newArr !== null ? newArr : obj;
  }
  let newObj = null;
  const keys = Object.keys(obj);
  for (const key of keys) {
    const value = obj[key];
    const escapedValue = escapeAnsiCtrlCodes(value);
    if (escapedValue !== value) {
      if (newObj === null) {
        newObj = { ...obj };
      }
      newObj[key] = escapedValue;
    }
  }
  return newObj !== null ? newObj : obj;
}

// packages/cli/src/utils/sessionUtils.ts
var RESUME_LATEST = "latest";
var SessionError = class _SessionError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
    this.name = "SessionError";
  }
  /**
   * Creates an error for when no sessions exist for the current project.
   */
  static noSessionsFound() {
    return new _SessionError(
      "NO_SESSIONS_FOUND",
      "No previous sessions found for this project."
    );
  }
  /**
   * Creates an error for when a session identifier is invalid.
   */
  static invalidSessionIdentifier(identifier, chatsDir) {
    const dirInfo = chatsDir ? ` in ${chatsDir}` : "";
    return new _SessionError(
      "INVALID_SESSION_IDENTIFIER",
      `Invalid session identifier "${identifier}".
  Searched for sessions${dirInfo}.
  Use --list-sessions to see available sessions, then use --resume {number}, --resume {uuid}, or --resume latest.`
    );
  }
};
var cleanMessage = (message) => message.replace(/\n+/g, " ").replace(/\s+/g, " ").replace(/[^\x20-\x7E]+/g, "").trim();
var extractFirstUserMessage = (messages) => {
  const userMessage = messages.filter((msg) => {
    const content2 = partListUnionToString(msg.content);
    return !content2.startsWith("/") && !content2.startsWith("?") && content2.trim().length > 0;
  }).find((msg) => msg.type === "user");
  let content;
  if (!userMessage) {
    const firstMsg = messages.find((msg) => msg.type === "user");
    if (!firstMsg) return "Empty conversation";
    content = cleanMessage(partListUnionToString(firstMsg.content));
  } else {
    content = cleanMessage(partListUnionToString(userMessage.content));
  }
  return content;
};
var formatRelativeTime = (timestamp, style = "long") => {
  const now = /* @__PURE__ */ new Date();
  const time = new Date(timestamp);
  const diffMs = now.getTime() - time.getTime();
  const diffSeconds = Math.floor(diffMs / 1e3);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);
  if (style === "short") {
    if (diffSeconds < 1) return "now";
    if (diffSeconds < 60) return `${diffSeconds}s`;
    if (diffMinutes < 60) return `${diffMinutes}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 30) return `${diffDays}d`;
    const diffMonths = Math.floor(diffDays / 30);
    return diffMonths < 12 ? `${diffMonths}mo` : `${Math.floor(diffMonths / 12)}y`;
  } else {
    if (diffDays > 0) {
      return `${diffDays} day${diffDays === 1 ? "" : "s"} ago`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours === 1 ? "" : "s"} ago`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes} minute${diffMinutes === 1 ? "" : "s"} ago`;
    } else {
      return "Just now";
    }
  }
};
var getAllSessionFiles = async (chatsDir, currentSessionId, options = {}) => {
  try {
    const files = await fs.readdir(chatsDir);
    const sessionFiles = files.filter(
      (f) => f.startsWith(SESSION_FILE_PREFIX) && (f.endsWith(".json") || f.endsWith(".jsonl"))
    ).sort();
    const sessionPromises = sessionFiles.map(
      async (file) => {
        const filePath = path.join(chatsDir, file);
        try {
          const content = await loadConversationRecord(filePath, {
            metadataOnly: !options.includeFullContent
          });
          if (!content) {
            return { fileName: file, sessionInfo: null };
          }
          if (!content.sessionId) {
            return { fileName: file, sessionInfo: null };
          }
          const fileTimestamp = !content.startTime || !content.lastUpdated ? (await fs.stat(filePath).catch(() => void 0))?.mtime.toISOString() : void 0;
          const fallbackTimestamp = fileTimestamp ?? (/* @__PURE__ */ new Date()).toISOString();
          const startTime = content.startTime || content.lastUpdated || fallbackTimestamp;
          const lastUpdated = content.lastUpdated || content.startTime || fallbackTimestamp;
          if (!content.hasUserOrAssistantMessage) {
            return { fileName: file, sessionInfo: null };
          }
          if (content.kind === "subagent") {
            return { fileName: file, sessionInfo: null };
          }
          const firstUserMessage = content.firstUserMessage ? cleanMessage(content.firstUserMessage) : extractFirstUserMessage(content.messages);
          const isCurrentSession = currentSessionId ? file.includes(currentSessionId.slice(0, 8)) : false;
          let fullContent;
          let messages;
          if (options.includeFullContent) {
            fullContent = content.messages.map((msg) => partListUnionToString(msg.content)).join(" ");
            messages = content.messages.map((msg) => ({
              role: msg.type === "user" ? "user" : "assistant",
              content: partListUnionToString(msg.content)
            }));
          }
          const sessionInfo = {
            id: content.sessionId,
            file: file.replace(/\.jsonl?$/, ""),
            fileName: file,
            startTime,
            lastUpdated,
            messageCount: content.messageCount ?? content.messages.length,
            displayName: content.summary ? stripUnsafeCharacters(content.summary) : firstUserMessage,
            firstUserMessage,
            isCurrentSession,
            index: 0,
            // Will be set after sorting valid sessions
            summary: content.summary,
            fullContent,
            messages
          };
          return { fileName: file, sessionInfo };
        } catch {
          return { fileName: file, sessionInfo: null };
        }
      }
    );
    return await Promise.all(sessionPromises);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      return [];
    }
    throw error;
  }
};
var getSessionFiles = async (chatsDir, currentSessionId, options = {}) => {
  const allFiles = await getAllSessionFiles(
    chatsDir,
    currentSessionId,
    options
  );
  const validSessions = allFiles.filter(
    (entry) => entry.sessionInfo !== null
  ).map((entry) => entry.sessionInfo);
  const uniqueSessionsMap = /* @__PURE__ */ new Map();
  for (const session of validSessions) {
    if (!uniqueSessionsMap.has(session.id) || new Date(session.lastUpdated).getTime() > new Date(uniqueSessionsMap.get(session.id).lastUpdated).getTime()) {
      uniqueSessionsMap.set(session.id, session);
    }
  }
  const uniqueSessions = Array.from(uniqueSessionsMap.values());
  uniqueSessions.sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
  );
  uniqueSessions.forEach((session, index) => {
    session.index = index + 1;
  });
  return uniqueSessions;
};
var SessionSelector = class {
  constructor(storage) {
    this.storage = storage;
  }
  /**
   * Checks if a session with the given ID already exists on disk.
   */
  async sessionExists(id) {
    const chatsDir = path.join(this.storage.getProjectTempDir(), "chats");
    const files = await fs.readdir(chatsDir).catch(() => []);
    const shortId = id.slice(0, 8);
    const candidateFiles = files.filter(
      (f) => f.startsWith(SESSION_FILE_PREFIX) && (f.endsWith(`-${shortId}.json`) || f.endsWith(`-${shortId}.jsonl`))
    );
    for (const fileName of candidateFiles) {
      try {
        const sessionPath = path.join(chatsDir, fileName);
        const sessionData = await loadConversationRecord(sessionPath);
        if (sessionData && sessionData.sessionId === id) {
          return true;
        }
      } catch {
      }
    }
    return false;
  }
  /**
   * Lists all available sessions for the current project.
   */
  async listSessions() {
    const chatsDir = path.join(this.storage.getProjectTempDir(), "chats");
    return getSessionFiles(chatsDir);
  }
  /**
   * Finds a session by identifier (UUID or numeric index).
   *
   * @param identifier - Can be a full UUID or an index number (1-based)
   * @returns Promise resolving to the found SessionInfo
   * @throws Error if the session is not found or identifier is invalid
   */
  async findSession(identifier) {
    const trimmedIdentifier = identifier.trim();
    const sessions = await this.listSessions();
    if (sessions.length === 0) {
      throw SessionError.noSessionsFound();
    }
    const sortedSessions = sessions.sort(
      (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
    );
    const sessionByUuid = sortedSessions.find(
      (session) => session.id === trimmedIdentifier
    );
    if (sessionByUuid) {
      return sessionByUuid;
    }
    const index = parseInt(trimmedIdentifier, 10);
    if (!isNaN(index) && index.toString() === trimmedIdentifier && index > 0 && index <= sortedSessions.length) {
      return sortedSessions[index - 1];
    }
    const chatsDir = path.join(this.storage.getProjectTempDir(), "chats");
    throw SessionError.invalidSessionIdentifier(trimmedIdentifier, chatsDir);
  }
  /**
   * Resolves a resume argument to a specific session.
   *
   * @param resumeArg - Can be "latest", a full UUID, or an index number (1-based)
   * @returns Promise resolving to session selection result
   */
  async resolveSession(resumeArg) {
    let selectedSession;
    const trimmedResumeArg = resumeArg.trim();
    if (trimmedResumeArg === RESUME_LATEST) {
      const sessions = await this.listSessions();
      if (sessions.length === 0) {
        throw SessionError.noSessionsFound();
      }
      sessions.sort(
        (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
      );
      selectedSession = sessions[sessions.length - 1];
    } else {
      try {
        selectedSession = await this.findSession(trimmedResumeArg);
      } catch (error) {
        if (error instanceof SessionError) {
          throw error;
        }
        throw new Error(
          `Failed to find session "${trimmedResumeArg}": ${error instanceof Error ? error.message : String(error)}`
        );
      }
    }
    return this.selectSession(selectedSession);
  }
  /**
   * Loads session data for a selected session.
   */
  async selectSession(sessionInfo) {
    const chatsDir = path.join(this.storage.getProjectTempDir(), "chats");
    const sessionPath = path.join(chatsDir, sessionInfo.fileName);
    try {
      const sessionData = await loadConversationRecord(sessionPath);
      if (!sessionData) {
        throw new Error("Failed to load session data");
      }
      const normalizedSessionData = {
        ...sessionData,
        startTime: sessionData.startTime || sessionInfo.startTime,
        lastUpdated: sessionData.lastUpdated || sessionInfo.lastUpdated
      };
      const displayInfo = `Session ${sessionInfo.index}: ${sessionInfo.firstUserMessage} (${sessionInfo.messageCount} messages, ${formatRelativeTime(sessionInfo.lastUpdated)})`;
      return {
        sessionPath,
        sessionData: normalizedSessionData,
        displayInfo
      };
    } catch (error) {
      throw new Error(
        `Failed to load session ${sessionInfo.id}: ${error instanceof Error ? error.message : "Unknown error"}`
      );
    }
  }
};
function convertSessionToHistoryFormats(messages) {
  const uiHistory = [];
  for (const msg of messages) {
    if (msg.type === "gemini" && msg.thoughts && msg.thoughts.length > 0) {
      for (const thought of msg.thoughts) {
        uiHistory.push({
          type: "thinking",
          thought: {
            subject: thought.subject,
            description: thought.description
          }
        });
      }
    }
    const displayContentString = msg.displayContent ? partListUnionToString(msg.displayContent) : void 0;
    const contentString = partListUnionToString(msg.content);
    const uiText = displayContentString || contentString;
    if (uiText.trim()) {
      let messageType;
      switch (msg.type) {
        case "user":
          messageType = "user" /* USER */;
          break;
        case "info":
          messageType = "info" /* INFO */;
          break;
        case "error":
          messageType = "error" /* ERROR */;
          break;
        case "warning":
          messageType = "warning" /* WARNING */;
          break;
        case "gemini":
          messageType = "gemini" /* GEMINI */;
          break;
        default:
          checkExhaustive(msg);
          messageType = "gemini" /* GEMINI */;
          break;
      }
      uiHistory.push({
        type: messageType,
        text: uiText
      });
    }
    if (msg.type !== "user" && "toolCalls" in msg && msg.toolCalls && msg.toolCalls.length > 0) {
      uiHistory.push({
        type: "tool_group",
        tools: msg.toolCalls.map((tool) => ({
          callId: tool.id,
          name: tool.displayName || tool.name,
          args: tool.args,
          description: tool.description || "",
          renderOutputAsMarkdown: tool.renderOutputAsMarkdown ?? true,
          status: tool.status === "success" ? "success" /* Success */ : "error" /* Error */,
          resultDisplay: tool.resultDisplay,
          confirmationDetails: void 0
        }))
      });
    }
  }
  return {
    uiHistory
  };
}

// packages/cli/src/utils/sessionCleanup.ts
import * as fs2 from "node:fs/promises";
import * as path2 from "node:path";
var DEFAULT_MIN_RETENTION = "1d";
var MIN_MAX_COUNT = 1;
var MULTIPLIERS = {
  h: 60 * 60 * 1e3,
  // hours to ms
  d: 24 * 60 * 60 * 1e3,
  // days to ms
  w: 7 * 24 * 60 * 60 * 1e3,
  // weeks to ms
  m: 30 * 24 * 60 * 60 * 1e3
  // months (30 days) to ms
};
var SHORT_ID_REGEX = /-([a-zA-Z0-9]{8})\.jsonl?$/;
function hasProperty(obj, prop) {
  return obj !== null && typeof obj === "object" && prop in obj;
}
function isStringProperty(obj, prop) {
  return hasProperty(obj, prop) && typeof obj[prop] === "string";
}
function isSessionIdRecord(record) {
  return isStringProperty(record, "sessionId");
}
function deriveShortIdFromFileName(fileName) {
  if (fileName.startsWith(SESSION_FILE_PREFIX) && (fileName.endsWith(".json") || fileName.endsWith(".jsonl"))) {
    const match = fileName.match(SHORT_ID_REGEX);
    return match ? match[1] : null;
  }
  return null;
}
async function cleanupSessionAndSubagentsAsync(sessionId, config) {
  const tempDir = config.storage.getProjectTempDir();
  const chatsDir = path2.join(tempDir, "chats");
  await deleteSessionArtifactsAsync(sessionId, tempDir);
  await deleteSubagentSessionDirAndArtifactsAsync(sessionId, chatsDir, tempDir);
}
async function cleanupExpiredSessions(config, settings) {
  const result = {
    disabled: false,
    scanned: 0,
    deleted: 0,
    skipped: 0,
    failed: 0
  };
  try {
    if (!settings.general?.sessionRetention?.enabled) {
      return { ...result, disabled: true };
    }
    const retentionConfig = settings.general.sessionRetention;
    const chatsDir = path2.join(config.storage.getProjectTempDir(), "chats");
    const validationErrorMessage = validateRetentionConfig(
      config,
      retentionConfig
    );
    if (validationErrorMessage) {
      debugLogger.warn(`Session cleanup disabled: ${validationErrorMessage}`);
      return { ...result, disabled: true };
    }
    const allFiles = await getAllSessionFiles(chatsDir, config.getSessionId());
    result.scanned = allFiles.length;
    if (allFiles.length === 0) {
      return result;
    }
    const sessionsToDelete = await identifySessionsToDelete(
      allFiles,
      retentionConfig
    );
    const processedShortIds = /* @__PURE__ */ new Set();
    for (const sessionToDelete of sessionsToDelete) {
      try {
        const shortId = deriveShortIdFromFileName(sessionToDelete.fileName);
        if (shortId) {
          if (processedShortIds.has(shortId)) {
            continue;
          }
          processedShortIds.add(shortId);
          const matchingFiles = allFiles.map((f) => f.fileName).filter(
            (f) => f.startsWith(SESSION_FILE_PREFIX) && (f.endsWith(`-${shortId}.json`) || f.endsWith(`-${shortId}.jsonl`))
          );
          for (const file of matchingFiles) {
            const filePath = path2.join(chatsDir, file);
            let fullSessionId;
            try {
              try {
                const CHUNK_SIZE = 4096;
                const buffer = Buffer.alloc(CHUNK_SIZE);
                let fd;
                try {
                  fd = await fs2.open(filePath, "r");
                  const { bytesRead } = await fd.read(buffer, 0, CHUNK_SIZE, 0);
                  if (bytesRead > 0) {
                    const contentChunk = buffer.toString("utf8", 0, bytesRead);
                    const newlineIndex = contentChunk.indexOf("\n");
                    const firstLine = newlineIndex !== -1 ? contentChunk.substring(0, newlineIndex) : contentChunk;
                    try {
                      const record = JSON.parse(firstLine);
                      if (isSessionIdRecord(record)) {
                        fullSessionId = record.sessionId;
                      }
                    } catch {
                    }
                  }
                } finally {
                  if (fd !== void 0) {
                    await fd.close();
                  }
                }
                if (!fullSessionId) {
                  const fileContent = await fs2.readFile(filePath, "utf8");
                  const content = JSON.parse(fileContent);
                  if (isSessionIdRecord(content)) {
                    fullSessionId = content.sessionId;
                  }
                }
              } catch {
              }
              if (!fullSessionId || fullSessionId !== config.getSessionId()) {
                await fs2.unlink(filePath);
                if (fullSessionId) {
                  await cleanupSessionAndSubagentsAsync(fullSessionId, config);
                }
                result.deleted++;
              } else {
                result.skipped++;
              }
            } catch (error) {
              if (error instanceof Error && "code" in error && error.code === "ENOENT") {
              } else {
                debugLogger.warn(
                  `Failed to delete matching file ${file}: ${error instanceof Error ? error.message : "Unknown error"}`
                );
                result.failed++;
              }
            }
          }
        } else {
          const sessionPath = path2.join(chatsDir, sessionToDelete.fileName);
          await fs2.unlink(sessionPath);
          const sessionId = sessionToDelete.sessionInfo?.id;
          if (sessionId) {
            await cleanupSessionAndSubagentsAsync(sessionId, config);
          }
          if (config.getDebugMode()) {
            debugLogger.debug(
              `Deleted fallback session: ${sessionToDelete.fileName}`
            );
          }
          result.deleted++;
        }
      } catch (error) {
        if (error instanceof Error && "code" in error && error.code === "ENOENT") {
        } else {
          const sessionId = sessionToDelete.sessionInfo === null ? sessionToDelete.fileName : sessionToDelete.sessionInfo.id;
          debugLogger.warn(
            `Failed to delete session ${sessionId}: ${error instanceof Error ? error.message : "Unknown error"}`
          );
          result.failed++;
        }
      }
    }
    result.skipped = result.scanned - result.deleted - result.failed;
    if (config.getDebugMode() && result.deleted > 0) {
      debugLogger.debug(
        `Session cleanup: deleted ${result.deleted}, skipped ${result.skipped}, failed ${result.failed}`
      );
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    debugLogger.warn(`Session cleanup failed: ${errorMessage}`);
    result.failed++;
  }
  return result;
}
async function identifySessionsToDelete(allFiles, retentionConfig) {
  const sessionsToDelete = [];
  sessionsToDelete.push(
    ...allFiles.filter((entry) => entry.sessionInfo === null)
  );
  const validSessions = allFiles.filter((entry) => entry.sessionInfo !== null);
  if (validSessions.length === 0) {
    return sessionsToDelete;
  }
  const now = /* @__PURE__ */ new Date();
  let cutoffDate = null;
  if (retentionConfig.maxAge) {
    try {
      const maxAgeMs = parseRetentionPeriod(retentionConfig.maxAge);
      cutoffDate = new Date(now.getTime() - maxAgeMs);
    } catch {
      cutoffDate = null;
    }
  }
  const sortedValidSessions = [...validSessions].sort(
    (a, b) => new Date(b.sessionInfo.lastUpdated).getTime() - new Date(a.sessionInfo.lastUpdated).getTime()
  );
  const deletableSessions = sortedValidSessions.filter(
    (entry) => !entry.sessionInfo.isCurrentSession
  );
  const hasActiveSession = sortedValidSessions.some(
    (e) => e.sessionInfo.isCurrentSession
  );
  const maxDeletableSessions = retentionConfig.maxCount && hasActiveSession ? Math.max(0, retentionConfig.maxCount - 1) : retentionConfig.maxCount;
  for (let i = 0; i < deletableSessions.length; i++) {
    const entry = deletableSessions[i];
    const session = entry.sessionInfo;
    let shouldDelete = false;
    if (cutoffDate) {
      const lastUpdatedDate = new Date(session.lastUpdated);
      const isExpired = lastUpdatedDate < cutoffDate;
      if (isExpired) {
        shouldDelete = true;
      }
    }
    if (maxDeletableSessions !== void 0) {
      if (i >= maxDeletableSessions) {
        shouldDelete = true;
      }
    }
    if (shouldDelete) {
      sessionsToDelete.push(entry);
    }
  }
  return sessionsToDelete;
}
function parseRetentionPeriod(period) {
  const match = period.match(/^(\d+)([dhwm])$/);
  if (!match) {
    throw new Error(
      `Invalid retention period format: ${period}. Expected format: <number><unit> where unit is h, d, w, or m`
    );
  }
  const value = parseInt(match[1], 10);
  const unit = match[2];
  if (value === 0) {
    throw new Error(
      `Invalid retention period: ${period}. Value must be greater than 0`
    );
  }
  return value * MULTIPLIERS[unit];
}
function validateRetentionConfig(config, retentionConfig) {
  if (!retentionConfig.enabled) {
    return "Retention not enabled";
  }
  if (retentionConfig.maxAge) {
    let maxAgeMs;
    try {
      maxAgeMs = parseRetentionPeriod(retentionConfig.maxAge);
    } catch (error) {
      return error.toString();
    }
    const minRetention = retentionConfig.minRetention || DEFAULT_MIN_RETENTION;
    let minRetentionMs;
    try {
      minRetentionMs = parseRetentionPeriod(minRetention);
    } catch (error) {
      if (config.getDebugMode()) {
        debugLogger.warn(`Failed to parse minRetention: ${error}`);
      }
      minRetentionMs = parseRetentionPeriod(DEFAULT_MIN_RETENTION);
    }
    if (maxAgeMs < minRetentionMs) {
      return `maxAge cannot be less than minRetention (${minRetention})`;
    }
  }
  if (retentionConfig.maxCount !== void 0) {
    if (retentionConfig.maxCount < MIN_MAX_COUNT) {
      return `maxCount must be at least ${MIN_MAX_COUNT}`;
    }
  }
  if (!retentionConfig.maxAge && retentionConfig.maxCount === void 0) {
    return "Either maxAge or maxCount must be specified";
  }
  return null;
}
async function cleanupToolOutputFiles(settings, debugMode = false, projectTempDir) {
  const result = {
    disabled: false,
    scanned: 0,
    deleted: 0,
    failed: 0
  };
  try {
    if (!settings.general?.sessionRetention?.enabled) {
      return { ...result, disabled: true };
    }
    const retentionConfig = settings.general.sessionRetention;
    let tempDir = projectTempDir;
    if (!tempDir) {
      const storage = new Storage(process.cwd());
      await storage.initialize();
      tempDir = storage.getProjectTempDir();
    }
    const toolOutputDir = path2.join(tempDir, TOOL_OUTPUTS_DIR);
    try {
      await fs2.access(toolOutputDir);
    } catch {
      return result;
    }
    const entries = await fs2.readdir(toolOutputDir, { withFileTypes: true });
    result.scanned = entries.length;
    if (entries.length === 0) {
      return result;
    }
    const files = entries.filter((e) => e.isFile());
    const fileStatsResults = await Promise.all(
      files.map(async (file) => {
        try {
          const filePath = path2.join(toolOutputDir, file.name);
          const stat3 = await fs2.stat(filePath);
          return { name: file.name, mtime: stat3.mtime };
        } catch (error) {
          debugLogger.debug(
            `Failed to stat file ${file.name}: ${error instanceof Error ? error.message : "Unknown error"}`
          );
          return null;
        }
      })
    );
    const fileStats = fileStatsResults.filter(
      (f) => f !== null
    );
    fileStats.sort((a, b) => a.mtime.getTime() - b.mtime.getTime());
    const now = /* @__PURE__ */ new Date();
    const filesToDelete = [];
    if (retentionConfig.maxAge) {
      try {
        const maxAgeMs = parseRetentionPeriod(retentionConfig.maxAge);
        const cutoffDate = new Date(now.getTime() - maxAgeMs);
        for (const file of fileStats) {
          if (file.mtime < cutoffDate) {
            filesToDelete.push(file.name);
          }
        }
      } catch (error) {
        debugLogger.debug(
          `Invalid maxAge format, skipping age-based cleanup: ${error instanceof Error ? error.message : "Unknown error"}`
        );
      }
    }
    if (retentionConfig.maxCount !== void 0) {
      const remainingFiles = fileStats.filter(
        (f) => !filesToDelete.includes(f.name)
      );
      if (remainingFiles.length > retentionConfig.maxCount) {
        const excessCount = remainingFiles.length - retentionConfig.maxCount;
        for (let i = 0; i < excessCount; i++) {
          filesToDelete.push(remainingFiles[i].name);
        }
      }
    }
    const subdirs = entries.filter(
      (e) => e.isDirectory() && e.name.startsWith("session-")
    );
    for (const subdir of subdirs) {
      try {
        if (subdir.name !== sanitizeFilenamePart(subdir.name)) {
          debugLogger.debug(
            `Skipping unsafe tool-output subdirectory: ${subdir.name}`
          );
          continue;
        }
        const subdirPath = path2.join(toolOutputDir, subdir.name);
        const stat3 = await fs2.stat(subdirPath);
        let shouldDelete = false;
        if (retentionConfig.maxAge) {
          const maxAgeMs = parseRetentionPeriod(retentionConfig.maxAge);
          const cutoffDate = new Date(now.getTime() - maxAgeMs);
          if (stat3.mtime < cutoffDate) {
            shouldDelete = true;
          }
        }
        if (shouldDelete) {
          await fs2.rm(subdirPath, { recursive: true, force: true });
          result.deleted++;
        }
      } catch (error) {
        debugLogger.debug(`Failed to cleanup subdir ${subdir.name}: ${error}`);
      }
    }
    for (const fileName of filesToDelete) {
      try {
        const filePath = path2.join(toolOutputDir, fileName);
        await fs2.unlink(filePath);
        result.deleted++;
      } catch (error) {
        debugLogger.debug(
          `Failed to delete file ${fileName}: ${error instanceof Error ? error.message : "Unknown error"}`
        );
        result.failed++;
      }
    }
    if (debugMode && result.deleted > 0) {
      debugLogger.debug(
        `Tool output cleanup: deleted ${result.deleted}, failed ${result.failed}`
      );
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    debugLogger.warn(`Tool output cleanup failed: ${errorMessage}`);
    result.failed++;
  }
  return result;
}

// packages/cli/src/config/settings.ts
var dotenv = __toESM(require_main(), 1);
import * as fs4 from "node:fs";
import * as path3 from "node:path";
import { platform } from "node:os";
import process2 from "node:process";
var import_strip_json_comments = __toESM(require_strip_json_comments(), 1);

// packages/cli/src/ui/themes/theme.ts
var import_tinygradient = __toESM(require_tinygradient(), 1);

// node_modules/tinycolor2/esm/tinycolor.js
function _typeof(obj) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
}
var trimLeft = /^\s+/;
var trimRight = /\s+$/;
function tinycolor(color, opts) {
  color = color ? color : "";
  opts = opts || {};
  if (color instanceof tinycolor) {
    return color;
  }
  if (!(this instanceof tinycolor)) {
    return new tinycolor(color, opts);
  }
  var rgb = inputToRGB(color);
  this._originalInput = color, this._r = rgb.r, this._g = rgb.g, this._b = rgb.b, this._a = rgb.a, this._roundA = Math.round(100 * this._a) / 100, this._format = opts.format || rgb.format;
  this._gradientType = opts.gradientType;
  if (this._r < 1) this._r = Math.round(this._r);
  if (this._g < 1) this._g = Math.round(this._g);
  if (this._b < 1) this._b = Math.round(this._b);
  this._ok = rgb.ok;
}
tinycolor.prototype = {
  isDark: function isDark() {
    return this.getBrightness() < 128;
  },
  isLight: function isLight() {
    return !this.isDark();
  },
  isValid: function isValid() {
    return this._ok;
  },
  getOriginalInput: function getOriginalInput() {
    return this._originalInput;
  },
  getFormat: function getFormat() {
    return this._format;
  },
  getAlpha: function getAlpha() {
    return this._a;
  },
  getBrightness: function getBrightness() {
    var rgb = this.toRgb();
    return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1e3;
  },
  getLuminance: function getLuminance() {
    var rgb = this.toRgb();
    var RsRGB, GsRGB, BsRGB, R, G, B;
    RsRGB = rgb.r / 255;
    GsRGB = rgb.g / 255;
    BsRGB = rgb.b / 255;
    if (RsRGB <= 0.03928) R = RsRGB / 12.92;
    else R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
    if (GsRGB <= 0.03928) G = GsRGB / 12.92;
    else G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
    if (BsRGB <= 0.03928) B = BsRGB / 12.92;
    else B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
    return 0.2126 * R + 0.7152 * G + 0.0722 * B;
  },
  setAlpha: function setAlpha(value) {
    this._a = boundAlpha(value);
    this._roundA = Math.round(100 * this._a) / 100;
    return this;
  },
  toHsv: function toHsv() {
    var hsv = rgbToHsv(this._r, this._g, this._b);
    return {
      h: hsv.h * 360,
      s: hsv.s,
      v: hsv.v,
      a: this._a
    };
  },
  toHsvString: function toHsvString() {
    var hsv = rgbToHsv(this._r, this._g, this._b);
    var h = Math.round(hsv.h * 360), s = Math.round(hsv.s * 100), v = Math.round(hsv.v * 100);
    return this._a == 1 ? "hsv(" + h + ", " + s + "%, " + v + "%)" : "hsva(" + h + ", " + s + "%, " + v + "%, " + this._roundA + ")";
  },
  toHsl: function toHsl() {
    var hsl = rgbToHsl(this._r, this._g, this._b);
    return {
      h: hsl.h * 360,
      s: hsl.s,
      l: hsl.l,
      a: this._a
    };
  },
  toHslString: function toHslString() {
    var hsl = rgbToHsl(this._r, this._g, this._b);
    var h = Math.round(hsl.h * 360), s = Math.round(hsl.s * 100), l = Math.round(hsl.l * 100);
    return this._a == 1 ? "hsl(" + h + ", " + s + "%, " + l + "%)" : "hsla(" + h + ", " + s + "%, " + l + "%, " + this._roundA + ")";
  },
  toHex: function toHex(allow3Char) {
    return rgbToHex(this._r, this._g, this._b, allow3Char);
  },
  toHexString: function toHexString(allow3Char) {
    return "#" + this.toHex(allow3Char);
  },
  toHex8: function toHex8(allow4Char) {
    return rgbaToHex(this._r, this._g, this._b, this._a, allow4Char);
  },
  toHex8String: function toHex8String(allow4Char) {
    return "#" + this.toHex8(allow4Char);
  },
  toRgb: function toRgb() {
    return {
      r: Math.round(this._r),
      g: Math.round(this._g),
      b: Math.round(this._b),
      a: this._a
    };
  },
  toRgbString: function toRgbString() {
    return this._a == 1 ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")";
  },
  toPercentageRgb: function toPercentageRgb() {
    return {
      r: Math.round(bound01(this._r, 255) * 100) + "%",
      g: Math.round(bound01(this._g, 255) * 100) + "%",
      b: Math.round(bound01(this._b, 255) * 100) + "%",
      a: this._a
    };
  },
  toPercentageRgbString: function toPercentageRgbString() {
    return this._a == 1 ? "rgb(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%)" : "rgba(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%, " + this._roundA + ")";
  },
  toName: function toName() {
    if (this._a === 0) {
      return "transparent";
    }
    if (this._a < 1) {
      return false;
    }
    return hexNames[rgbToHex(this._r, this._g, this._b, true)] || false;
  },
  toFilter: function toFilter(secondColor) {
    var hex8String = "#" + rgbaToArgbHex(this._r, this._g, this._b, this._a);
    var secondHex8String = hex8String;
    var gradientType = this._gradientType ? "GradientType = 1, " : "";
    if (secondColor) {
      var s = tinycolor(secondColor);
      secondHex8String = "#" + rgbaToArgbHex(s._r, s._g, s._b, s._a);
    }
    return "progid:DXImageTransform.Microsoft.gradient(" + gradientType + "startColorstr=" + hex8String + ",endColorstr=" + secondHex8String + ")";
  },
  toString: function toString(format) {
    var formatSet = !!format;
    format = format || this._format;
    var formattedString = false;
    var hasAlpha = this._a < 1 && this._a >= 0;
    var needsAlphaFormat = !formatSet && hasAlpha && (format === "hex" || format === "hex6" || format === "hex3" || format === "hex4" || format === "hex8" || format === "name");
    if (needsAlphaFormat) {
      if (format === "name" && this._a === 0) {
        return this.toName();
      }
      return this.toRgbString();
    }
    if (format === "rgb") {
      formattedString = this.toRgbString();
    }
    if (format === "prgb") {
      formattedString = this.toPercentageRgbString();
    }
    if (format === "hex" || format === "hex6") {
      formattedString = this.toHexString();
    }
    if (format === "hex3") {
      formattedString = this.toHexString(true);
    }
    if (format === "hex4") {
      formattedString = this.toHex8String(true);
    }
    if (format === "hex8") {
      formattedString = this.toHex8String();
    }
    if (format === "name") {
      formattedString = this.toName();
    }
    if (format === "hsl") {
      formattedString = this.toHslString();
    }
    if (format === "hsv") {
      formattedString = this.toHsvString();
    }
    return formattedString || this.toHexString();
  },
  clone: function clone() {
    return tinycolor(this.toString());
  },
  _applyModification: function _applyModification(fn, args) {
    var color = fn.apply(null, [this].concat([].slice.call(args)));
    this._r = color._r;
    this._g = color._g;
    this._b = color._b;
    this.setAlpha(color._a);
    return this;
  },
  lighten: function lighten() {
    return this._applyModification(_lighten, arguments);
  },
  brighten: function brighten() {
    return this._applyModification(_brighten, arguments);
  },
  darken: function darken() {
    return this._applyModification(_darken, arguments);
  },
  desaturate: function desaturate() {
    return this._applyModification(_desaturate, arguments);
  },
  saturate: function saturate() {
    return this._applyModification(_saturate, arguments);
  },
  greyscale: function greyscale() {
    return this._applyModification(_greyscale, arguments);
  },
  spin: function spin() {
    return this._applyModification(_spin, arguments);
  },
  _applyCombination: function _applyCombination(fn, args) {
    return fn.apply(null, [this].concat([].slice.call(args)));
  },
  analogous: function analogous() {
    return this._applyCombination(_analogous, arguments);
  },
  complement: function complement() {
    return this._applyCombination(_complement, arguments);
  },
  monochromatic: function monochromatic() {
    return this._applyCombination(_monochromatic, arguments);
  },
  splitcomplement: function splitcomplement() {
    return this._applyCombination(_splitcomplement, arguments);
  },
  // Disabled until https://github.com/bgrins/TinyColor/issues/254
  // polyad: function (number) {
  //   return this._applyCombination(polyad, [number]);
  // },
  triad: function triad() {
    return this._applyCombination(polyad, [3]);
  },
  tetrad: function tetrad() {
    return this._applyCombination(polyad, [4]);
  }
};
tinycolor.fromRatio = function(color, opts) {
  if (_typeof(color) == "object") {
    var newColor = {};
    for (var i in color) {
      if (color.hasOwnProperty(i)) {
        if (i === "a") {
          newColor[i] = color[i];
        } else {
          newColor[i] = convertToPercentage(color[i]);
        }
      }
    }
    color = newColor;
  }
  return tinycolor(color, opts);
};
function inputToRGB(color) {
  var rgb = {
    r: 0,
    g: 0,
    b: 0
  };
  var a = 1;
  var s = null;
  var v = null;
  var l = null;
  var ok = false;
  var format = false;
  if (typeof color == "string") {
    color = stringInputToObject(color);
  }
  if (_typeof(color) == "object") {
    if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
      rgb = rgbToRgb(color.r, color.g, color.b);
      ok = true;
      format = String(color.r).substr(-1) === "%" ? "prgb" : "rgb";
    } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
      s = convertToPercentage(color.s);
      v = convertToPercentage(color.v);
      rgb = hsvToRgb(color.h, s, v);
      ok = true;
      format = "hsv";
    } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
      s = convertToPercentage(color.s);
      l = convertToPercentage(color.l);
      rgb = hslToRgb(color.h, s, l);
      ok = true;
      format = "hsl";
    }
    if (color.hasOwnProperty("a")) {
      a = color.a;
    }
  }
  a = boundAlpha(a);
  return {
    ok,
    format: color.format || format,
    r: Math.min(255, Math.max(rgb.r, 0)),
    g: Math.min(255, Math.max(rgb.g, 0)),
    b: Math.min(255, Math.max(rgb.b, 0)),
    a
  };
}
function rgbToRgb(r, g, b) {
  return {
    r: bound01(r, 255) * 255,
    g: bound01(g, 255) * 255,
    b: bound01(b, 255) * 255
  };
}
function rgbToHsl(r, g, b) {
  r = bound01(r, 255);
  g = bound01(g, 255);
  b = bound01(b, 255);
  var max = Math.max(r, g, b), min = Math.min(r, g, b);
  var h, s, l = (max + min) / 2;
  if (max == min) {
    h = s = 0;
  } else {
    var d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return {
    h,
    s,
    l
  };
}
function hslToRgb(h, s, l) {
  var r, g, b;
  h = bound01(h, 360);
  s = bound01(s, 100);
  l = bound01(l, 100);
  function hue2rgb(p2, q2, t) {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p2 + (q2 - p2) * 6 * t;
    if (t < 1 / 2) return q2;
    if (t < 2 / 3) return p2 + (q2 - p2) * (2 / 3 - t) * 6;
    return p2;
  }
  if (s === 0) {
    r = g = b = l;
  } else {
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return {
    r: r * 255,
    g: g * 255,
    b: b * 255
  };
}
function rgbToHsv(r, g, b) {
  r = bound01(r, 255);
  g = bound01(g, 255);
  b = bound01(b, 255);
  var max = Math.max(r, g, b), min = Math.min(r, g, b);
  var h, s, v = max;
  var d = max - min;
  s = max === 0 ? 0 : d / max;
  if (max == min) {
    h = 0;
  } else {
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return {
    h,
    s,
    v
  };
}
function hsvToRgb(h, s, v) {
  h = bound01(h, 360) * 6;
  s = bound01(s, 100);
  v = bound01(v, 100);
  var i = Math.floor(h), f = h - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s), mod = i % 6, r = [v, q, p, p, t, v][mod], g = [t, v, v, q, p, p][mod], b = [p, p, t, v, v, q][mod];
  return {
    r: r * 255,
    g: g * 255,
    b: b * 255
  };
}
function rgbToHex(r, g, b, allow3Char) {
  var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];
  if (allow3Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1)) {
    return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
  }
  return hex.join("");
}
function rgbaToHex(r, g, b, a, allow4Char) {
  var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16)), pad2(convertDecimalToHex(a))];
  if (allow4Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1) && hex[3].charAt(0) == hex[3].charAt(1)) {
    return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
  }
  return hex.join("");
}
function rgbaToArgbHex(r, g, b, a) {
  var hex = [pad2(convertDecimalToHex(a)), pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];
  return hex.join("");
}
tinycolor.equals = function(color1, color2) {
  if (!color1 || !color2) return false;
  return tinycolor(color1).toRgbString() == tinycolor(color2).toRgbString();
};
tinycolor.random = function() {
  return tinycolor.fromRatio({
    r: Math.random(),
    g: Math.random(),
    b: Math.random()
  });
};
function _desaturate(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.s -= amount / 100;
  hsl.s = clamp01(hsl.s);
  return tinycolor(hsl);
}
function _saturate(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.s += amount / 100;
  hsl.s = clamp01(hsl.s);
  return tinycolor(hsl);
}
function _greyscale(color) {
  return tinycolor(color).desaturate(100);
}
function _lighten(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.l += amount / 100;
  hsl.l = clamp01(hsl.l);
  return tinycolor(hsl);
}
function _brighten(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var rgb = tinycolor(color).toRgb();
  rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
  rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
  rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
  return tinycolor(rgb);
}
function _darken(color, amount) {
  amount = amount === 0 ? 0 : amount || 10;
  var hsl = tinycolor(color).toHsl();
  hsl.l -= amount / 100;
  hsl.l = clamp01(hsl.l);
  return tinycolor(hsl);
}
function _spin(color, amount) {
  var hsl = tinycolor(color).toHsl();
  var hue = (hsl.h + amount) % 360;
  hsl.h = hue < 0 ? 360 + hue : hue;
  return tinycolor(hsl);
}
function _complement(color) {
  var hsl = tinycolor(color).toHsl();
  hsl.h = (hsl.h + 180) % 360;
  return tinycolor(hsl);
}
function polyad(color, number) {
  if (isNaN(number) || number <= 0) {
    throw new Error("Argument to polyad must be a positive number");
  }
  var hsl = tinycolor(color).toHsl();
  var result = [tinycolor(color)];
  var step = 360 / number;
  for (var i = 1; i < number; i++) {
    result.push(tinycolor({
      h: (hsl.h + i * step) % 360,
      s: hsl.s,
      l: hsl.l
    }));
  }
  return result;
}
function _splitcomplement(color) {
  var hsl = tinycolor(color).toHsl();
  var h = hsl.h;
  return [tinycolor(color), tinycolor({
    h: (h + 72) % 360,
    s: hsl.s,
    l: hsl.l
  }), tinycolor({
    h: (h + 216) % 360,
    s: hsl.s,
    l: hsl.l
  })];
}
function _analogous(color, results, slices) {
  results = results || 6;
  slices = slices || 30;
  var hsl = tinycolor(color).toHsl();
  var part = 360 / slices;
  var ret = [tinycolor(color)];
  for (hsl.h = (hsl.h - (part * results >> 1) + 720) % 360; --results; ) {
    hsl.h = (hsl.h + part) % 360;
    ret.push(tinycolor(hsl));
  }
  return ret;
}
function _monochromatic(color, results) {
  results = results || 6;
  var hsv = tinycolor(color).toHsv();
  var h = hsv.h, s = hsv.s, v = hsv.v;
  var ret = [];
  var modification = 1 / results;
  while (results--) {
    ret.push(tinycolor({
      h,
      s,
      v
    }));
    v = (v + modification) % 1;
  }
  return ret;
}
tinycolor.mix = function(color1, color2, amount) {
  amount = amount === 0 ? 0 : amount || 50;
  var rgb1 = tinycolor(color1).toRgb();
  var rgb2 = tinycolor(color2).toRgb();
  var p = amount / 100;
  var rgba = {
    r: (rgb2.r - rgb1.r) * p + rgb1.r,
    g: (rgb2.g - rgb1.g) * p + rgb1.g,
    b: (rgb2.b - rgb1.b) * p + rgb1.b,
    a: (rgb2.a - rgb1.a) * p + rgb1.a
  };
  return tinycolor(rgba);
};
tinycolor.readability = function(color1, color2) {
  var c1 = tinycolor(color1);
  var c2 = tinycolor(color2);
  return (Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) / (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05);
};
tinycolor.isReadable = function(color1, color2, wcag2) {
  var readability = tinycolor.readability(color1, color2);
  var wcag2Parms, out;
  out = false;
  wcag2Parms = validateWCAG2Parms(wcag2);
  switch (wcag2Parms.level + wcag2Parms.size) {
    case "AAsmall":
    case "AAAlarge":
      out = readability >= 4.5;
      break;
    case "AAlarge":
      out = readability >= 3;
      break;
    case "AAAsmall":
      out = readability >= 7;
      break;
  }
  return out;
};
tinycolor.mostReadable = function(baseColor, colorList, args) {
  var bestColor = null;
  var bestScore = 0;
  var readability;
  var includeFallbackColors, level, size;
  args = args || {};
  includeFallbackColors = args.includeFallbackColors;
  level = args.level;
  size = args.size;
  for (var i = 0; i < colorList.length; i++) {
    readability = tinycolor.readability(baseColor, colorList[i]);
    if (readability > bestScore) {
      bestScore = readability;
      bestColor = tinycolor(colorList[i]);
    }
  }
  if (tinycolor.isReadable(baseColor, bestColor, {
    level,
    size
  }) || !includeFallbackColors) {
    return bestColor;
  } else {
    args.includeFallbackColors = false;
    return tinycolor.mostReadable(baseColor, ["#fff", "#000"], args);
  }
};
var names = tinycolor.names = {
  aliceblue: "f0f8ff",
  antiquewhite: "faebd7",
  aqua: "0ff",
  aquamarine: "7fffd4",
  azure: "f0ffff",
  beige: "f5f5dc",
  bisque: "ffe4c4",
  black: "000",
  blanchedalmond: "ffebcd",
  blue: "00f",
  blueviolet: "8a2be2",
  brown: "a52a2a",
  burlywood: "deb887",
  burntsienna: "ea7e5d",
  cadetblue: "5f9ea0",
  chartreuse: "7fff00",
  chocolate: "d2691e",
  coral: "ff7f50",
  cornflowerblue: "6495ed",
  cornsilk: "fff8dc",
  crimson: "dc143c",
  cyan: "0ff",
  darkblue: "00008b",
  darkcyan: "008b8b",
  darkgoldenrod: "b8860b",
  darkgray: "a9a9a9",
  darkgreen: "006400",
  darkgrey: "a9a9a9",
  darkkhaki: "bdb76b",
  darkmagenta: "8b008b",
  darkolivegreen: "556b2f",
  darkorange: "ff8c00",
  darkorchid: "9932cc",
  darkred: "8b0000",
  darksalmon: "e9967a",
  darkseagreen: "8fbc8f",
  darkslateblue: "483d8b",
  darkslategray: "2f4f4f",
  darkslategrey: "2f4f4f",
  darkturquoise: "00ced1",
  darkviolet: "9400d3",
  deeppink: "ff1493",
  deepskyblue: "00bfff",
  dimgray: "696969",
  dimgrey: "696969",
  dodgerblue: "1e90ff",
  firebrick: "b22222",
  floralwhite: "fffaf0",
  forestgreen: "228b22",
  fuchsia: "f0f",
  gainsboro: "dcdcdc",
  ghostwhite: "f8f8ff",
  gold: "ffd700",
  goldenrod: "daa520",
  gray: "808080",
  green: "008000",
  greenyellow: "adff2f",
  grey: "808080",
  honeydew: "f0fff0",
  hotpink: "ff69b4",
  indianred: "cd5c5c",
  indigo: "4b0082",
  ivory: "fffff0",
  khaki: "f0e68c",
  lavender: "e6e6fa",
  lavenderblush: "fff0f5",
  lawngreen: "7cfc00",
  lemonchiffon: "fffacd",
  lightblue: "add8e6",
  lightcoral: "f08080",
  lightcyan: "e0ffff",
  lightgoldenrodyellow: "fafad2",
  lightgray: "d3d3d3",
  lightgreen: "90ee90",
  lightgrey: "d3d3d3",
  lightpink: "ffb6c1",
  lightsalmon: "ffa07a",
  lightseagreen: "20b2aa",
  lightskyblue: "87cefa",
  lightslategray: "789",
  lightslategrey: "789",
  lightsteelblue: "b0c4de",
  lightyellow: "ffffe0",
  lime: "0f0",
  limegreen: "32cd32",
  linen: "faf0e6",
  magenta: "f0f",
  maroon: "800000",
  mediumaquamarine: "66cdaa",
  mediumblue: "0000cd",
  mediumorchid: "ba55d3",
  mediumpurple: "9370db",
  mediumseagreen: "3cb371",
  mediumslateblue: "7b68ee",
  mediumspringgreen: "00fa9a",
  mediumturquoise: "48d1cc",
  mediumvioletred: "c71585",
  midnightblue: "191970",
  mintcream: "f5fffa",
  mistyrose: "ffe4e1",
  moccasin: "ffe4b5",
  navajowhite: "ffdead",
  navy: "000080",
  oldlace: "fdf5e6",
  olive: "808000",
  olivedrab: "6b8e23",
  orange: "ffa500",
  orangered: "ff4500",
  orchid: "da70d6",
  palegoldenrod: "eee8aa",
  palegreen: "98fb98",
  paleturquoise: "afeeee",
  palevioletred: "db7093",
  papayawhip: "ffefd5",
  peachpuff: "ffdab9",
  peru: "cd853f",
  pink: "ffc0cb",
  plum: "dda0dd",
  powderblue: "b0e0e6",
  purple: "800080",
  rebeccapurple: "663399",
  red: "f00",
  rosybrown: "bc8f8f",
  royalblue: "4169e1",
  saddlebrown: "8b4513",
  salmon: "fa8072",
  sandybrown: "f4a460",
  seagreen: "2e8b57",
  seashell: "fff5ee",
  sienna: "a0522d",
  silver: "c0c0c0",
  skyblue: "87ceeb",
  slateblue: "6a5acd",
  slategray: "708090",
  slategrey: "708090",
  snow: "fffafa",
  springgreen: "00ff7f",
  steelblue: "4682b4",
  tan: "d2b48c",
  teal: "008080",
  thistle: "d8bfd8",
  tomato: "ff6347",
  turquoise: "40e0d0",
  violet: "ee82ee",
  wheat: "f5deb3",
  white: "fff",
  whitesmoke: "f5f5f5",
  yellow: "ff0",
  yellowgreen: "9acd32"
};
var hexNames = tinycolor.hexNames = flip(names);
function flip(o) {
  var flipped = {};
  for (var i in o) {
    if (o.hasOwnProperty(i)) {
      flipped[o[i]] = i;
    }
  }
  return flipped;
}
function boundAlpha(a) {
  a = parseFloat(a);
  if (isNaN(a) || a < 0 || a > 1) {
    a = 1;
  }
  return a;
}
function bound01(n, max) {
  if (isOnePointZero(n)) n = "100%";
  var processPercent = isPercentage(n);
  n = Math.min(max, Math.max(0, parseFloat(n)));
  if (processPercent) {
    n = parseInt(n * max, 10) / 100;
  }
  if (Math.abs(n - max) < 1e-6) {
    return 1;
  }
  return n % max / parseFloat(max);
}
function clamp01(val) {
  return Math.min(1, Math.max(0, val));
}
function parseIntFromHex(val) {
  return parseInt(val, 16);
}
function isOnePointZero(n) {
  return typeof n == "string" && n.indexOf(".") != -1 && parseFloat(n) === 1;
}
function isPercentage(n) {
  return typeof n === "string" && n.indexOf("%") != -1;
}
function pad2(c) {
  return c.length == 1 ? "0" + c : "" + c;
}
function convertToPercentage(n) {
  if (n <= 1) {
    n = n * 100 + "%";
  }
  return n;
}
function convertDecimalToHex(d) {
  return Math.round(parseFloat(d) * 255).toString(16);
}
function convertHexToDecimal(h) {
  return parseIntFromHex(h) / 255;
}
var matchers = (function() {
  var CSS_INTEGER = "[-\\+]?\\d+%?";
  var CSS_NUMBER = "[-\\+]?\\d*\\.\\d+%?";
  var CSS_UNIT = "(?:" + CSS_NUMBER + ")|(?:" + CSS_INTEGER + ")";
  var PERMISSIVE_MATCH3 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
  var PERMISSIVE_MATCH4 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
  return {
    CSS_UNIT: new RegExp(CSS_UNIT),
    rgb: new RegExp("rgb" + PERMISSIVE_MATCH3),
    rgba: new RegExp("rgba" + PERMISSIVE_MATCH4),
    hsl: new RegExp("hsl" + PERMISSIVE_MATCH3),
    hsla: new RegExp("hsla" + PERMISSIVE_MATCH4),
    hsv: new RegExp("hsv" + PERMISSIVE_MATCH3),
    hsva: new RegExp("hsva" + PERMISSIVE_MATCH4),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
  };
})();
function isValidCSSUnit(color) {
  return !!matchers.CSS_UNIT.exec(color);
}
function stringInputToObject(color) {
  color = color.replace(trimLeft, "").replace(trimRight, "").toLowerCase();
  var named = false;
  if (names[color]) {
    color = names[color];
    named = true;
  } else if (color == "transparent") {
    return {
      r: 0,
      g: 0,
      b: 0,
      a: 0,
      format: "name"
    };
  }
  var match;
  if (match = matchers.rgb.exec(color)) {
    return {
      r: match[1],
      g: match[2],
      b: match[3]
    };
  }
  if (match = matchers.rgba.exec(color)) {
    return {
      r: match[1],
      g: match[2],
      b: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hsl.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      l: match[3]
    };
  }
  if (match = matchers.hsla.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      l: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hsv.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      v: match[3]
    };
  }
  if (match = matchers.hsva.exec(color)) {
    return {
      h: match[1],
      s: match[2],
      v: match[3],
      a: match[4]
    };
  }
  if (match = matchers.hex8.exec(color)) {
    return {
      r: parseIntFromHex(match[1]),
      g: parseIntFromHex(match[2]),
      b: parseIntFromHex(match[3]),
      a: convertHexToDecimal(match[4]),
      format: named ? "name" : "hex8"
    };
  }
  if (match = matchers.hex6.exec(color)) {
    return {
      r: parseIntFromHex(match[1]),
      g: parseIntFromHex(match[2]),
      b: parseIntFromHex(match[3]),
      format: named ? "name" : "hex"
    };
  }
  if (match = matchers.hex4.exec(color)) {
    return {
      r: parseIntFromHex(match[1] + "" + match[1]),
      g: parseIntFromHex(match[2] + "" + match[2]),
      b: parseIntFromHex(match[3] + "" + match[3]),
      a: convertHexToDecimal(match[4] + "" + match[4]),
      format: named ? "name" : "hex8"
    };
  }
  if (match = matchers.hex3.exec(color)) {
    return {
      r: parseIntFromHex(match[1] + "" + match[1]),
      g: parseIntFromHex(match[2] + "" + match[2]),
      b: parseIntFromHex(match[3] + "" + match[3]),
      format: named ? "name" : "hex"
    };
  }
  return false;
}
function validateWCAG2Parms(parms) {
  var level, size;
  parms = parms || {
    level: "AA",
    size: "small"
  };
  level = (parms.level || "AA").toUpperCase();
  size = (parms.size || "small").toLowerCase();
  if (level !== "AA" && level !== "AAA") {
    level = "AA";
  }
  if (size !== "small" && size !== "large") {
    size = "small";
  }
  return {
    level,
    size
  };
}

// packages/cli/src/ui/themes/theme.ts
var INK_SUPPORTED_NAMES = /* @__PURE__ */ new Set([
  "black",
  "red",
  "green",
  "yellow",
  "blue",
  "cyan",
  "magenta",
  "white",
  "gray",
  "grey",
  "blackbright",
  "redbright",
  "greenbright",
  "yellowbright",
  "bluebright",
  "cyanbright",
  "magentabright",
  "whitebright"
]);
var CSS_NAME_TO_HEX_MAP = Object.fromEntries(
  Object.entries(tinycolor.names).filter(([name]) => !INK_SUPPORTED_NAMES.has(name)).map(([name, hex]) => [name, `#${hex}`])
);
var INK_NAME_TO_HEX_MAP = {
  blackbright: "#555555",
  redbright: "#ff5555",
  greenbright: "#55ff55",
  yellowbright: "#ffff55",
  bluebright: "#5555ff",
  magentabright: "#ff55ff",
  cyanbright: "#55ffff",
  whitebright: "#ffffff"
};
function getLuminance2(color) {
  const resolved = color.toLowerCase();
  const hex = INK_NAME_TO_HEX_MAP[resolved] || resolved;
  const colorObj = tinycolor(hex);
  if (!colorObj.isValid()) {
    return 0;
  }
  return colorObj.getLuminance() * 255;
}
function resolveColor(colorValue) {
  const lowerColor = colorValue.toLowerCase();
  if (lowerColor.startsWith("#")) {
    if (/^#[0-9A-Fa-f]{3}([0-9A-Fa-f]{3})?$/.test(colorValue)) {
      return lowerColor;
    } else {
      return void 0;
    }
  }
  if (/^[0-9A-Fa-f]{3}([0-9A-Fa-f]{3})?$/.test(colorValue)) {
    return `#${lowerColor}`;
  }
  if (INK_SUPPORTED_NAMES.has(lowerColor)) {
    return lowerColor;
  }
  const colorObj = tinycolor(lowerColor);
  if (colorObj.isValid()) {
    return colorObj.toHexString();
  }
  return void 0;
}
function interpolateColor(color1, color2, factor) {
  if (factor <= 0 && color1) {
    return color1;
  }
  if (factor >= 1 && color2) {
    return color2;
  }
  if (!color1 || !color2) {
    return "";
  }
  try {
    const gradient = (0, import_tinygradient.default)(color1, color2);
    const color = gradient.rgbAt(factor);
    return color.toHexString();
  } catch {
    return color1;
  }
}
function getThemeTypeFromBackgroundColor(backgroundColor) {
  if (!backgroundColor) {
    return void 0;
  }
  const resolvedColor = resolveColor(backgroundColor);
  if (!resolvedColor) {
    return void 0;
  }
  const luminance = getLuminance2(resolvedColor);
  return luminance > 128 ? "light" : "dark";
}
var lightTheme = {
  type: "light",
  Background: "#FFFFFF",
  Foreground: "#000000",
  LightBlue: "#005FAF",
  AccentBlue: "#005FAF",
  AccentPurple: "#5F00FF",
  AccentCyan: "#005F87",
  AccentGreen: "#005F00",
  AccentYellow: "#875F00",
  AccentRed: "#AF0000",
  DiffAdded: "#D7FFD7",
  DiffRemoved: "#FFD7D7",
  Comment: "#008700",
  Gray: "#5F5F5F",
  DarkGray: "#5F5F5F",
  InputBackground: "#E4E4E4",
  MessageBackground: "#FAFAFA",
  FocusBackground: "#D7FFD7",
  GradientColors: ["#4796E4", "#847ACE", "#C3677F"]
};
var darkTheme = {
  type: "dark",
  Background: "#000000",
  Foreground: "#FFFFFF",
  LightBlue: "#AFD7D7",
  AccentBlue: "#87AFFF",
  AccentPurple: "#D7AFFF",
  AccentCyan: "#87D7D7",
  AccentGreen: "#D7FFD7",
  AccentYellow: "#FFFFAF",
  AccentRed: "#FF87AF",
  DiffAdded: "#005F00",
  DiffRemoved: "#5F0000",
  Comment: "#AFAFAF",
  Gray: "#AFAFAF",
  DarkGray: "#878787",
  InputBackground: "#5F5F5F",
  MessageBackground: "#5F5F5F",
  FocusBackground: "#005F00",
  GradientColors: ["#4796E4", "#847ACE", "#C3677F"]
};
var Theme = class _Theme {
  /**
   * Creates a new Theme instance.
   * @param name The name of the theme.
   * @param rawMappings The raw CSSProperties mappings from a react-syntax-highlighter theme object.
   */
  constructor(name, type, rawMappings, colors, semanticColors) {
    this.name = name;
    this.type = type;
    this.colors = colors;
    this.semanticColors = semanticColors ?? {
      text: {
        primary: this.colors.Foreground,
        secondary: this.colors.Gray,
        link: this.colors.AccentBlue,
        accent: this.colors.AccentPurple,
        response: this.colors.Foreground
      },
      background: {
        primary: this.colors.Background,
        message: this.colors.MessageBackground ?? interpolateColor(
          this.colors.Background,
          this.colors.Gray,
          DEFAULT_INPUT_BACKGROUND_OPACITY
        ),
        input: this.colors.InputBackground ?? interpolateColor(
          this.colors.Background,
          this.colors.Gray,
          DEFAULT_INPUT_BACKGROUND_OPACITY
        ),
        focus: this.colors.FocusBackground ?? interpolateColor(
          this.colors.Background,
          this.colors.FocusColor ?? this.colors.AccentGreen,
          DEFAULT_SELECTION_OPACITY
        ),
        diff: {
          added: this.colors.DiffAdded,
          removed: this.colors.DiffRemoved
        }
      },
      border: {
        default: this.colors.DarkGray
      },
      ui: {
        comment: this.colors.Gray,
        symbol: this.colors.AccentCyan,
        active: this.colors.AccentBlue,
        dark: this.colors.DarkGray,
        focus: this.colors.FocusColor ?? this.colors.AccentGreen,
        gradient: this.colors.GradientColors
      },
      status: {
        error: this.colors.AccentRed,
        success: this.colors.AccentGreen,
        warning: this.colors.AccentYellow
      }
    };
    this._colorMap = Object.freeze(this._buildColorMap(rawMappings));
    const rawDefaultColor = rawMappings["hljs"]?.color;
    this.defaultColor = (rawDefaultColor ? _Theme._resolveColor(rawDefaultColor) : void 0) ?? "";
  }
  /**
   * The default foreground color for text when no specific highlight rule applies.
   * This is an Ink-compatible color string (hex or name).
   */
  defaultColor;
  /**
   * Stores the mapping from highlight.js class names (e.g., 'hljs-keyword')
   * to Ink-compatible color strings (hex or name).
   */
  _colorMap;
  semanticColors;
  /**
   * Gets the Ink-compatible color string for a given highlight.js class name.
   * @param hljsClass The highlight.js class name (e.g., 'hljs-keyword', 'hljs-string').
   * @returns The corresponding Ink color string (hex or name) if it exists.
   */
  getInkColor(hljsClass) {
    return this._colorMap[hljsClass];
  }
  /**
   * Resolves a CSS color value (name or hex) into an Ink-compatible color string.
   * @param colorValue The raw color string (e.g., 'blue', '#ff0000', 'darkkhaki').
   * @returns An Ink-compatible color string (hex or name), or undefined if not resolvable.
   */
  static _resolveColor(colorValue) {
    return resolveColor(colorValue);
  }
  /**
   * Builds the internal map from highlight.js class names to Ink-compatible color strings.
   * This method is protected and primarily intended for use by the constructor.
   * @param hljsTheme The raw CSSProperties mappings from a react-syntax-highlighter theme object.
   * @returns An Ink-compatible theme map (Record<string, string>).
   */
  _buildColorMap(hljsTheme) {
    const inkTheme = {};
    for (const key in hljsTheme) {
      if (!key.startsWith("hljs-") && key !== "hljs") {
        continue;
      }
      const style = hljsTheme[key];
      if (style?.color) {
        const resolvedColor = _Theme._resolveColor(style.color);
        if (resolvedColor !== void 0) {
          inkTheme[key] = resolvedColor;
        }
      }
    }
    return inkTheme;
  }
};
function createCustomTheme(customTheme) {
  const colors = {
    type: "custom",
    Background: customTheme.background?.primary ?? customTheme.Background ?? "",
    Foreground: customTheme.text?.primary ?? customTheme.Foreground ?? "",
    LightBlue: customTheme.text?.link ?? customTheme.LightBlue ?? "",
    AccentBlue: customTheme.text?.link ?? customTheme.AccentBlue ?? "",
    AccentPurple: customTheme.text?.accent ?? customTheme.AccentPurple ?? "",
    AccentCyan: customTheme.text?.link ?? customTheme.AccentCyan ?? "",
    AccentGreen: customTheme.status?.success ?? customTheme.AccentGreen ?? "",
    AccentYellow: customTheme.status?.warning ?? customTheme.AccentYellow ?? "",
    AccentRed: customTheme.status?.error ?? customTheme.AccentRed ?? "",
    DiffAdded: customTheme.background?.diff?.added ?? customTheme.DiffAdded ?? "",
    DiffRemoved: customTheme.background?.diff?.removed ?? customTheme.DiffRemoved ?? "",
    Comment: customTheme.ui?.comment ?? customTheme.Comment ?? "",
    Gray: customTheme.text?.secondary ?? customTheme.Gray ?? "",
    DarkGray: customTheme.DarkGray ?? interpolateColor(
      customTheme.background?.primary ?? customTheme.Background ?? "",
      customTheme.text?.secondary ?? customTheme.Gray ?? "",
      DEFAULT_BORDER_OPACITY
    ),
    InputBackground: interpolateColor(
      customTheme.background?.primary ?? customTheme.Background ?? "",
      customTheme.text?.secondary ?? customTheme.Gray ?? "",
      DEFAULT_INPUT_BACKGROUND_OPACITY
    ),
    MessageBackground: interpolateColor(
      customTheme.background?.primary ?? customTheme.Background ?? "",
      customTheme.text?.secondary ?? customTheme.Gray ?? "",
      DEFAULT_INPUT_BACKGROUND_OPACITY
    ),
    FocusBackground: interpolateColor(
      customTheme.background?.primary ?? customTheme.Background ?? "",
      customTheme.status?.success ?? customTheme.AccentGreen ?? "#3CA84B",
      // Fallback to a default green if not found
      DEFAULT_SELECTION_OPACITY
    ),
    FocusColor: customTheme.ui?.focus ?? customTheme.AccentGreen,
    GradientColors: customTheme.ui?.gradient ?? customTheme.GradientColors
  };
  const rawMappings = {
    hljs: {
      display: "block",
      overflowX: "auto",
      padding: "0.5em",
      background: colors.Background,
      color: colors.Foreground
    },
    "hljs-keyword": {
      color: colors.AccentBlue
    },
    "hljs-literal": {
      color: colors.AccentBlue
    },
    "hljs-symbol": {
      color: colors.AccentBlue
    },
    "hljs-name": {
      color: colors.AccentBlue
    },
    "hljs-link": {
      color: colors.AccentBlue,
      textDecoration: "underline"
    },
    "hljs-built_in": {
      color: colors.AccentCyan
    },
    "hljs-type": {
      color: colors.AccentCyan
    },
    "hljs-number": {
      color: colors.AccentGreen
    },
    "hljs-class": {
      color: colors.AccentGreen
    },
    "hljs-string": {
      color: colors.AccentYellow
    },
    "hljs-meta-string": {
      color: colors.AccentYellow
    },
    "hljs-regexp": {
      color: colors.AccentRed
    },
    "hljs-template-tag": {
      color: colors.AccentRed
    },
    "hljs-subst": {
      color: colors.Foreground
    },
    "hljs-function": {
      color: colors.Foreground
    },
    "hljs-title": {
      color: colors.Foreground
    },
    "hljs-params": {
      color: colors.Foreground
    },
    "hljs-formula": {
      color: colors.Foreground
    },
    "hljs-comment": {
      color: colors.Comment,
      fontStyle: "italic"
    },
    "hljs-quote": {
      color: colors.Comment,
      fontStyle: "italic"
    },
    "hljs-doctag": {
      color: colors.Comment
    },
    "hljs-meta": {
      color: colors.Gray
    },
    "hljs-meta-keyword": {
      color: colors.Gray
    },
    "hljs-tag": {
      color: colors.Gray
    },
    "hljs-variable": {
      color: colors.AccentPurple
    },
    "hljs-template-variable": {
      color: colors.AccentPurple
    },
    "hljs-attr": {
      color: colors.LightBlue
    },
    "hljs-attribute": {
      color: colors.LightBlue
    },
    "hljs-builtin-name": {
      color: colors.LightBlue
    },
    "hljs-section": {
      color: colors.AccentYellow
    },
    "hljs-emphasis": {
      fontStyle: "italic"
    },
    "hljs-strong": {
      fontWeight: "bold"
    },
    "hljs-bullet": {
      color: colors.AccentYellow
    },
    "hljs-selector-tag": {
      color: colors.AccentYellow
    },
    "hljs-selector-id": {
      color: colors.AccentYellow
    },
    "hljs-selector-class": {
      color: colors.AccentYellow
    },
    "hljs-selector-attr": {
      color: colors.AccentYellow
    },
    "hljs-selector-pseudo": {
      color: colors.AccentYellow
    },
    "hljs-addition": {
      backgroundColor: colors.AccentGreen,
      display: "inline-block",
      width: "100%"
    },
    "hljs-deletion": {
      backgroundColor: colors.AccentRed,
      display: "inline-block",
      width: "100%"
    }
  };
  const semanticColors = {
    text: {
      primary: customTheme.text?.primary ?? colors.Foreground,
      secondary: customTheme.text?.secondary ?? colors.Gray,
      link: customTheme.text?.link ?? colors.AccentBlue,
      accent: customTheme.text?.accent ?? colors.AccentPurple,
      response: customTheme.text?.response ?? customTheme.text?.primary ?? colors.Foreground
    },
    background: {
      primary: customTheme.background?.primary ?? colors.Background,
      message: colors.MessageBackground,
      input: colors.InputBackground,
      focus: colors.FocusBackground,
      diff: {
        added: customTheme.background?.diff?.added ?? colors.DiffAdded,
        removed: customTheme.background?.diff?.removed ?? colors.DiffRemoved
      }
    },
    border: {
      default: colors.DarkGray
    },
    ui: {
      comment: customTheme.ui?.comment ?? colors.Comment,
      symbol: customTheme.ui?.symbol ?? colors.Gray,
      active: customTheme.ui?.active ?? colors.AccentBlue,
      dark: colors.DarkGray,
      focus: colors.FocusColor ?? colors.AccentGreen,
      gradient: customTheme.ui?.gradient ?? colors.GradientColors
    },
    status: {
      error: customTheme.status?.error ?? colors.AccentRed,
      success: customTheme.status?.success ?? colors.AccentGreen,
      warning: customTheme.status?.warning ?? colors.AccentYellow
    }
  };
  return new Theme(
    customTheme.name,
    "custom",
    rawMappings,
    colors,
    semanticColors
  );
}
function validateCustomTheme(customTheme) {
  if (customTheme.name && !isValidThemeName(customTheme.name)) {
    return {
      isValid: false,
      error: `Invalid theme name: ${customTheme.name}`
    };
  }
  return {
    isValid: true
  };
}
function isValidThemeName(name) {
  return name.trim().length > 0 && name.trim().length <= 50;
}
function pickDefaultThemeName(terminalBackground, availableThemes, defaultDarkThemeName, defaultLightThemeName) {
  if (terminalBackground) {
    const lowerTerminalBackground = terminalBackground.toLowerCase();
    for (const theme of availableThemes) {
      if (!theme.colors.Background) continue;
      const themeBg = resolveColor(theme.colors.Background)?.toLowerCase();
      if (themeBg === lowerTerminalBackground) {
        return theme.name;
      }
    }
  }
  const themeType = getThemeTypeFromBackgroundColor(terminalBackground);
  if (themeType === "light") {
    return defaultLightThemeName;
  }
  return defaultDarkThemeName;
}

// packages/cli/src/ui/themes/builtin/light/default-light.ts
var DefaultLight = new Theme(
  "Default Light",
  "light",
  {
    hljs: {
      display: "block",
      overflowX: "auto",
      padding: "0.5em",
      background: lightTheme.Background,
      color: lightTheme.Foreground
    },
    "hljs-comment": {
      color: lightTheme.Comment
    },
    "hljs-quote": {
      color: lightTheme.Comment
    },
    "hljs-variable": {
      color: lightTheme.Foreground
    },
    "hljs-keyword": {
      color: lightTheme.AccentBlue
    },
    "hljs-selector-tag": {
      color: lightTheme.AccentBlue
    },
    "hljs-built_in": {
      color: lightTheme.AccentBlue
    },
    "hljs-name": {
      color: lightTheme.AccentBlue
    },
    "hljs-tag": {
      color: lightTheme.AccentBlue
    },
    "hljs-string": {
      color: lightTheme.AccentRed
    },
    "hljs-title": {
      color: lightTheme.AccentRed
    },
    "hljs-section": {
      color: lightTheme.AccentRed
    },
    "hljs-attribute": {
      color: lightTheme.AccentRed
    },
    "hljs-literal": {
      color: lightTheme.AccentRed
    },
    "hljs-template-tag": {
      color: lightTheme.AccentRed
    },
    "hljs-template-variable": {
      color: lightTheme.AccentRed
    },
    "hljs-type": {
      color: lightTheme.AccentRed
    },
    "hljs-addition": {
      color: lightTheme.AccentGreen
    },
    "hljs-deletion": {
      color: lightTheme.AccentRed
    },
    "hljs-selector-attr": {
      color: lightTheme.AccentCyan
    },
    "hljs-selector-pseudo": {
      color: lightTheme.AccentCyan
    },
    "hljs-meta": {
      color: lightTheme.AccentCyan
    },
    "hljs-doctag": {
      color: lightTheme.Gray
    },
    "hljs-attr": {
      color: lightTheme.AccentRed
    },
    "hljs-symbol": {
      color: lightTheme.AccentCyan
    },
    "hljs-bullet": {
      color: lightTheme.AccentCyan
    },
    "hljs-link": {
      color: lightTheme.AccentCyan
    },
    "hljs-emphasis": {
      fontStyle: "italic"
    },
    "hljs-strong": {
      fontWeight: "bold"
    }
  },
  lightTheme
);

// packages/cli/src/ui/themes/builtin/dark/default-dark.ts
var DefaultDark = new Theme(
  "Default",
  "dark",
  {
    hljs: {
      display: "block",
      overflowX: "auto",
      padding: "0.5em",
      background: darkTheme.Background,
      color: darkTheme.Foreground
    },
    "hljs-keyword": {
      color: darkTheme.AccentBlue
    },
    "hljs-literal": {
      color: darkTheme.AccentBlue
    },
    "hljs-symbol": {
      color: darkTheme.AccentBlue
    },
    "hljs-name": {
      color: darkTheme.AccentBlue
    },
    "hljs-link": {
      color: darkTheme.AccentBlue,
      textDecoration: "underline"
    },
    "hljs-built_in": {
      color: darkTheme.AccentCyan
    },
    "hljs-type": {
      color: darkTheme.AccentCyan
    },
    "hljs-number": {
      color: darkTheme.AccentGreen
    },
    "hljs-class": {
      color: darkTheme.AccentGreen
    },
    "hljs-string": {
      color: darkTheme.AccentYellow
    },
    "hljs-meta-string": {
      color: darkTheme.AccentYellow
    },
    "hljs-regexp": {
      color: darkTheme.AccentRed
    },
    "hljs-template-tag": {
      color: darkTheme.AccentRed
    },
    "hljs-subst": {
      color: darkTheme.Foreground
    },
    "hljs-function": {
      color: darkTheme.Foreground
    },
    "hljs-title": {
      color: darkTheme.Foreground
    },
    "hljs-params": {
      color: darkTheme.Foreground
    },
    "hljs-formula": {
      color: darkTheme.Foreground
    },
    "hljs-comment": {
      color: darkTheme.Comment,
      fontStyle: "italic"
    },
    "hljs-quote": {
      color: darkTheme.Comment,
      fontStyle: "italic"
    },
    "hljs-doctag": {
      color: darkTheme.Comment
    },
    "hljs-meta": {
      color: darkTheme.Gray
    },
    "hljs-meta-keyword": {
      color: darkTheme.Gray
    },
    "hljs-tag": {
      color: darkTheme.Gray
    },
    "hljs-variable": {
      color: darkTheme.AccentPurple
    },
    "hljs-template-variable": {
      color: darkTheme.AccentPurple
    },
    "hljs-attr": {
      color: darkTheme.LightBlue
    },
    "hljs-attribute": {
      color: darkTheme.LightBlue
    },
    "hljs-builtin-name": {
      color: darkTheme.LightBlue
    },
    "hljs-section": {
      color: darkTheme.AccentYellow
    },
    "hljs-emphasis": {
      fontStyle: "italic"
    },
    "hljs-strong": {
      fontWeight: "bold"
    },
    "hljs-bullet": {
      color: darkTheme.AccentYellow
    },
    "hljs-selector-tag": {
      color: darkTheme.AccentYellow
    },
    "hljs-selector-id": {
      color: darkTheme.AccentYellow
    },
    "hljs-selector-class": {
      color: darkTheme.AccentYellow
    },
    "hljs-selector-attr": {
      color: darkTheme.AccentYellow
    },
    "hljs-selector-pseudo": {
      color: darkTheme.AccentYellow
    },
    "hljs-addition": {
      backgroundColor: "#144212",
      display: "inline-block",
      width: "100%"
    },
    "hljs-deletion": {
      backgroundColor: "#600",
      display: "inline-block",
      width: "100%"
    }
  },
  darkTheme
);

// packages/cli/src/config/settingsSchema.ts
var TOGGLE_TYPES = /* @__PURE__ */ new Set([
  "boolean",
  "enum"
]);
function oneLine(strings, ...values) {
  let result = "";
  for (let i = 0; i < strings.length; i++) {
    result += strings[i];
    if (i < values.length) {
      result += String(values[i]);
    }
  }
  return result.replace(/\s+/g, " ").trim();
}
var pathArraySetting = (label, description) => ({
  type: "array",
  label,
  category: "Advanced",
  requiresRestart: true,
  default: [],
  description,
  showInDialog: false,
  items: { type: "string" },
  mergeStrategy: "union" /* UNION */
});
var SETTINGS_SCHEMA = {
  // Maintained for compatibility/criticality
  mcpServers: {
    type: "object",
    label: "MCP Servers",
    category: "Advanced",
    requiresRestart: true,
    default: {},
    description: "Configuration for MCP servers.",
    showInDialog: false,
    mergeStrategy: "shallow_merge" /* SHALLOW_MERGE */,
    additionalProperties: {
      type: "object",
      ref: "MCPServerConfig"
    }
  },
  policyPaths: pathArraySetting(
    "Policy Paths",
    "Additional policy files or directories to load."
  ),
  adminPolicyPaths: pathArraySetting(
    "Admin Policy Paths",
    "Additional admin policy files or directories to load."
  ),
  general: {
    type: "object",
    label: "General",
    category: "General",
    requiresRestart: false,
    default: {},
    description: "General application settings.",
    showInDialog: false,
    properties: {
      preferredEditor: {
        type: "string",
        label: "Preferred Editor",
        category: "General",
        requiresRestart: false,
        default: void 0,
        description: "The preferred editor to open files in.",
        showInDialog: false
      },
      vimMode: {
        type: "boolean",
        label: "Vim Mode",
        category: "General",
        requiresRestart: false,
        default: false,
        description: "Enable Vim keybindings",
        showInDialog: true
      },
      defaultApprovalMode: {
        type: "enum",
        label: "Default Approval Mode",
        category: "General",
        requiresRestart: false,
        default: "default",
        description: oneLine`
          The default approval mode for tool execution.
          'default' prompts for approval, 'auto_edit' auto-approves edit tools,
          and 'plan' is read-only mode. YOLO mode (auto-approve all actions) can
          only be enabled via command line (--yolo or --approval-mode=yolo).
        `,
        showInDialog: true,
        options: [
          { value: "default", label: "Default" },
          { value: "auto_edit", label: "Auto Edit" },
          { value: "plan", label: "Plan" }
        ]
      },
      devtools: {
        type: "boolean",
        label: "DevTools",
        category: "General",
        requiresRestart: false,
        default: false,
        description: "Enable DevTools inspector on launch.",
        showInDialog: false
      },
      enableAutoUpdate: {
        type: "boolean",
        label: "Enable Auto Update",
        category: "General",
        requiresRestart: false,
        default: true,
        description: "Enable automatic updates.",
        showInDialog: true
      },
      enableAutoUpdateNotification: {
        type: "boolean",
        label: "Enable Auto Update Notification",
        category: "General",
        requiresRestart: false,
        default: true,
        description: "Enable update notification prompts.",
        showInDialog: false
      },
      enableNotifications: {
        type: "boolean",
        label: "Enable Terminal Notifications",
        category: "General",
        requiresRestart: false,
        default: false,
        description: "Enable terminal run-event notifications for action-required prompts and session completion.",
        showInDialog: true
      },
      notificationMethod: {
        type: "enum",
        label: "Terminal Notification Method",
        category: "General",
        requiresRestart: false,
        default: "auto",
        description: "How to send terminal notifications.",
        showInDialog: true,
        options: [
          { value: "auto", label: "Auto" },
          { value: "osc9", label: "OSC 9" },
          { value: "osc777", label: "OSC 777" },
          { value: "bell", label: "Bell" }
        ]
      },
      checkpointing: {
        type: "object",
        label: "Checkpointing",
        category: "General",
        requiresRestart: true,
        default: {},
        description: "Session checkpointing settings.",
        showInDialog: false,
        properties: {
          enabled: {
            type: "boolean",
            label: "Enable Checkpointing",
            category: "General",
            requiresRestart: true,
            default: false,
            description: "Enable session checkpointing for recovery",
            showInDialog: false
          }
        }
      },
      plan: {
        type: "object",
        label: "Plan",
        category: "General",
        requiresRestart: true,
        default: {},
        description: "Planning features configuration.",
        showInDialog: false,
        properties: {
          enabled: {
            type: "boolean",
            label: "Enable Plan Mode",
            category: "General",
            requiresRestart: true,
            default: true,
            description: "Enable Plan Mode for read-only safety during planning.",
            showInDialog: true
          },
          directory: {
            type: "string",
            label: "Plan Directory",
            category: "General",
            requiresRestart: true,
            default: void 0,
            description: "The directory where planning artifacts are stored. If not specified, defaults to the system temporary directory. A custom directory requires a policy to allow write access in Plan Mode.",
            showInDialog: true
          },
          modelRouting: {
            type: "boolean",
            label: "Plan Model Routing",
            category: "General",
            requiresRestart: false,
            default: true,
            description: "Automatically switch between Pro and Flash models based on Plan Mode status. Uses Pro for the planning phase and Flash for the implementation phase.",
            showInDialog: true
          }
        }
      },
      retryFetchErrors: {
        type: "boolean",
        label: "Retry Fetch Errors",
        category: "General",
        requiresRestart: false,
        default: true,
        description: 'Retry on "exception TypeError: fetch failed sending request" errors.',
        showInDialog: true
      },
      maxAttempts: {
        type: "number",
        label: "Max Chat Model Attempts",
        category: "General",
        requiresRestart: false,
        default: 10,
        description: "Maximum number of attempts for requests to the main chat model. Cannot exceed 10.",
        showInDialog: true
      },
      debugKeystrokeLogging: {
        type: "boolean",
        label: "Debug Keystroke Logging",
        category: "General",
        requiresRestart: false,
        default: false,
        description: "Enable debug logging of keystrokes to the console.",
        showInDialog: true
      },
      sessionRetention: {
        type: "object",
        label: "Session Retention",
        category: "General",
        requiresRestart: false,
        default: void 0,
        showInDialog: false,
        properties: {
          enabled: {
            type: "boolean",
            label: "Enable Session Cleanup",
            category: "General",
            requiresRestart: false,
            default: true,
            description: "Enable automatic session cleanup",
            showInDialog: true
          },
          maxAge: {
            type: "string",
            label: "Keep chat history",
            category: "General",
            requiresRestart: false,
            default: "30d",
            description: 'Automatically delete chats older than this time period (e.g., "30d", "7d", "24h", "1w")',
            showInDialog: true
          },
          maxCount: {
            type: "number",
            label: "Max Session Count",
            category: "General",
            requiresRestart: false,
            default: void 0,
            description: "Alternative: Maximum number of sessions to keep (most recent)",
            showInDialog: false
          },
          minRetention: {
            type: "string",
            label: "Min Retention Period",
            category: "General",
            requiresRestart: false,
            default: DEFAULT_MIN_RETENTION,
            description: `Minimum retention period (safety limit, defaults to "${DEFAULT_MIN_RETENTION}")`,
            showInDialog: false
          }
        },
        description: "Settings for automatic session cleanup."
      },
      topicUpdateNarration: {
        type: "boolean",
        label: "Topic & Update Narration",
        category: "General",
        requiresRestart: false,
        default: true,
        description: "Enable the Topic & Update communication model for reduced chattiness and structured progress reporting.",
        showInDialog: true
      },
      logRagSnippets: {
        type: "boolean",
        label: "Log RAG Snippets",
        category: "General",
        requiresRestart: false,
        default: false,
        description: "Log full Code Customization (RAG) retrieved snippets to a local file for debugging.",
        showInDialog: true
      }
    }
  },
  output: {
    type: "object",
    label: "Output",
    category: "General",
    requiresRestart: false,
    default: {},
    description: "Settings for the CLI output.",
    showInDialog: false,
    properties: {
      format: {
        type: "enum",
        label: "Output Format",
        category: "General",
        requiresRestart: false,
        default: "text",
        description: "The format of the CLI output. Can be `text` or `json`.",
        showInDialog: true,
        options: [
          { value: "text", label: "Text" },
          { value: "json", label: "JSON" }
        ]
      }
    }
  },
  ui: {
    type: "object",
    label: "UI",
    category: "UI",
    requiresRestart: false,
    default: {},
    description: "User interface settings.",
    showInDialog: false,
    properties: {
      debugRainbow: {
        type: "boolean",
        label: "Debug Rainbow",
        category: "UI",
        requiresRestart: true,
        default: false,
        description: "Enable debug rainbow rendering. Only useful for debugging rendering bugs and performance issues.",
        showInDialog: false
      },
      theme: {
        type: "string",
        label: "Theme",
        category: "UI",
        requiresRestart: false,
        default: void 0,
        description: "The color theme for the UI. See the CLI themes guide for available options.",
        showInDialog: false
      },
      autoThemeSwitching: {
        type: "boolean",
        label: "Auto Theme Switching",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Automatically switch between default light and dark themes based on terminal background color.",
        showInDialog: true
      },
      terminalBackgroundPollingInterval: {
        type: "number",
        label: "Terminal Background Polling Interval",
        category: "UI",
        requiresRestart: false,
        default: 60,
        description: "Interval in seconds to poll the terminal background color.",
        showInDialog: true
      },
      customThemes: {
        type: "object",
        label: "Custom Themes",
        category: "UI",
        requiresRestart: false,
        default: {},
        description: "Custom theme definitions.",
        showInDialog: false,
        additionalProperties: {
          type: "object",
          ref: "CustomTheme"
        }
      },
      hideWindowTitle: {
        type: "boolean",
        label: "Hide Window Title",
        category: "UI",
        requiresRestart: true,
        default: false,
        description: "Hide the window title bar",
        showInDialog: true
      },
      inlineThinkingMode: {
        type: "enum",
        label: "Inline Thinking",
        category: "UI",
        requiresRestart: false,
        default: "off",
        description: "Display model thinking inline: off or full.",
        showInDialog: true,
        options: [
          { value: "off", label: "Off" },
          { value: "full", label: "Full" }
        ]
      },
      showStatusInTitle: {
        type: "boolean",
        label: "Show Thoughts in Title",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Show Gemini CLI model thoughts in the terminal window title during the working phase",
        showInDialog: true
      },
      dynamicWindowTitle: {
        type: "boolean",
        label: "Dynamic Window Title",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Update the terminal window title with current status icons (Ready: \u25C7, Action Required: \u270B, Working: \u2726)",
        showInDialog: true
      },
      showHomeDirectoryWarning: {
        type: "boolean",
        label: "Show Home Directory Warning",
        category: "UI",
        requiresRestart: true,
        default: true,
        description: "Show a warning when running Gemini CLI in the home directory.",
        showInDialog: true
      },
      showCompatibilityWarnings: {
        type: "boolean",
        label: "Show Compatibility Warnings",
        category: "UI",
        requiresRestart: true,
        default: true,
        description: "Show warnings about terminal or OS compatibility issues.",
        showInDialog: true
      },
      hideTips: {
        type: "boolean",
        label: "Hide Tips",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Hide helpful tips in the UI",
        showInDialog: true
      },
      escapePastedAtSymbols: {
        type: "boolean",
        label: "Escape Pasted @ Symbols",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "When enabled, @ symbols in pasted text are escaped to prevent unintended @path expansion.",
        showInDialog: true
      },
      showShortcutsHint: {
        type: "boolean",
        label: "Show Shortcuts Hint",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: 'Show the "? for shortcuts" hint above the input.',
        showInDialog: true
      },
      compactToolOutput: {
        type: "boolean",
        label: "Compact Tool Output",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Display tool outputs (like directory listings and file reads) in a compact, structured format.",
        showInDialog: true
      },
      hideBanner: {
        type: "boolean",
        label: "Hide Banner",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Hide the application banner",
        showInDialog: true
      },
      hideContextSummary: {
        type: "boolean",
        label: "Hide Context Summary",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Hide the context summary (GEMINI.md, MCP servers) above the input.",
        showInDialog: true
      },
      footer: {
        type: "object",
        label: "Footer",
        category: "UI",
        requiresRestart: false,
        default: {},
        description: "Settings for the footer.",
        showInDialog: false,
        properties: {
          items: {
            type: "array",
            label: "Footer Items",
            category: "UI",
            requiresRestart: false,
            default: void 0,
            description: "List of item IDs to display in the footer. Rendered in order",
            showInDialog: false,
            items: { type: "string" }
          },
          showLabels: {
            type: "boolean",
            label: "Show Footer Labels",
            category: "UI",
            requiresRestart: false,
            default: true,
            description: "Display a second line above the footer items with descriptive headers (e.g., /model).",
            showInDialog: false
          },
          hideCWD: {
            type: "boolean",
            label: "Hide CWD",
            category: "UI",
            requiresRestart: false,
            default: false,
            description: "Hide the current working directory in the footer.",
            showInDialog: true
          },
          hideSandboxStatus: {
            type: "boolean",
            label: "Hide Sandbox Status",
            category: "UI",
            requiresRestart: false,
            default: false,
            description: "Hide the sandbox status indicator in the footer.",
            showInDialog: true
          },
          hideModelInfo: {
            type: "boolean",
            label: "Hide Model Info",
            category: "UI",
            requiresRestart: false,
            default: false,
            description: "Hide the model name and context usage in the footer.",
            showInDialog: true
          },
          hideContextPercentage: {
            type: "boolean",
            label: "Hide Context Window Percentage",
            category: "UI",
            requiresRestart: false,
            default: true,
            description: "Hides the context window usage percentage.",
            showInDialog: true
          }
        }
      },
      hideFooter: {
        type: "boolean",
        label: "Hide Footer",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Hide the footer from the UI",
        showInDialog: true
      },
      collapseDrawerDuringApproval: {
        type: "boolean",
        label: "Collapse Drawer During Approval",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Whether to collapse the UI drawer when a tool is awaiting confirmation.",
        showInDialog: false
      },
      showMemoryUsage: {
        type: "boolean",
        label: "Show Memory Usage",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Display memory usage information in the UI",
        showInDialog: true
      },
      showLineNumbers: {
        type: "boolean",
        label: "Show Line Numbers",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Show line numbers in the chat.",
        showInDialog: true
      },
      showCitations: {
        type: "boolean",
        label: "Show Citations",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Show citations for generated text in the chat.",
        showInDialog: true
      },
      showModelInfoInChat: {
        type: "boolean",
        label: "Show Model Info In Chat",
        category: "UI",
        requiresRestart: false,
        default: false,
        description: "Show the model name in the chat for each model turn.",
        showInDialog: true
      },
      showUserIdentity: {
        type: "boolean",
        label: "Show User Identity",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Show the signed-in user's identity (e.g. email) in the UI.",
        showInDialog: true
      },
      useAlternateBuffer: {
        type: "boolean",
        label: "Use Alternate Screen Buffer",
        category: "UI",
        requiresRestart: true,
        default: false,
        description: "Use an alternate screen buffer for the UI, preserving shell history.",
        showInDialog: true
      },
      renderProcess: {
        type: "boolean",
        label: "Render Process",
        category: "UI",
        requiresRestart: true,
        default: true,
        description: "Enable Ink render process for the UI.",
        showInDialog: true
      },
      terminalBuffer: {
        type: "boolean",
        label: "Terminal Buffer",
        category: "UI",
        requiresRestart: true,
        default: false,
        description: "Use the new terminal buffer architecture for rendering.",
        showInDialog: true
      },
      useBackgroundColor: {
        type: "boolean",
        label: "Use Background Color",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Whether to use background colors in the UI.",
        showInDialog: true
      },
      incrementalRendering: {
        type: "boolean",
        label: "Incremental Rendering",
        category: "UI",
        requiresRestart: true,
        default: true,
        description: "Enable incremental rendering for the UI. This option will reduce flickering but may cause rendering artifacts. Only supported when useAlternateBuffer is enabled.",
        showInDialog: true
      },
      showSpinner: {
        type: "boolean",
        label: "Show Spinner",
        category: "UI",
        requiresRestart: false,
        default: true,
        description: "Show the spinner during operations.",
        showInDialog: true
      },
      loadingPhrases: {
        type: "enum",
        label: "Loading Phrases",
        category: "UI",
        requiresRestart: false,
        default: "off",
        description: "What to show while the model is working: tips, witty comments, all, or off.",
        showInDialog: true,
        options: [
          { value: "tips", label: "Tips" },
          { value: "witty", label: "Witty" },
          { value: "all", label: "All" },
          { value: "off", label: "Off" }
        ]
      },
      errorVerbosity: {
        type: "enum",
        label: "Error Verbosity",
        category: "UI",
        requiresRestart: false,
        default: "low",
        description: "Controls whether recoverable errors are hidden (low) or fully shown (full).",
        showInDialog: true,
        options: [
          { value: "low", label: "Low" },
          { value: "full", label: "Full" }
        ]
      },
      customWittyPhrases: {
        type: "array",
        label: "Custom Witty Phrases",
        category: "UI",
        requiresRestart: false,
        default: [],
        description: oneLine`
          Custom witty phrases to display during loading.
          When provided, the CLI cycles through these instead of the defaults.
        `,
        showInDialog: false,
        items: { type: "string" }
      },
      accessibility: {
        type: "object",
        label: "Accessibility",
        category: "UI",
        requiresRestart: true,
        default: {},
        description: "Accessibility settings.",
        showInDialog: false,
        properties: {
          enableLoadingPhrases: {
            type: "boolean",
            label: "Enable Loading Phrases",
            category: "UI",
            requiresRestart: true,
            default: true,
            description: "@deprecated Use ui.loadingPhrases instead. Enable loading phrases during operations.",
            showInDialog: false
          },
          screenReader: {
            type: "boolean",
            label: "Screen Reader Mode",
            category: "UI",
            requiresRestart: true,
            default: false,
            description: "Render output in plain-text to be more screen reader accessible",
            showInDialog: true
          }
        }
      }
    }
  },
  ide: {
    type: "object",
    label: "IDE",
    category: "IDE",
    requiresRestart: true,
    default: {},
    description: "IDE integration settings.",
    showInDialog: false,
    properties: {
      enabled: {
        type: "boolean",
        label: "IDE Mode",
        category: "IDE",
        requiresRestart: true,
        default: false,
        description: "Enable IDE integration mode.",
        showInDialog: true
      },
      hasSeenNudge: {
        type: "boolean",
        label: "Has Seen IDE Integration Nudge",
        category: "IDE",
        requiresRestart: false,
        default: false,
        description: "Whether the user has seen the IDE integration nudge.",
        showInDialog: false
      }
    }
  },
  privacy: {
    type: "object",
    label: "Privacy",
    category: "Privacy",
    requiresRestart: true,
    default: {},
    description: "Privacy-related settings.",
    showInDialog: false,
    properties: {
      usageStatisticsEnabled: {
        type: "boolean",
        label: "Enable Usage Statistics",
        category: "Privacy",
        requiresRestart: true,
        default: true,
        description: "Enable collection of usage statistics",
        showInDialog: false
      }
    }
  },
  telemetry: {
    type: "object",
    label: "Telemetry",
    category: "Advanced",
    requiresRestart: true,
    default: void 0,
    description: "Telemetry configuration.",
    showInDialog: false,
    ref: "TelemetrySettings"
  },
  billing: {
    type: "object",
    label: "Billing",
    category: "Advanced",
    requiresRestart: false,
    default: {},
    description: "Billing and AI credits settings.",
    showInDialog: false,
    properties: {
      overageStrategy: {
        type: "enum",
        label: "Overage Strategy",
        category: "Advanced",
        requiresRestart: false,
        default: "ask",
        description: oneLine`
          How to handle quota exhaustion when AI credits are available.
          'ask' prompts each time, 'always' automatically uses credits,
          'never' disables credit usage.
        `,
        showInDialog: true,
        options: [
          { value: "ask", label: "Ask each time" },
          { value: "always", label: "Always use credits" },
          { value: "never", label: "Never use credits" }
        ]
      },
      vertexAi: {
        type: "object",
        label: "Vertex AI",
        category: "Advanced",
        requiresRestart: true,
        default: void 0,
        description: "Vertex AI request routing settings.",
        showInDialog: false,
        properties: {
          requestType: {
            type: "enum",
            label: "Vertex AI Request Type",
            category: "Advanced",
            requiresRestart: true,
            default: void 0,
            description: "Sets the X-Vertex-AI-LLM-Request-Type header for Vertex AI requests.",
            showInDialog: false,
            options: [
              { value: "dedicated", label: "Dedicated" },
              { value: "shared", label: "Shared" }
            ]
          },
          sharedRequestType: {
            type: "enum",
            label: "Vertex AI Shared Request Type",
            category: "Advanced",
            requiresRestart: true,
            default: void 0,
            description: "Sets the X-Vertex-AI-LLM-Shared-Request-Type header for Vertex AI requests.",
            showInDialog: false,
            options: [
              { value: "priority", label: "Priority" },
              { value: "flex", label: "Flex" }
            ]
          }
        }
      }
    }
  },
  model: {
    type: "object",
    label: "Model",
    category: "Model",
    requiresRestart: false,
    default: {},
    description: "Settings related to the generative model.",
    showInDialog: false,
    properties: {
      name: {
        type: "string",
        label: "Model",
        category: "Model",
        requiresRestart: false,
        default: void 0,
        description: "The Gemini model to use for conversations.",
        showInDialog: true
      },
      maxSessionTurns: {
        type: "number",
        label: "Max Session Turns",
        category: "Model",
        requiresRestart: false,
        default: -1,
        description: "Maximum number of user/model/tool turns to keep in a session. -1 means unlimited.",
        showInDialog: true
      },
      summarizeToolOutput: {
        type: "object",
        label: "Summarize Tool Output",
        category: "Model",
        requiresRestart: false,
        default: void 0,
        description: oneLine`
          Enables or disables summarization of tool output.
          Configure per-tool token budgets (for example {"run_shell_command": {"tokenBudget": 2000}}).
          Currently only the run_shell_command tool supports summarization.
        `,
        showInDialog: false,
        additionalProperties: {
          type: "object",
          description: "Per-tool summarization settings with an optional tokenBudget.",
          ref: "SummarizeToolOutputSettings"
        }
      },
      compressionThreshold: {
        type: "number",
        label: "Context Compression Threshold",
        category: "Model",
        requiresRestart: true,
        default: 0.5,
        description: "The fraction of context usage at which to trigger context compression (e.g. 0.2, 0.3).",
        showInDialog: true,
        unit: "%"
      },
      disableLoopDetection: {
        type: "boolean",
        label: "Disable Loop Detection",
        category: "Model",
        requiresRestart: true,
        default: false,
        description: "Disable automatic detection and prevention of infinite loops.",
        showInDialog: true
      },
      skipNextSpeakerCheck: {
        type: "boolean",
        label: "Skip Next Speaker Check",
        category: "Model",
        requiresRestart: false,
        default: true,
        description: "Skip the next speaker check.",
        showInDialog: true
      }
    }
  },
  modelConfigs: {
    type: "object",
    label: "Model Configs",
    category: "Model",
    requiresRestart: false,
    default: DEFAULT_MODEL_CONFIGS,
    description: "Model configurations.",
    showInDialog: false,
    properties: {
      aliases: {
        type: "object",
        label: "Model Config Aliases",
        category: "Model",
        requiresRestart: false,
        default: DEFAULT_MODEL_CONFIGS.aliases,
        description: "Named presets for model configs. Can be used in place of a model name and can inherit from other aliases using an `extends` property.",
        showInDialog: false
      },
      customAliases: {
        type: "object",
        label: "Custom Model Config Aliases",
        category: "Model",
        requiresRestart: false,
        default: {},
        description: "Custom named presets for model configs. These are merged with (and override) the built-in aliases.",
        showInDialog: false
      },
      customOverrides: {
        type: "array",
        label: "Custom Model Config Overrides",
        category: "Model",
        requiresRestart: false,
        default: [],
        description: "Custom model config overrides. These are merged with (and added to) the built-in overrides.",
        showInDialog: false
      },
      overrides: {
        type: "array",
        label: "Model Config Overrides",
        category: "Model",
        requiresRestart: false,
        default: [],
        description: "Apply specific configuration overrides based on matches, with a primary key of model (or alias). The most specific match will be used.",
        showInDialog: false
      },
      modelDefinitions: {
        type: "object",
        label: "Model Definitions",
        category: "Model",
        requiresRestart: true,
        default: DEFAULT_MODEL_CONFIGS.modelDefinitions,
        description: "Registry of model metadata, including tier, family, and features.",
        showInDialog: false,
        additionalProperties: {
          type: "object",
          ref: "ModelDefinition"
        }
      },
      modelIdResolutions: {
        type: "object",
        label: "Model ID Resolutions",
        category: "Model",
        requiresRestart: true,
        default: DEFAULT_MODEL_CONFIGS.modelIdResolutions,
        description: "Rules for resolving requested model names to concrete model IDs based on context.",
        showInDialog: false,
        additionalProperties: {
          type: "object",
          ref: "ModelResolution"
        }
      },
      classifierIdResolutions: {
        type: "object",
        label: "Classifier ID Resolutions",
        category: "Model",
        requiresRestart: true,
        default: DEFAULT_MODEL_CONFIGS.classifierIdResolutions,
        description: "Rules for resolving classifier tiers (flash, pro) to concrete model IDs.",
        showInDialog: false,
        additionalProperties: {
          type: "object",
          ref: "ModelResolution"
        }
      },
      modelChains: {
        type: "object",
        label: "Model Chains",
        category: "Model",
        requiresRestart: true,
        default: DEFAULT_MODEL_CONFIGS.modelChains,
        description: "Availability policy chains defining fallback behavior for models.",
        showInDialog: false,
        additionalProperties: {
          type: "array",
          ref: "ModelPolicyChain"
        }
      }
    }
  },
  agents: {
    type: "object",
    label: "Agents",
    category: "Advanced",
    requiresRestart: true,
    default: {},
    description: "Settings for subagents.",
    showInDialog: false,
    properties: {
      overrides: {
        type: "object",
        label: "Agent Overrides",
        category: "Advanced",
        requiresRestart: true,
        default: {},
        description: "Override settings for specific agents, e.g. to disable the agent, set a custom model config, or run config.",
        showInDialog: false,
        additionalProperties: {
          type: "object",
          ref: "AgentOverride"
        }
      },
      browser: {
        type: "object",
        label: "Browser Agent",
        category: "Advanced",
        requiresRestart: true,
        default: {},
        description: "Settings specific to the browser agent.",
        showInDialog: false,
        properties: {
          sessionMode: {
            type: "enum",
            label: "Browser Session Mode",
            category: "Advanced",
            requiresRestart: true,
            default: "persistent",
            description: "Session mode: 'persistent', 'isolated', or 'existing'.",
            showInDialog: false,
            options: [
              { value: "persistent", label: "Persistent" },
              { value: "isolated", label: "Isolated" },
              { value: "existing", label: "Existing" }
            ]
          },
          headless: {
            type: "boolean",
            label: "Browser Headless",
            category: "Advanced",
            requiresRestart: true,
            default: false,
            description: "Run browser in headless mode.",
            showInDialog: false
          },
          profilePath: {
            type: "string",
            label: "Browser Profile Path",
            category: "Advanced",
            requiresRestart: true,
            default: void 0,
            description: "Path to browser profile directory for session persistence.",
            showInDialog: false
          },
          visualModel: {
            type: "string",
            label: "Browser Visual Model",
            category: "Advanced",
            requiresRestart: true,
            default: void 0,
            description: "Model for the visual agent's analyze_screenshot tool. When set, enables the tool.",
            showInDialog: false
          },
          allowedDomains: {
            type: "array",
            label: "Allowed Domains",
            category: "Advanced",
            requiresRestart: true,
            default: ["github.com", "*.google.com", "localhost"],
            description: oneLine`
              A list of allowed domains for the browser agent
              (e.g., ["github.com", "*.google.com"]).
            `,
            showInDialog: false,
            items: { type: "string" }
          },
          disableUserInput: {
            type: "boolean",
            label: "Disable User Input",
            category: "Advanced",
            requiresRestart: false,
            default: true,
            description: "Disable user input on browser window during automation.",
            showInDialog: false
          },
          maxActionsPerTask: {
            type: "number",
            label: "Max Actions Per Task",
            category: "Advanced",
            requiresRestart: false,
            default: 100,
            description: "The maximum number of tool calls allowed per browser task. Enforcement is hard: the agent will be terminated when the limit is reached.",
            showInDialog: false
          },
          confirmSensitiveActions: {
            type: "boolean",
            label: "Confirm Sensitive Actions",
            category: "Advanced",
            requiresRestart: true,
            default: false,
            description: "Require manual confirmation for sensitive browser actions (e.g., fill_form, evaluate_script).",
            showInDialog: true
          },
          blockFileUploads: {
            type: "boolean",
            label: "Block File Uploads",
            category: "Advanced",
            requiresRestart: true,
            default: false,
            description: "Hard-block file upload requests from the browser agent.",
            showInDialog: true
          }
        }
      }
    }
  },
  context: {
    type: "object",
    label: "Context",
    category: "Context",
    requiresRestart: false,
    default: {},
    description: "Settings for managing context provided to the model.",
    showInDialog: false,
    properties: {
      fileName: {
        type: "string",
        label: "Context File Name",
        category: "Context",
        requiresRestart: false,
        default: void 0,
        ref: "StringOrStringArray",
        description: "The name of the context file or files to load into memory. Accepts either a single string or an array of strings.",
        showInDialog: false
      },
      importFormat: {
        type: "string",
        label: "Memory Import Format",
        category: "Context",
        requiresRestart: false,
        default: void 0,
        description: "The format to use when importing memory.",
        showInDialog: false
      },
      includeDirectoryTree: {
        type: "boolean",
        label: "Include Directory Tree",
        category: "Context",
        requiresRestart: false,
        default: true,
        description: "Whether to include the directory tree of the current working directory in the initial request to the model.",
        showInDialog: false
      },
      discoveryMaxDirs: {
        type: "number",
        label: "Memory Discovery Max Dirs",
        category: "Context",
        requiresRestart: false,
        default: 200,
        description: "Maximum number of directories to search for memory.",
        showInDialog: true
      },
      memoryBoundaryMarkers: {
        type: "array",
        label: "Memory Boundary Markers",
        category: "Context",
        requiresRestart: true,
        default: [".git"],
        description: "File or directory names that mark the boundary for GEMINI.md discovery. The upward traversal stops at the first directory containing any of these markers. An empty array disables parent traversal.",
        showInDialog: false,
        items: { type: "string" }
      },
      includeDirectories: {
        type: "array",
        label: "Include Directories",
        category: "Context",
        requiresRestart: false,
        default: [],
        description: oneLine`
          Additional directories to include in the workspace context.
          Missing directories will be skipped with a warning.
        `,
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "concat" /* CONCAT */
      },
      loadMemoryFromIncludeDirectories: {
        type: "boolean",
        label: "Load Memory From Include Directories",
        category: "Context",
        requiresRestart: false,
        default: false,
        description: oneLine`
          Controls how /memory reload loads GEMINI.md files.
          When true, include directories are scanned; when false, only the current directory is used.
        `,
        showInDialog: true
      },
      fileFiltering: {
        type: "object",
        label: "File Filtering",
        category: "Context",
        requiresRestart: true,
        default: {},
        description: "Settings for git-aware file filtering.",
        showInDialog: false,
        properties: {
          respectGitIgnore: {
            type: "boolean",
            label: "Respect .gitignore",
            category: "Context",
            requiresRestart: true,
            default: true,
            description: "Respect .gitignore files when searching.",
            showInDialog: true
          },
          respectGeminiIgnore: {
            type: "boolean",
            label: "Respect .geminiignore",
            category: "Context",
            requiresRestart: true,
            default: true,
            description: "Respect .geminiignore files when searching.",
            showInDialog: true
          },
          enableFileWatcher: {
            type: "boolean",
            label: "Enable File Watcher",
            category: "Context",
            requiresRestart: true,
            default: false,
            description: oneLine`
              Enable file watcher updates for @ file suggestions (experimental).
            `,
            showInDialog: false
          },
          enableRecursiveFileSearch: {
            type: "boolean",
            label: "Enable Recursive File Search",
            category: "Context",
            requiresRestart: true,
            default: true,
            description: oneLine`
              Enable recursive file search functionality when completing @ references in the prompt.
            `,
            showInDialog: true
          },
          enableFuzzySearch: {
            type: "boolean",
            label: "Enable Fuzzy Search",
            category: "Context",
            requiresRestart: true,
            default: true,
            description: "Enable fuzzy search when searching for files.",
            showInDialog: true
          },
          customIgnoreFilePaths: {
            type: "array",
            label: "Custom Ignore File Paths",
            category: "Context",
            requiresRestart: true,
            default: [],
            description: "Additional ignore file paths to respect. These files take precedence over .geminiignore and .gitignore. Files earlier in the array take precedence over files later in the array, e.g. the first file takes precedence over the second one.",
            showInDialog: true,
            items: { type: "string" },
            mergeStrategy: "union" /* UNION */
          }
        }
      }
    }
  },
  tools: {
    type: "object",
    label: "Tools",
    category: "Tools",
    requiresRestart: true,
    default: {},
    description: "Settings for built-in and custom tools.",
    showInDialog: false,
    properties: {
      sandbox: {
        type: "string",
        label: "Sandbox",
        category: "Tools",
        requiresRestart: true,
        default: void 0,
        ref: "BooleanOrStringOrObject",
        description: oneLine`
          Legacy full-process sandbox execution environment.
          Set to a boolean to enable or disable the sandbox, provide a string path to a sandbox profile,
          or specify an explicit sandbox command (e.g., "docker", "podman", "lxc", "windows-native").
        `,
        showInDialog: false
      },
      sandboxAllowedPaths: {
        type: "array",
        label: "Sandbox Allowed Paths",
        category: "Tools",
        requiresRestart: true,
        default: [],
        description: "List of additional paths that the sandbox is allowed to access.",
        showInDialog: true,
        items: { type: "string" }
      },
      sandboxNetworkAccess: {
        type: "boolean",
        label: "Sandbox Network Access",
        category: "Tools",
        requiresRestart: true,
        default: false,
        description: "Whether the sandbox is allowed to access the network.",
        showInDialog: true
      },
      shell: {
        type: "object",
        label: "Shell",
        category: "Tools",
        requiresRestart: false,
        default: {},
        description: "Settings for shell execution.",
        showInDialog: false,
        properties: {
          enableInteractiveShell: {
            type: "boolean",
            label: "Enable Interactive Shell",
            category: "Tools",
            requiresRestart: true,
            default: true,
            description: oneLine`
              Use node-pty for an interactive shell experience.
              Fallback to child_process still applies.
            `,
            showInDialog: true
          },
          backgroundCompletionBehavior: {
            type: "enum",
            label: "Background Completion Behavior",
            category: "Tools",
            requiresRestart: false,
            default: "silent",
            description: "Controls what happens when a background shell command finishes. 'silent' (default): quietly exits in background. 'inject': automatically returns output to agent. 'notify': shows brief message in chat.",
            showInDialog: false,
            options: [
              { label: "Silent", value: "silent" },
              { label: "Inject", value: "inject" },
              { label: "Notify", value: "notify" }
            ]
          },
          pager: {
            type: "string",
            label: "Pager",
            category: "Tools",
            requiresRestart: false,
            default: "cat",
            description: "The pager command to use for shell output. Defaults to `cat`.",
            showInDialog: false
          },
          showColor: {
            type: "boolean",
            label: "Show Color",
            category: "Tools",
            requiresRestart: false,
            default: true,
            description: "Show color in shell output.",
            showInDialog: true
          },
          inactivityTimeout: {
            type: "number",
            label: "Inactivity Timeout",
            category: "Tools",
            requiresRestart: false,
            default: 300,
            description: "The maximum time in seconds allowed without output from the shell command. Defaults to 5 minutes.",
            showInDialog: false
          },
          enableShellOutputEfficiency: {
            type: "boolean",
            label: "Enable Shell Output Efficiency",
            category: "Tools",
            requiresRestart: false,
            default: true,
            description: "Enable shell output efficiency optimizations for better performance.",
            showInDialog: false
          }
        }
      },
      core: {
        type: "array",
        label: "Core Tools",
        category: "Tools",
        requiresRestart: true,
        default: void 0,
        description: oneLine`
          Restrict the set of built-in tools with an allowlist.
          Match semantics mirror tools.allowed; see the built-in tools documentation for available names.
        `,
        showInDialog: false,
        items: { type: "string" }
      },
      allowed: {
        type: "array",
        label: "Allowed Tools",
        category: "Advanced",
        requiresRestart: true,
        default: void 0,
        description: oneLine`
          Tool names that bypass the confirmation dialog.
          Useful for trusted commands (for example ["run_shell_command(git)", "run_shell_command(npm test)"]).
          See shell tool command restrictions for matching details.
        `,
        showInDialog: false,
        items: { type: "string" }
      },
      confirmationRequired: {
        type: "array",
        label: "Confirmation Required",
        category: "Advanced",
        requiresRestart: true,
        default: void 0,
        description: oneLine`
          Tool names that always require user confirmation.
          Takes precedence over allowed tools and core tool allowlists.
        `,
        showInDialog: false,
        items: { type: "string" }
      },
      exclude: {
        type: "array",
        label: "Exclude Tools",
        category: "Tools",
        requiresRestart: true,
        default: void 0,
        description: "Tool names to exclude from discovery.",
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "union" /* UNION */
      },
      discoveryCommand: {
        type: "string",
        label: "Tool Discovery Command",
        category: "Tools",
        requiresRestart: true,
        default: void 0,
        description: "Command to run for tool discovery.",
        showInDialog: false
      },
      callCommand: {
        type: "string",
        label: "Tool Call Command",
        category: "Tools",
        requiresRestart: true,
        default: void 0,
        description: oneLine`
          Defines a custom shell command for invoking discovered tools.
          The command must take the tool name as the first argument, read JSON arguments from stdin, and emit JSON results on stdout.
        `,
        showInDialog: false
      },
      useRipgrep: {
        type: "boolean",
        label: "Use Ripgrep",
        category: "Tools",
        requiresRestart: false,
        default: true,
        description: "Use ripgrep for file content search instead of the fallback implementation. Provides faster search performance.",
        showInDialog: true
      },
      truncateToolOutputThreshold: {
        type: "number",
        label: "Tool Output Truncation Threshold",
        category: "General",
        requiresRestart: true,
        default: DEFAULT_TRUNCATE_TOOL_OUTPUT_THRESHOLD,
        description: "Maximum characters to show when truncating large tool outputs. Set to 0 or negative to disable truncation.",
        showInDialog: true
      },
      disableLLMCorrection: {
        type: "boolean",
        label: "Disable LLM Correction",
        category: "Tools",
        requiresRestart: true,
        default: true,
        description: oneLine`
          Disable LLM-based error correction for edit tools.
          When enabled, tools will fail immediately if exact string matches are not found, instead of attempting to self-correct.
        `,
        showInDialog: true
      }
    }
  },
  mcp: {
    type: "object",
    label: "MCP",
    category: "MCP",
    requiresRestart: true,
    default: {},
    description: "Settings for Model Context Protocol (MCP) servers.",
    showInDialog: false,
    properties: {
      serverCommand: {
        type: "string",
        label: "MCP Server Command",
        category: "MCP",
        requiresRestart: true,
        default: void 0,
        description: "Command to start an MCP server.",
        showInDialog: false
      },
      allowed: {
        type: "array",
        label: "Allow MCP Servers",
        category: "MCP",
        requiresRestart: true,
        default: void 0,
        description: "A list of MCP servers to allow.",
        showInDialog: false,
        items: { type: "string" }
      },
      excluded: {
        type: "array",
        label: "Exclude MCP Servers",
        category: "MCP",
        requiresRestart: true,
        default: void 0,
        description: "A list of MCP servers to exclude.",
        showInDialog: false,
        items: { type: "string" }
      }
    }
  },
  useWriteTodos: {
    type: "boolean",
    label: "Use WriteTodos",
    category: "Advanced",
    requiresRestart: false,
    default: true,
    description: "Enable the write_todos tool.",
    showInDialog: false
  },
  security: {
    type: "object",
    label: "Security",
    category: "Security",
    requiresRestart: true,
    default: {},
    description: "Security-related settings.",
    showInDialog: false,
    properties: {
      toolSandboxing: {
        type: "boolean",
        label: "Tool Sandboxing",
        category: "Security",
        requiresRestart: true,
        default: false,
        description: "Tool-level sandboxing. Isolates individual tools instead of the entire CLI process.",
        showInDialog: true
      },
      disableYoloMode: {
        type: "boolean",
        label: "Disable YOLO Mode",
        category: "Security",
        requiresRestart: true,
        default: false,
        description: "Disable YOLO mode, even if enabled by a flag.",
        showInDialog: true
      },
      disableAlwaysAllow: {
        type: "boolean",
        label: "Disable Always Allow",
        category: "Security",
        requiresRestart: true,
        default: false,
        description: 'Disable "Always allow" options in tool confirmation dialogs.',
        showInDialog: true
      },
      enablePermanentToolApproval: {
        type: "boolean",
        label: "Allow Permanent Tool Approval",
        category: "Security",
        requiresRestart: false,
        default: false,
        description: 'Enable the "Allow for all future sessions" option in tool confirmation dialogs.',
        showInDialog: true
      },
      autoAddToPolicyByDefault: {
        type: "boolean",
        label: "Auto-add to Policy by Default",
        category: "Security",
        requiresRestart: false,
        default: false,
        description: oneLine`
          When enabled, the "Allow for all future sessions" option becomes the
          default choice for low-risk tools in trusted workspaces.
        `,
        showInDialog: true
      },
      blockGitExtensions: {
        type: "boolean",
        label: "Blocks extensions from Git",
        category: "Security",
        requiresRestart: true,
        default: false,
        description: "Blocks installing and loading extensions from Git.",
        showInDialog: true
      },
      allowedExtensions: {
        type: "array",
        label: "Extension Source Regex Allowlist",
        category: "Security",
        requiresRestart: true,
        default: [],
        description: "List of Regex patterns for allowed extensions. If nonempty, only extensions that match the patterns in this list are allowed. Overrides the blockGitExtensions setting.",
        showInDialog: true,
        items: { type: "string" }
      },
      folderTrust: {
        type: "object",
        label: "Folder Trust",
        category: "Security",
        requiresRestart: false,
        default: {},
        description: "Settings for folder trust.",
        showInDialog: false,
        properties: {
          enabled: {
            type: "boolean",
            label: "Folder Trust",
            category: "Security",
            requiresRestart: true,
            default: true,
            description: "Setting to track whether Folder trust is enabled.",
            showInDialog: true
          }
        }
      },
      environmentVariableRedaction: {
        type: "object",
        label: "Environment Variable Redaction",
        category: "Security",
        requiresRestart: false,
        default: {},
        description: "Settings for environment variable redaction.",
        showInDialog: false,
        properties: {
          allowed: {
            type: "array",
            label: "Allowed Environment Variables",
            category: "Security",
            requiresRestart: true,
            default: [],
            description: "Environment variables to always allow (bypass redaction).",
            showInDialog: false,
            items: { type: "string" }
          },
          blocked: {
            type: "array",
            label: "Blocked Environment Variables",
            category: "Security",
            requiresRestart: true,
            default: [],
            description: "Environment variables to always redact.",
            showInDialog: false,
            items: { type: "string" }
          },
          enabled: {
            type: "boolean",
            label: "Enable Environment Variable Redaction",
            category: "Security",
            requiresRestart: true,
            default: false,
            description: "Enable redaction of environment variables that may contain secrets.",
            showInDialog: true
          }
        }
      },
      auth: {
        type: "object",
        label: "Authentication",
        category: "Security",
        requiresRestart: true,
        default: {},
        description: "Authentication settings.",
        showInDialog: false,
        properties: {
          selectedType: {
            type: "string",
            label: "Selected Auth Type",
            category: "Security",
            requiresRestart: true,
            default: void 0,
            description: "The currently selected authentication type.",
            showInDialog: false
          },
          enforcedType: {
            type: "string",
            label: "Enforced Auth Type",
            category: "Advanced",
            requiresRestart: true,
            default: void 0,
            description: "The required auth type. If this does not match the selected auth type, the user will be prompted to re-authenticate.",
            showInDialog: false
          },
          useExternal: {
            type: "boolean",
            label: "Use External Auth",
            category: "Security",
            requiresRestart: true,
            default: void 0,
            description: "Whether to use an external authentication flow.",
            showInDialog: false
          }
        }
      },
      enableConseca: {
        type: "boolean",
        label: "Enable Context-Aware Security",
        category: "Security",
        requiresRestart: true,
        default: false,
        description: "Enable the context-aware security checker. This feature uses an LLM to dynamically generate and enforce security policies for tool use based on your prompt, providing an additional layer of protection against unintended actions.",
        showInDialog: true
      }
    }
  },
  advanced: {
    type: "object",
    label: "Advanced",
    category: "Advanced",
    requiresRestart: true,
    default: {},
    description: "Advanced settings for power users.",
    showInDialog: false,
    properties: {
      autoConfigureMemory: {
        type: "boolean",
        label: "Auto Configure Max Old Space Size",
        category: "Advanced",
        requiresRestart: true,
        default: true,
        description: "Automatically configure Node.js memory limits. Note: Because memory is allocated during the initial process boot, this setting is only read from the global user settings file and ignores workspace-level overrides.",
        showInDialog: true
      },
      dnsResolutionOrder: {
        type: "string",
        label: "DNS Resolution Order",
        category: "Advanced",
        requiresRestart: true,
        default: void 0,
        description: "The DNS resolution order.",
        showInDialog: false
      },
      excludedEnvVars: {
        type: "array",
        label: "Excluded Project Environment Variables",
        category: "Advanced",
        requiresRestart: false,
        default: ["DEBUG", "DEBUG_MODE"],
        description: "Environment variables to exclude from project context.",
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "union" /* UNION */
      },
      ignoreLocalEnv: {
        type: "boolean",
        label: "Ignore Local .env",
        category: "Advanced",
        requiresRestart: true,
        default: false,
        description: "Whether to ignore generic .env files in the project directory.",
        showInDialog: true
      },
      bugCommand: {
        type: "object",
        label: "Bug Command",
        category: "Advanced",
        requiresRestart: false,
        default: void 0,
        description: "Configuration for the bug report command.",
        showInDialog: false,
        ref: "BugCommandSettings"
      }
    }
  },
  experimental: {
    type: "object",
    label: "Experimental",
    category: "Experimental",
    requiresRestart: true,
    default: {},
    description: "Setting to enable experimental features",
    showInDialog: false,
    properties: {
      gemma: {
        type: "boolean",
        label: "Gemma Models",
        category: "Experimental",
        requiresRestart: true,
        default: true,
        description: "Enable access to Gemma 4 models via Gemini API.",
        showInDialog: true
      },
      voiceMode: {
        type: "boolean",
        label: "Voice Mode",
        category: "Experimental",
        requiresRestart: false,
        default: false,
        description: "Enable experimental voice dictation and commands (/voice, /voice model).",
        showInDialog: true
      },
      voice: {
        type: "object",
        label: "Voice",
        category: "Experimental",
        requiresRestart: false,
        default: {},
        description: "Settings for voice mode and transcription.",
        showInDialog: false,
        properties: {
          activationMode: {
            type: "enum",
            label: "Voice Activation Mode",
            category: "Experimental",
            requiresRestart: false,
            default: "push-to-talk",
            description: "How to trigger voice recording with the Space key.",
            showInDialog: true,
            options: [
              { value: "push-to-talk", label: "Push-To-Talk (Hold Space)" },
              { value: "toggle", label: "Toggle (Press Space to start/stop)" }
            ]
          },
          backend: {
            type: "enum",
            label: "Voice Transcription Backend",
            category: "Experimental",
            requiresRestart: false,
            default: "gemini-live",
            description: oneLine`
              The backend to use for voice transcription. Note: When using the
              Gemini Live backend, voice recordings are sent to Google Cloud for
              transcription.
            `,
            showInDialog: true,
            options: [
              { value: "gemini-live", label: "Gemini Live API (Cloud)" },
              { value: "whisper", label: "Whisper (Local)" }
            ]
          },
          whisperModel: {
            type: "enum",
            label: "Whisper Model",
            category: "Experimental",
            requiresRestart: false,
            default: "ggml-base.en.bin",
            description: "The Whisper model to use for local transcription.",
            showInDialog: true,
            options: [
              { value: "ggml-tiny.en.bin", label: "Tiny (EN) - Fast (~75MB)" },
              {
                value: "ggml-base.en.bin",
                label: "Base (EN) - Balanced (~142MB)"
              },
              {
                value: "ggml-large-v3-turbo-q5_0.bin",
                label: "Large v3 Turbo (Q5_0) - High Accuracy (~547MB)"
              },
              {
                value: "ggml-large-v3-turbo-q8_0.bin",
                label: "Large v3 Turbo (Q8_0) - Max Accuracy (~834MB)"
              }
            ]
          },
          stopGracePeriodMs: {
            type: "number",
            label: "Voice Stop Grace Period (ms)",
            category: "Experimental",
            requiresRestart: false,
            default: 4e3,
            description: "How long to wait for final transcription after stopping recording.",
            showInDialog: true
          }
        }
      },
      adk: {
        type: "object",
        label: "ADK",
        category: "Experimental",
        requiresRestart: true,
        default: {},
        description: "Settings for the Agent Development Kit (ADK).",
        showInDialog: false,
        properties: {
          agentSessionNoninteractiveEnabled: {
            type: "boolean",
            label: "Agent Session Non-interactive Enabled",
            category: "Experimental",
            requiresRestart: true,
            default: false,
            description: "Enable non-interactive agent sessions.",
            showInDialog: false
          },
          agentSessionInteractiveEnabled: {
            type: "boolean",
            label: "Interactive Agent Session Enabled",
            category: "Experimental",
            requiresRestart: true,
            default: false,
            description: "Enable the agent session implementation for the interactive CLI.",
            showInDialog: false
          },
          agentSessionSubagentEnabled: {
            type: "boolean",
            label: "Agent Session Subagent Enabled",
            category: "Experimental",
            requiresRestart: true,
            default: false,
            description: "Route subagent invocations through the AgentSession protocol instead of legacy executors.",
            showInDialog: false
          }
        }
      },
      enableAgents: {
        type: "boolean",
        label: "Enable Agents",
        category: "Experimental",
        requiresRestart: true,
        default: true,
        description: "Enable local and remote subagents.",
        showInDialog: false
      },
      worktrees: {
        type: "boolean",
        label: "Enable Git Worktrees",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable automated Git worktree management for parallel work.",
        showInDialog: true
      },
      extensionManagement: {
        type: "boolean",
        label: "Extension Management",
        category: "Experimental",
        requiresRestart: true,
        default: true,
        description: "Enable extension management features.",
        showInDialog: false
      },
      extensionConfig: {
        type: "boolean",
        label: "Extension Configuration",
        category: "Experimental",
        requiresRestart: true,
        default: true,
        description: "Enable requesting and fetching of extension settings.",
        showInDialog: false
      },
      extensionRegistry: {
        type: "boolean",
        label: "Extension Registry Explore UI",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable extension registry explore UI.",
        showInDialog: false
      },
      extensionRegistryURI: {
        type: "string",
        label: "Extension Registry URI",
        category: "Experimental",
        requiresRestart: true,
        default: "https://geminicli.com/extensions.json",
        description: "The URI (web URL or local file path) of the extension registry.",
        showInDialog: false
      },
      extensionReloading: {
        type: "boolean",
        label: "Extension Reloading",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enables extension loading/unloading within the CLI session.",
        showInDialog: false
      },
      useOSC52Paste: {
        type: "boolean",
        label: "Use OSC 52 Paste",
        category: "Experimental",
        requiresRestart: false,
        default: false,
        description: "Use OSC 52 for pasting. This may be more robust than the default system when using remote terminal sessions (if your terminal is configured to allow it).",
        showInDialog: true
      },
      useOSC52Copy: {
        type: "boolean",
        label: "Use OSC 52 Copy",
        category: "Experimental",
        requiresRestart: false,
        default: false,
        description: "Use OSC 52 for copying. This may be more robust than the default system when using remote terminal sessions (if your terminal is configured to allow it).",
        showInDialog: true
      },
      taskTracker: {
        type: "boolean",
        label: "Task Tracker",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable task tracker tools.",
        showInDialog: false
      },
      modelSteering: {
        type: "boolean",
        label: "Model Steering",
        category: "Experimental",
        requiresRestart: false,
        default: false,
        description: "Enable model steering (user hints) to guide the model during tool execution.",
        showInDialog: true
      },
      directWebFetch: {
        type: "boolean",
        label: "Direct Web Fetch",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable web fetch behavior that bypasses LLM summarization.",
        showInDialog: true
      },
      dynamicModelConfiguration: {
        type: "boolean",
        label: "Dynamic Model Configuration",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable dynamic model configuration (definitions, resolutions, and chains) via settings.",
        showInDialog: false
      },
      gemmaModelRouter: {
        type: "object",
        label: "Gemma Model Router",
        category: "Experimental",
        requiresRestart: true,
        default: {},
        description: "Enable Gemma model router (experimental).",
        showInDialog: false,
        properties: {
          enabled: {
            type: "boolean",
            label: "Enable Gemma Model Router",
            category: "Experimental",
            requiresRestart: true,
            default: false,
            description: "Enable the Gemma Model Router (experimental). Requires a local endpoint serving Gemma via the Gemini API using LiteRT-LM shim.",
            showInDialog: true
          },
          autoStartServer: {
            type: "boolean",
            label: "Auto-start LiteRT Server",
            category: "Experimental",
            requiresRestart: true,
            default: false,
            description: "Automatically start the LiteRT-LM server when Gemini CLI starts and the Gemma router is enabled.",
            showInDialog: true
          },
          binaryPath: {
            type: "string",
            label: "LiteRT Binary Path",
            category: "Experimental",
            requiresRestart: true,
            default: "",
            description: "Custom path to the LiteRT-LM binary. Leave empty to use the default location (~/.gemini/bin/litert/).",
            showInDialog: false
          },
          classifier: {
            type: "object",
            label: "Classifier",
            category: "Experimental",
            requiresRestart: true,
            default: {},
            description: "Classifier configuration.",
            showInDialog: false,
            properties: {
              host: {
                type: "string",
                label: "Host",
                category: "Experimental",
                requiresRestart: true,
                default: "http://localhost:9379",
                description: "The host of the classifier.",
                showInDialog: false
              },
              model: {
                type: "string",
                label: "Model",
                category: "Experimental",
                requiresRestart: true,
                default: "gemma3-1b-gpu-custom",
                description: "The model to use for the classifier. Only tested on `gemma3-1b-gpu-custom`.",
                showInDialog: false
              }
            }
          }
        }
      },
      stressTestProfile: {
        type: "boolean",
        label: "Use the stress test profile to aggressively trigger context management.",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Significantly lowers token limits to force early garbage collection and distillation for testing purposes.",
        showInDialog: false
      },
      autoMemory: {
        type: "boolean",
        label: "Auto Memory",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Automatically extract memory patches and skills from past sessions in the background. Every change is written as a unified diff `.patch` file under `<projectMemoryDir>/.inbox/<kind>/` and held for review in /memory inbox; nothing is applied until you approve it.",
        showInDialog: true
      },
      generalistProfile: {
        type: "boolean",
        label: "Use the generalist profile to manage agent contexts.",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Suitable for general coding and software development tasks.",
        showInDialog: true
      },
      contextManagement: {
        type: "boolean",
        label: "Enable Context Management",
        category: "Experimental",
        requiresRestart: true,
        default: false,
        description: "Enable logic for context management.",
        showInDialog: true
      },
      topicUpdateNarration: {
        type: "boolean",
        label: "Topic & Update Narration",
        category: "Experimental",
        requiresRestart: false,
        default: false,
        description: "Deprecated: Use general.topicUpdateNarration instead.",
        showInDialog: false
      }
    }
  },
  extensions: {
    type: "object",
    label: "Extensions",
    category: "Extensions",
    requiresRestart: true,
    default: {},
    description: "Settings for extensions.",
    showInDialog: false,
    properties: {
      disabled: {
        type: "array",
        label: "Disabled Extensions",
        category: "Extensions",
        requiresRestart: true,
        default: [],
        description: "List of disabled extensions.",
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "union" /* UNION */
      },
      workspacesWithMigrationNudge: {
        type: "array",
        label: "Workspaces with Migration Nudge",
        category: "Extensions",
        requiresRestart: false,
        default: [],
        description: "List of workspaces for which the migration nudge has been shown.",
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "union" /* UNION */
      }
    }
  },
  skills: {
    type: "object",
    label: "Skills",
    category: "Advanced",
    requiresRestart: true,
    default: {},
    description: "Settings for agent skills.",
    showInDialog: false,
    properties: {
      enabled: {
        type: "boolean",
        label: "Enable Agent Skills",
        category: "Advanced",
        requiresRestart: true,
        default: true,
        description: "Enable Agent Skills.",
        showInDialog: true
      },
      disabled: {
        type: "array",
        label: "Disabled Skills",
        category: "Advanced",
        requiresRestart: true,
        default: [],
        description: "List of disabled skills.",
        showInDialog: false,
        items: { type: "string" },
        mergeStrategy: "union" /* UNION */
      }
    }
  },
  hooksConfig: {
    type: "object",
    label: "HooksConfig",
    category: "Advanced",
    requiresRestart: false,
    default: {},
    description: "Hook configurations for intercepting and customizing agent behavior.",
    showInDialog: false,
    properties: {
      enabled: {
        type: "boolean",
        label: "Enable Hooks",
        category: "Advanced",
        requiresRestart: true,
        default: true,
        description: "Canonical toggle for the hooks system. When disabled, no hooks will be executed.",
        showInDialog: true
      },
      disabled: {
        type: "array",
        label: "Disabled Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "List of hook names (commands) that should be disabled. Hooks in this list will not execute even if configured.",
        showInDialog: false,
        items: {
          type: "string",
          description: "Hook command name"
        },
        mergeStrategy: "union" /* UNION */
      },
      notifications: {
        type: "boolean",
        label: "Hook Notifications",
        category: "Advanced",
        requiresRestart: false,
        default: true,
        description: "Show visual indicators when hooks are executing.",
        showInDialog: true
      }
    }
  },
  hooks: {
    type: "object",
    label: "Hook Events",
    category: "Advanced",
    requiresRestart: false,
    default: {},
    description: "Event-specific hook configurations.",
    showInDialog: false,
    properties: {
      BeforeTool: {
        type: "array",
        label: "Before Tool Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute before tool execution. Can intercept, validate, or modify tool calls.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      AfterTool: {
        type: "array",
        label: "After Tool Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute after tool execution. Can process results, log outputs, or trigger follow-up actions.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      BeforeAgent: {
        type: "array",
        label: "Before Agent Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute before agent loop starts. Can set up context or initialize resources.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      AfterAgent: {
        type: "array",
        label: "After Agent Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute after agent loop completes. Can perform cleanup or summarize results.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      Notification: {
        type: "array",
        label: "Notification Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute on notification events (errors, warnings, info). Can log or alert on specific conditions.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      SessionStart: {
        type: "array",
        label: "Session Start Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute when a session starts. Can initialize session-specific resources or state.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      SessionEnd: {
        type: "array",
        label: "Session End Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute when a session ends. Can perform cleanup or persist session data.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      PreCompress: {
        type: "array",
        label: "Pre-Compress Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute before chat history compression. Can back up or analyze conversation before compression.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      BeforeModel: {
        type: "array",
        label: "Before Model Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute before LLM requests. Can modify prompts, inject context, or control model parameters.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      AfterModel: {
        type: "array",
        label: "After Model Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute after LLM responses. Can process outputs, extract information, or log interactions.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      },
      BeforeToolSelection: {
        type: "array",
        label: "Before Tool Selection Hooks",
        category: "Advanced",
        requiresRestart: false,
        default: [],
        description: "Hooks that execute before tool selection. Can filter or prioritize available tools dynamically.",
        showInDialog: false,
        ref: "HookDefinitionArray",
        mergeStrategy: "concat" /* CONCAT */
      }
    },
    additionalProperties: {
      type: "array",
      description: "Custom hook event arrays that contain hook definitions for user-defined events",
      mergeStrategy: "concat" /* CONCAT */
    }
  },
  contextManagement: {
    type: "object",
    label: "Context Management",
    category: "Experimental",
    requiresRestart: true,
    default: {},
    description: "Settings for agent history and tool distillation context management.",
    showInDialog: false,
    properties: {
      historyWindow: {
        type: "object",
        label: "History Window Settings",
        category: "Context Management",
        requiresRestart: true,
        default: {},
        showInDialog: false,
        properties: {
          maxTokens: {
            type: "number",
            label: "Max Tokens",
            category: "Context Management",
            requiresRestart: true,
            default: 15e4,
            description: "The number of tokens to allow before triggering compression.",
            showInDialog: false
          },
          retainedTokens: {
            type: "number",
            label: "Retained Tokens",
            category: "Context Management",
            requiresRestart: true,
            default: 4e4,
            description: "The number of tokens to always retain.",
            showInDialog: false
          }
        }
      },
      messageLimits: {
        type: "object",
        label: "Message Limits",
        category: "Context Management",
        requiresRestart: true,
        default: {},
        showInDialog: false,
        properties: {
          normalMaxTokens: {
            type: "number",
            label: "Normal Maximum Tokens",
            category: "Context Management",
            requiresRestart: true,
            default: 2500,
            description: "The target number of tokens to budget for a normal conversation turn.",
            showInDialog: false
          },
          retainedMaxTokens: {
            type: "number",
            label: "Retained Maximum Tokens",
            category: "Context Management",
            requiresRestart: true,
            default: 12e3,
            description: "The maximum number of tokens a single conversation turn can consume before truncation.",
            showInDialog: false
          },
          normalizationHeadRatio: {
            type: "number",
            label: "Normalization Head Ratio",
            category: "Context Management",
            requiresRestart: true,
            default: 0.25,
            description: "The ratio of tokens to retain from the beginning of a truncated message (0.0 to 1.0).",
            showInDialog: false
          }
        }
      },
      tools: {
        type: "object",
        label: "Context Management Tools",
        category: "Context Management",
        requiresRestart: true,
        default: {},
        showInDialog: false,
        properties: {
          distillation: {
            type: "object",
            label: "Tool Distillation",
            category: "Context Management",
            requiresRestart: true,
            default: {},
            showInDialog: false,
            properties: {
              maxOutputTokens: {
                type: "number",
                label: "Max Output Tokens",
                category: "Context Management",
                requiresRestart: true,
                default: 1e4,
                description: "Maximum tokens to show to the model when truncating large tool outputs.",
                showInDialog: false
              },
              summarizationThresholdTokens: {
                type: "number",
                label: "Tool Summarization Threshold",
                category: "Context Management",
                requiresRestart: true,
                default: 2e4,
                description: "Threshold above which truncated tool outputs will be summarized by an LLM.",
                showInDialog: false
              }
            }
          },
          outputMasking: {
            type: "object",
            label: "Tool Output Masking",
            category: "Context Management",
            requiresRestart: true,
            ignoreInDocs: false,
            default: {},
            description: "Advanced settings for tool output masking to manage context window efficiency.",
            showInDialog: false,
            properties: {
              protectionThresholdTokens: {
                type: "number",
                label: "Tool Protection Threshold (Tokens)",
                category: "Context Management",
                requiresRestart: true,
                default: 5e4,
                description: "Minimum number of tokens to protect from masking (most recent tool outputs).",
                showInDialog: false
              },
              minPrunableThresholdTokens: {
                type: "number",
                label: "Min Prunable Tokens Threshold",
                category: "Context Management",
                requiresRestart: true,
                default: 3e4,
                description: "Minimum prunable tokens required to trigger a masking pass.",
                showInDialog: false
              },
              protectLatestTurn: {
                type: "boolean",
                label: "Protect Latest Turn",
                category: "Context Management",
                requiresRestart: true,
                default: true,
                description: "Ensures the absolute latest turn is never masked, regardless of token count.",
                showInDialog: false
              }
            }
          }
        }
      }
    }
  },
  admin: {
    type: "object",
    label: "Admin",
    category: "Admin",
    requiresRestart: false,
    default: {},
    description: "Settings configured remotely by enterprise admins.",
    showInDialog: false,
    mergeStrategy: "replace" /* REPLACE */,
    properties: {
      secureModeEnabled: {
        type: "boolean",
        label: "Secure Mode Enabled",
        category: "Admin",
        requiresRestart: false,
        default: false,
        description: 'If true, disallows YOLO mode and "Always allow" options from being used.',
        showInDialog: false,
        mergeStrategy: "replace" /* REPLACE */
      },
      extensions: {
        type: "object",
        label: "Extensions Settings",
        category: "Admin",
        requiresRestart: false,
        default: {},
        description: "Extensions-specific admin settings.",
        showInDialog: false,
        mergeStrategy: "replace" /* REPLACE */,
        properties: {
          enabled: {
            type: "boolean",
            label: "Extensions Enabled",
            category: "Admin",
            requiresRestart: false,
            default: true,
            description: "If false, disallows extensions from being installed or used.",
            showInDialog: false,
            mergeStrategy: "replace" /* REPLACE */
          }
        }
      },
      mcp: {
        type: "object",
        label: "MCP Settings",
        category: "Admin",
        requiresRestart: false,
        default: {},
        description: "MCP-specific admin settings.",
        showInDialog: false,
        mergeStrategy: "replace" /* REPLACE */,
        properties: {
          enabled: {
            type: "boolean",
            label: "MCP Enabled",
            category: "Admin",
            requiresRestart: false,
            default: true,
            description: "If false, disallows MCP servers from being used.",
            showInDialog: false,
            mergeStrategy: "replace" /* REPLACE */
          },
          config: {
            type: "object",
            label: "MCP Config",
            category: "Admin",
            requiresRestart: false,
            default: {},
            description: "Admin-configured MCP servers (allowlist).",
            showInDialog: false,
            mergeStrategy: "replace" /* REPLACE */,
            additionalProperties: {
              type: "object",
              ref: "MCPServerConfig"
            }
          },
          requiredConfig: {
            type: "object",
            label: "Required MCP Config",
            category: "Admin",
            requiresRestart: false,
            default: {},
            description: "Admin-required MCP servers that are always injected.",
            showInDialog: false,
            mergeStrategy: "replace" /* REPLACE */,
            additionalProperties: {
              type: "object",
              ref: "RequiredMcpServerConfig"
            }
          }
        }
      },
      skills: {
        type: "object",
        label: "Skills Settings",
        category: "Admin",
        requiresRestart: false,
        default: {},
        description: "Agent Skills-specific admin settings.",
        showInDialog: false,
        mergeStrategy: "replace" /* REPLACE */,
        properties: {
          enabled: {
            type: "boolean",
            label: "Skills Enabled",
            category: "Admin",
            requiresRestart: false,
            default: true,
            description: "If false, disallows agent skills from being used.",
            showInDialog: false,
            mergeStrategy: "replace" /* REPLACE */
          }
        }
      }
    }
  }
};
var SETTINGS_SCHEMA_DEFINITIONS = {
  MCPServerConfig: {
    type: "object",
    description: "Definition of a Model Context Protocol (MCP) server configuration.",
    additionalProperties: false,
    properties: {
      command: {
        type: "string",
        description: "Executable invoked for stdio transport."
      },
      args: {
        type: "array",
        description: "Command-line arguments for the stdio transport command.",
        items: { type: "string" }
      },
      env: {
        type: "object",
        description: "Environment variables to set for the server process.",
        additionalProperties: { type: "string" }
      },
      cwd: {
        type: "string",
        description: "Working directory for the server process."
      },
      url: {
        type: "string",
        description: 'URL for SSE or HTTP transport. Use with "type" field to specify transport type.'
      },
      httpUrl: {
        type: "string",
        description: "Streaming HTTP transport URL."
      },
      headers: {
        type: "object",
        description: "Additional HTTP headers sent to the server.",
        additionalProperties: { type: "string" }
      },
      tcp: {
        type: "string",
        description: "TCP address for websocket transport."
      },
      type: {
        type: "string",
        description: 'Transport type. Use "stdio" for local command, "sse" for Server-Sent Events, or "http" for Streamable HTTP.',
        enum: ["stdio", "sse", "http"]
      },
      timeout: {
        type: "number",
        description: "Timeout in milliseconds for MCP requests."
      },
      trust: {
        type: "boolean",
        description: "Marks the server as trusted. Trusted servers may gain additional capabilities."
      },
      description: {
        type: "string",
        description: "Human-readable description of the server."
      },
      includeTools: {
        type: "array",
        description: "Subset of tools that should be enabled for this server. When omitted all tools are enabled.",
        items: { type: "string" }
      },
      excludeTools: {
        type: "array",
        description: "Tools that should be disabled for this server even if exposed.",
        items: { type: "string" }
      },
      extension: {
        type: "object",
        description: "Metadata describing the Gemini CLI extension that owns this MCP server.",
        additionalProperties: { type: ["string", "boolean", "number"] }
      },
      oauth: {
        type: "object",
        description: "OAuth configuration for authenticating with the server.",
        additionalProperties: true
      },
      authProviderType: {
        type: "string",
        description: "Authentication provider used for acquiring credentials (for example `dynamic_discovery`).",
        enum: Object.values(AuthProviderType)
      },
      targetAudience: {
        type: "string",
        description: "OAuth target audience (CLIENT_ID.apps.googleusercontent.com)."
      },
      targetServiceAccount: {
        type: "string",
        description: "Service account email to impersonate (name@project.iam.gserviceaccount.com)."
      }
    }
  },
  RequiredMcpServerConfig: {
    type: "object",
    description: "Admin-required MCP server configuration (remote transports only).",
    additionalProperties: false,
    properties: {
      url: {
        type: "string",
        description: "URL for the required MCP server."
      },
      type: {
        type: "string",
        description: "Transport type for the required server.",
        enum: ["sse", "http"]
      },
      headers: {
        type: "object",
        description: "Additional HTTP headers sent to the server.",
        additionalProperties: { type: "string" }
      },
      timeout: {
        type: "number",
        description: "Timeout in milliseconds for MCP requests."
      },
      trust: {
        type: "boolean",
        description: "Marks the server as trusted. Defaults to true for admin-required servers."
      },
      description: {
        type: "string",
        description: "Human-readable description of the server."
      },
      includeTools: {
        type: "array",
        description: "Subset of tools enabled for this server.",
        items: { type: "string" }
      },
      excludeTools: {
        type: "array",
        description: "Tools disabled for this server.",
        items: { type: "string" }
      },
      oauth: {
        type: "object",
        description: "OAuth configuration for authenticating with the server.",
        additionalProperties: true
      },
      authProviderType: {
        type: "string",
        description: "Authentication provider used for acquiring credentials.",
        enum: Object.values(AuthProviderType)
      },
      targetAudience: {
        type: "string",
        description: "OAuth target audience (CLIENT_ID.apps.googleusercontent.com)."
      },
      targetServiceAccount: {
        type: "string",
        description: "Service account email to impersonate (name@project.iam.gserviceaccount.com)."
      }
    }
  },
  TelemetrySettings: {
    type: "object",
    description: "Telemetry configuration for Gemini CLI.",
    additionalProperties: false,
    properties: {
      enabled: {
        type: "boolean",
        description: "Enables telemetry emission."
      },
      target: {
        type: "string",
        description: "Telemetry destination (for example `stderr`, `stdout`, or `otlp`)."
      },
      otlpEndpoint: {
        type: "string",
        description: "Endpoint for OTLP exporters."
      },
      otlpProtocol: {
        type: "string",
        description: "Protocol for OTLP exporters.",
        enum: ["grpc", "http"]
      },
      traces: {
        type: "boolean",
        description: "Whether detailed traces with large attributes are captured."
      },
      logPrompts: {
        type: "boolean",
        description: "Whether prompts are logged in telemetry payloads."
      },
      outfile: {
        type: "string",
        description: "File path for writing telemetry output."
      },
      useCollector: {
        type: "boolean",
        description: "Whether to forward telemetry to an OTLP collector."
      },
      useCliAuth: {
        type: "boolean",
        description: "Whether to use CLI authentication for telemetry (only for in-process exporters)."
      }
    }
  },
  BugCommandSettings: {
    type: "object",
    description: "Configuration for the bug report helper command.",
    additionalProperties: false,
    properties: {
      urlTemplate: {
        type: "string",
        description: "Template used to open a bug report URL. Variables in the template are populated at runtime."
      }
    },
    required: ["urlTemplate"]
  },
  SummarizeToolOutputSettings: {
    type: "object",
    description: "Controls summarization behavior for individual tools. All properties are optional.",
    additionalProperties: false,
    properties: {
      tokenBudget: {
        type: "number",
        description: "Maximum number of tokens used when summarizing tool output."
      }
    }
  },
  AgentOverride: {
    type: "object",
    description: "Override settings for a specific agent.",
    additionalProperties: false,
    properties: {
      modelConfig: {
        type: "object",
        additionalProperties: true
      },
      runConfig: {
        type: "object",
        description: "Run configuration for an agent.",
        additionalProperties: false,
        properties: {
          maxTimeMinutes: {
            type: "number",
            description: "The maximum execution time for the agent in minutes."
          },
          maxTurns: {
            type: "number",
            description: "The maximum number of conversational turns."
          }
        }
      },
      enabled: {
        type: "boolean",
        description: "Whether to enable the agent."
      }
    }
  },
  CustomTheme: {
    type: "object",
    description: "Custom theme definition used for styling Gemini CLI output. Colors are provided as hex strings or named ANSI colors.",
    additionalProperties: false,
    properties: {
      type: {
        type: "string",
        enum: ["custom"],
        default: "custom"
      },
      name: {
        type: "string",
        description: "Theme display name."
      },
      text: {
        type: "object",
        additionalProperties: false,
        properties: {
          primary: { type: "string" },
          secondary: { type: "string" },
          link: { type: "string" },
          accent: { type: "string" },
          response: { type: "string" }
        }
      },
      background: {
        type: "object",
        additionalProperties: false,
        properties: {
          primary: { type: "string" },
          diff: {
            type: "object",
            additionalProperties: false,
            properties: {
              added: { type: "string" },
              removed: { type: "string" }
            }
          }
        }
      },
      border: {
        type: "object",
        additionalProperties: false,
        properties: {
          default: { type: "string" },
          focused: { type: "string" }
        }
      },
      ui: {
        type: "object",
        additionalProperties: false,
        properties: {
          comment: { type: "string" },
          symbol: { type: "string" },
          gradient: {
            type: "array",
            items: { type: "string" }
          }
        }
      },
      status: {
        type: "object",
        additionalProperties: false,
        properties: {
          error: { type: "string" },
          success: { type: "string" },
          warning: { type: "string" }
        }
      },
      Background: { type: "string" },
      Foreground: { type: "string" },
      LightBlue: { type: "string" },
      AccentBlue: { type: "string" },
      AccentPurple: { type: "string" },
      AccentCyan: { type: "string" },
      AccentGreen: { type: "string" },
      AccentYellow: { type: "string" },
      AccentRed: { type: "string" },
      DiffAdded: { type: "string" },
      DiffRemoved: { type: "string" },
      Comment: { type: "string" },
      Gray: { type: "string" },
      DarkGray: { type: "string" },
      GradientColors: {
        type: "array",
        items: { type: "string" }
      }
    },
    required: ["type", "name"]
  },
  StringOrStringArray: {
    description: "Accepts either a single string or an array of strings.",
    anyOf: [{ type: "string" }, { type: "array", items: { type: "string" } }]
  },
  BooleanOrStringOrObject: {
    description: "Accepts either a boolean flag, a string command name, or a configuration object.",
    anyOf: [
      { type: "boolean" },
      { type: "string" },
      {
        type: "object",
        description: "Sandbox configuration object.",
        additionalProperties: false,
        properties: {
          enabled: {
            type: "boolean",
            description: "Enables or disables the sandbox."
          },
          command: {
            type: "string",
            description: "The sandbox command to use (docker, podman, sandbox-exec, runsc, lxc).",
            enum: ["docker", "podman", "sandbox-exec", "runsc", "lxc"]
          },
          image: {
            type: "string",
            description: "The sandbox image to use."
          },
          allowedPaths: {
            type: "array",
            description: "A list of absolute host paths that should be accessible within the sandbox.",
            items: { type: "string" }
          },
          networkAccess: {
            type: "boolean",
            description: "Whether the sandbox should have internet access."
          }
        }
      }
    ]
  },
  HookDefinitionArray: {
    type: "array",
    description: "Array of hook definition objects for a specific event.",
    items: {
      type: "object",
      description: "Hook definition specifying matcher pattern and hook configurations.",
      properties: {
        matcher: {
          type: "string",
          description: "Pattern to match against the event context (tool name, notification type, etc.). Supports exact match, regex (/pattern/), and wildcards (*)."
        },
        hooks: {
          type: "array",
          description: "Hooks to execute when the matcher matches.",
          items: {
            type: "object",
            description: "Individual hook configuration.",
            properties: {
              name: {
                type: "string",
                description: "Unique identifier for the hook."
              },
              type: {
                type: "string",
                description: 'Type of hook (currently only "command" supported).'
              },
              command: {
                type: "string",
                description: "Shell command to execute. Receives JSON input via stdin and returns JSON output via stdout."
              },
              description: {
                type: "string",
                description: "A description of the hook."
              },
              timeout: {
                type: "number",
                description: "Timeout in milliseconds for hook execution."
              }
            }
          }
        }
      }
    }
  },
  ModelDefinition: {
    type: "object",
    description: "Model metadata registry entry.",
    properties: {
      displayName: { type: "string" },
      tier: { enum: ["pro", "flash", "flash-lite", "custom", "auto"] },
      family: { type: "string" },
      isPreview: { type: "boolean" },
      isVisible: { type: "boolean" },
      dialogDescription: {
        type: "string",
        description: "A description of the model to display in the model selection dialog. For the 'auto' alias, this value is dynamically generated and any value provided here will be ignored."
      },
      features: {
        type: "object",
        properties: {
          thinking: { type: "boolean" },
          multimodalToolUse: { type: "boolean" }
        }
      }
    }
  },
  ModelResolution: {
    type: "object",
    description: "Model resolution rule.",
    properties: {
      default: { type: "string" },
      contexts: {
        type: "array",
        items: {
          type: "object",
          properties: {
            condition: {
              type: "object",
              properties: {
                useGemini3_1: { type: "boolean" },
                useGemini3_1FlashLite: { type: "boolean" },
                useCustomTools: { type: "boolean" },
                hasAccessToPreview: { type: "boolean" },
                requestedModels: {
                  type: "array",
                  items: { type: "string" }
                }
              }
            },
            target: { type: "string" }
          }
        }
      }
    }
  },
  ModelPolicyChain: {
    type: "array",
    description: "A chain of model policies for fallback behavior.",
    items: {
      type: "object",
      ref: "ModelPolicy"
    }
  },
  ModelPolicy: {
    type: "object",
    description: "Defines the policy for a single model in the availability chain.",
    properties: {
      model: { type: "string" },
      isLastResort: { type: "boolean" },
      actions: {
        type: "object",
        properties: {
          terminal: { type: "string", enum: ["silent", "prompt"] },
          transient: { type: "string", enum: ["silent", "prompt"] },
          not_found: { type: "string", enum: ["silent", "prompt"] },
          unknown: { type: "string", enum: ["silent", "prompt"] }
        }
      },
      stateTransitions: {
        type: "object",
        properties: {
          terminal: { type: "string", enum: ["terminal", "sticky_retry"] },
          transient: { type: "string", enum: ["terminal", "sticky_retry"] },
          not_found: { type: "string", enum: ["terminal", "sticky_retry"] },
          unknown: { type: "string", enum: ["terminal", "sticky_retry"] }
        }
      }
    },
    required: ["model"]
  }
};
function getSettingsSchema() {
  return SETTINGS_SCHEMA;
}

// packages/cli/src/utils/envVarResolver.ts
function resolveEnvVarsInString(value, customEnv) {
  const envVarRegex = /\$(?:(\w+)|{([^}]+?)(?::-([^}]*))?})/g;
  return value.replace(
    envVarRegex,
    (match, varName1, varName2, defaultValue) => {
      const varName = varName1 || varName2 || "";
      if (!varName) {
        return match;
      }
      if (customEnv && typeof customEnv[varName] === "string") {
        return customEnv[varName];
      }
      if (process && process.env && typeof process.env[varName] === "string") {
        return process.env[varName];
      }
      if (defaultValue !== void 0) {
        return defaultValue;
      }
      return match;
    }
  );
}
function resolveEnvVarsInObject(obj, customEnv) {
  return resolveEnvVarsInObjectInternal(obj, /* @__PURE__ */ new WeakSet(), customEnv);
}
function resolveEnvVarsInObjectInternal(obj, visited, customEnv) {
  if (obj === null || obj === void 0 || typeof obj === "boolean" || typeof obj === "number") {
    return obj;
  }
  if (typeof obj === "string") {
    return resolveEnvVarsInString(obj, customEnv);
  }
  if (Array.isArray(obj)) {
    if (visited.has(obj)) {
      const copy = [...obj];
      const isTArray2 = (val) => Array.isArray(val);
      if (isTArray2(copy)) return copy;
      throw new Error("Unreachable");
    }
    visited.add(obj);
    const mapped = obj.map(
      (item) => resolveEnvVarsInObjectInternal(item, visited, customEnv)
    );
    visited.delete(obj);
    const isTArray = (val) => Array.isArray(val);
    if (isTArray(mapped)) return mapped;
    throw new Error("Unreachable");
  }
  if (typeof obj === "object") {
    if (visited.has(obj)) {
      return { ...obj };
    }
    visited.add(obj);
    const newObj = { ...obj };
    for (const key in newObj) {
      if (Object.prototype.hasOwnProperty.call(newObj, key)) {
        newObj[key] = resolveEnvVarsInObjectInternal(
          newObj[key],
          visited,
          customEnv
        );
      }
    }
    visited.delete(obj);
    return newObj;
  }
  return obj;
}

// packages/cli/src/utils/deepMerge.ts
function isPlainObject(item) {
  return !!item && typeof item === "object" && !Array.isArray(item);
}
function mergeRecursively(target, source, getMergeStrategyForPath2, path6 = []) {
  for (const key of Object.keys(source)) {
    if (key === "__proto__" || key === "constructor" || key === "prototype") {
      continue;
    }
    const srcValue = source[key];
    if (srcValue === void 0) {
      continue;
    }
    const newPath = [...path6, key];
    const objValue = target[key];
    const mergeStrategy = getMergeStrategyForPath2(newPath);
    if (mergeStrategy === "shallow_merge" /* SHALLOW_MERGE */ && objValue && srcValue) {
      const obj1 = typeof objValue === "object" && objValue !== null ? objValue : {};
      const obj2 = typeof srcValue === "object" && srcValue !== null ? srcValue : {};
      target[key] = { ...obj1, ...obj2 };
      continue;
    }
    if (Array.isArray(objValue)) {
      const srcArray = Array.isArray(srcValue) ? srcValue : [srcValue];
      if (mergeStrategy === "concat" /* CONCAT */) {
        target[key] = objValue.concat(srcArray);
        continue;
      }
      if (mergeStrategy === "union" /* UNION */) {
        target[key] = [...new Set(objValue.concat(srcArray))];
        continue;
      }
    }
    if (isPlainObject(objValue) && isPlainObject(srcValue)) {
      mergeRecursively(objValue, srcValue, getMergeStrategyForPath2, newPath);
    } else if (isPlainObject(srcValue)) {
      target[key] = {};
      mergeRecursively(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        target[key],
        srcValue,
        getMergeStrategyForPath2,
        newPath
      );
    } else {
      target[key] = srcValue;
    }
  }
  return target;
}
function customDeepMerge(getMergeStrategyForPath2, ...sources) {
  const result = {};
  for (const source of sources) {
    if (source) {
      mergeRecursively(result, source, getMergeStrategyForPath2);
    }
  }
  return result;
}

// packages/cli/src/utils/commentJson.ts
var import_comment_json = __toESM(require_src2(), 1);
import * as fs3 from "node:fs";
function updateSettingsFilePreservingFormat(filePath, updates) {
  if (!fs3.existsSync(filePath)) {
    fs3.writeFileSync(filePath, JSON.stringify(updates, null, 2), "utf-8");
    return;
  }
  const originalContent = fs3.readFileSync(filePath, "utf-8");
  let parsed;
  try {
    parsed = (0, import_comment_json.parse)(originalContent);
  } catch (error) {
    coreEvents.emitFeedback(
      "error",
      "Error parsing settings file. Please check the JSON syntax.",
      error
    );
    return;
  }
  const updatedStructure = applyUpdates(parsed, updates);
  const updatedContent = (0, import_comment_json.stringify)(updatedStructure, null, 2);
  fs3.writeFileSync(filePath, updatedContent, "utf-8");
}
function preserveCommentsOnPropertyDeletion(container, propName) {
  const target = container;
  const beforeSym = Symbol.for(`before:${propName}`);
  const afterSym = Symbol.for(`after:${propName}`);
  const beforeComments = target[beforeSym];
  const afterComments = target[afterSym];
  if (!beforeComments && !afterComments) return;
  const keys = Object.getOwnPropertyNames(container);
  const idx = keys.indexOf(propName);
  const nextKey = idx >= 0 && idx + 1 < keys.length ? keys[idx + 1] : void 0;
  const prevKey = idx > 0 ? keys[idx - 1] : void 0;
  function appendToSymbol(destSym, comments) {
    if (!comments || comments.length === 0) return;
    const existing = target[destSym];
    target[destSym] = Array.isArray(existing) ? existing.concat(comments) : comments;
  }
  if (beforeComments && beforeComments.length > 0) {
    if (nextKey) {
      appendToSymbol(Symbol.for(`before:${nextKey}`), beforeComments);
    } else if (prevKey) {
      appendToSymbol(Symbol.for(`after:${prevKey}`), beforeComments);
    } else {
      appendToSymbol(Symbol.for("before"), beforeComments);
    }
    delete target[beforeSym];
  }
  if (afterComments && afterComments.length > 0) {
    if (nextKey) {
      appendToSymbol(Symbol.for(`before:${nextKey}`), afterComments);
    } else if (prevKey) {
      appendToSymbol(Symbol.for(`after:${prevKey}`), afterComments);
    } else {
      appendToSymbol(Symbol.for("after"), afterComments);
    }
    delete target[afterSym];
  }
}
function applyKeyDiff(base, desired) {
  for (const existingKey of Object.getOwnPropertyNames(base)) {
    if (!Object.prototype.hasOwnProperty.call(desired, existingKey)) {
      preserveCommentsOnPropertyDeletion(base, existingKey);
      delete base[existingKey];
    }
  }
  for (const nextKey of Object.getOwnPropertyNames(desired)) {
    const nextVal = desired[nextKey];
    const baseVal = base[nextKey];
    const isObj = typeof nextVal === "object" && nextVal !== null && !Array.isArray(nextVal);
    const isBaseObj = typeof baseVal === "object" && baseVal !== null && !Array.isArray(baseVal);
    const isArr = Array.isArray(nextVal);
    const isBaseArr = Array.isArray(baseVal);
    if (isObj && isBaseObj) {
      applyKeyDiff(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        baseVal,
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        nextVal
      );
    } else if (isArr && isBaseArr) {
      const baseArr = baseVal;
      const desiredArr = nextVal;
      baseArr.length = 0;
      for (const el of desiredArr) {
        baseArr.push(el);
      }
    } else {
      base[nextKey] = nextVal;
    }
  }
}
function applyUpdates(current, updates) {
  applyKeyDiff(current, updates);
  return current;
}

// packages/cli/src/config/settings-validation.ts
function buildZodSchemaFromJsonSchema(def) {
  if (def.anyOf) {
    return external_exports.union(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      def.anyOf.map((d) => buildZodSchemaFromJsonSchema(d))
    );
  }
  if (def.type === "string") {
    if (def.enum) return external_exports.enum(def.enum);
    return buildPrimitiveSchema("string");
  }
  if (def.type === "number") return buildPrimitiveSchema("number");
  if (def.type === "boolean") return buildPrimitiveSchema("boolean");
  if (def.type === "array") {
    if (def.items) {
      return external_exports.array(buildZodSchemaFromJsonSchema(def.items));
    }
    return external_exports.array(external_exports.unknown());
  }
  if (def.type === "object") {
    let schema;
    if (def.properties) {
      const shape = {};
      for (const [key, propDef] of Object.entries(def.properties)) {
        let propSchema = buildZodSchemaFromJsonSchema(propDef);
        if (def.required && Array.isArray(def.required) && def.required.includes(key)) {
        } else {
          propSchema = propSchema.optional();
        }
        shape[key] = propSchema;
      }
      schema = external_exports.object(shape).passthrough();
    } else {
      schema = external_exports.object({}).passthrough();
    }
    if (def.additionalProperties === false) {
      schema = schema.strict();
    } else if (typeof def.additionalProperties === "object") {
      schema = schema.catchall(
        buildZodSchemaFromJsonSchema(def.additionalProperties)
      );
    }
    return schema;
  }
  return external_exports.unknown();
}
function buildEnumSchema(options) {
  if (!options || options.length === 0) {
    throw new Error(
      `Enum type must have options defined. Check your settings schema definition.`
    );
  }
  const values = options.map((opt) => opt.value);
  if (values.every((v) => typeof v === "string")) {
    return external_exports.enum(values);
  } else if (values.every((v) => typeof v === "number")) {
    return external_exports.union(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      values.map((v) => external_exports.literal(v))
    );
  } else {
    return external_exports.union(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      values.map((v) => external_exports.literal(v))
    );
  }
}
function buildObjectShapeFromProperties(properties) {
  const shape = {};
  for (const [key, childDef] of Object.entries(properties)) {
    shape[key] = buildZodSchemaFromDefinition(childDef);
  }
  return shape;
}
function buildPrimitiveSchema(type) {
  switch (type) {
    case "string":
      return external_exports.string();
    case "number":
      return external_exports.preprocess((val) => {
        if (typeof val === "string" && val.trim() !== "") {
          const num = Number(val);
          if (!isNaN(num)) return num;
        }
        return val;
      }, external_exports.number());
    case "boolean":
      return external_exports.preprocess((val) => {
        if (typeof val === "string") {
          const lower = val.toLowerCase();
          if (lower === "true") return true;
          if (lower === "false") return false;
        }
        return val;
      }, external_exports.boolean());
    default:
      return external_exports.unknown();
  }
}
var REF_SCHEMAS = {};
for (const [name, def] of Object.entries(SETTINGS_SCHEMA_DEFINITIONS)) {
  REF_SCHEMAS[name] = buildZodSchemaFromJsonSchema(def);
}
function buildZodSchemaFromDefinition(definition) {
  let baseSchema;
  if (definition.ref === "TelemetrySettings") {
    const objectSchema = REF_SCHEMAS["TelemetrySettings"];
    if (objectSchema) {
      return external_exports.union([buildPrimitiveSchema("boolean"), objectSchema]).optional();
    }
  }
  if (definition.ref && definition.ref in REF_SCHEMAS) {
    return REF_SCHEMAS[definition.ref].optional();
  }
  switch (definition.type) {
    case "string":
    case "number":
    case "boolean":
      baseSchema = buildPrimitiveSchema(definition.type);
      break;
    case "enum": {
      baseSchema = buildEnumSchema(definition.options);
      break;
    }
    case "array":
      if (definition.items) {
        const itemSchema = buildZodSchemaFromCollection(definition.items);
        baseSchema = external_exports.array(itemSchema);
      } else {
        baseSchema = external_exports.array(external_exports.unknown());
      }
      break;
    case "object":
      if (definition.properties) {
        const shape = buildObjectShapeFromProperties(definition.properties);
        baseSchema = external_exports.object(shape).passthrough();
        if (definition.additionalProperties) {
          const additionalSchema = buildZodSchemaFromCollection(
            definition.additionalProperties
          );
          baseSchema = external_exports.object(shape).catchall(additionalSchema);
        }
      } else if (definition.additionalProperties) {
        const valueSchema = buildZodSchemaFromCollection(
          definition.additionalProperties
        );
        baseSchema = external_exports.record(external_exports.string(), valueSchema);
      } else {
        baseSchema = external_exports.record(external_exports.string(), external_exports.unknown());
      }
      break;
    default:
      baseSchema = external_exports.unknown();
  }
  return baseSchema.optional();
}
function buildZodSchemaFromCollection(collection) {
  if (collection.ref && collection.ref in REF_SCHEMAS) {
    return REF_SCHEMAS[collection.ref];
  }
  switch (collection.type) {
    case "string":
    case "number":
    case "boolean":
      return buildPrimitiveSchema(collection.type);
    case "enum": {
      return buildEnumSchema(collection.options);
    }
    case "array":
      if (collection.properties) {
        const shape = buildObjectShapeFromProperties(collection.properties);
        return external_exports.array(external_exports.object(shape));
      }
      return external_exports.array(external_exports.unknown());
    case "object":
      if (collection.properties) {
        const shape = buildObjectShapeFromProperties(collection.properties);
        return external_exports.object(shape).passthrough();
      }
      return external_exports.record(external_exports.string(), external_exports.unknown());
    default:
      return external_exports.unknown();
  }
}
function buildSettingsZodSchema() {
  const schema = getSettingsSchema();
  const shape = {};
  for (const [key, definition] of Object.entries(schema)) {
    shape[key] = buildZodSchemaFromDefinition(definition);
  }
  return external_exports.object(shape).passthrough();
}
var settingsZodSchema = buildSettingsZodSchema();
function validateSettings(data) {
  const result = settingsZodSchema.safeParse(data);
  return result;
}
function formatValidationError(error, filePath) {
  const lines = [];
  lines.push(`Invalid configuration in ${filePath}:`);
  lines.push("");
  const MAX_ERRORS_TO_DISPLAY = 5;
  const displayedIssues = error.issues.slice(0, MAX_ERRORS_TO_DISPLAY);
  for (const issue of displayedIssues) {
    const path6 = issue.path.reduce(
      (acc, curr) => typeof curr === "number" ? `${acc}[${curr}]` : `${acc ? acc + "." : ""}${curr}`,
      ""
    );
    lines.push(`Error in: ${path6 || "(root)"}`);
    lines.push(`    ${issue.message}`);
    if (issue.code === "invalid_type") {
      const expected = issue.expected;
      const received = issue.received;
      lines.push(`Expected: ${expected}, but received: ${received}`);
    }
    lines.push("");
  }
  if (error.issues.length > MAX_ERRORS_TO_DISPLAY) {
    lines.push(
      `...and ${error.issues.length - MAX_ERRORS_TO_DISPLAY} more errors.`
    );
    lines.push("");
  }
  lines.push("Please fix the configuration.");
  lines.push("See: https://geminicli.com/docs/reference/configuration/");
  return lines.join("\n");
}

// packages/cli/src/config/settings.ts
function getMergeStrategyForPath(path6) {
  let current = void 0;
  let currentSchema = getSettingsSchema();
  let parent = void 0;
  for (const key of path6) {
    if (!currentSchema || !currentSchema[key]) {
      if (parent?.additionalProperties?.mergeStrategy) {
        return parent.additionalProperties.mergeStrategy;
      }
      return void 0;
    }
    parent = current;
    current = currentSchema[key];
    currentSchema = current.properties;
  }
  return current?.mergeStrategy;
}
var USER_SETTINGS_PATH = Storage.getGlobalSettingsPath();
var USER_SETTINGS_DIR = path3.dirname(USER_SETTINGS_PATH);
var DEFAULT_EXCLUDED_ENV_VARS = [
  "DEBUG",
  "DEBUG_MODE",
  "GEMINI_CLI_IDE_SERVER_STDIO_COMMAND",
  "GEMINI_CLI_IDE_SERVER_STDIO_ARGS"
];
var AUTH_ENV_VAR_WHITELIST = [
  "GEMINI_API_KEY",
  "GOOGLE_API_KEY",
  "GOOGLE_CLOUD_PROJECT",
  "GOOGLE_CLOUD_LOCATION"
];
function sanitizeEnvVar(value) {
  return value.replace(/[^a-zA-Z0-9\-_./]/g, "");
}
function getSystemSettingsPath() {
  if (process2.env["GEMINI_CLI_SYSTEM_SETTINGS_PATH"]) {
    return process2.env["GEMINI_CLI_SYSTEM_SETTINGS_PATH"];
  }
  if (platform() === "darwin") {
    return "/Library/Application Support/GeminiCli/settings.json";
  } else if (platform() === "win32") {
    return "C:\\ProgramData\\gemini-cli\\settings.json";
  } else {
    return "/etc/gemini-cli/settings.json";
  }
}
function getSystemDefaultsPath() {
  if (process2.env["GEMINI_CLI_SYSTEM_DEFAULTS_PATH"]) {
    return process2.env["GEMINI_CLI_SYSTEM_DEFAULTS_PATH"];
  }
  return path3.join(
    path3.dirname(getSystemSettingsPath()),
    "system-defaults.json"
  );
}
var SettingScope = /* @__PURE__ */ ((SettingScope2) => {
  SettingScope2["User"] = "User";
  SettingScope2["Workspace"] = "Workspace";
  SettingScope2["System"] = "System";
  SettingScope2["SystemDefaults"] = "SystemDefaults";
  SettingScope2["Session"] = "Session";
  return SettingScope2;
})(SettingScope || {});
var _loadableSettingScopes = [
  "User" /* User */,
  "Workspace" /* Workspace */,
  "System" /* System */,
  "SystemDefaults" /* SystemDefaults */
];
function isLoadableSettingScope(scope) {
  return _loadableSettingScopes.includes(scope);
}
function setNestedProperty(obj, path6, value) {
  const keys = path6.split(".");
  const lastKey = keys.pop();
  if (!lastKey) return;
  let current = obj;
  for (const key of keys) {
    if (current[key] === void 0) {
      current[key] = {};
    }
    const next = current[key];
    if (typeof next === "object" && next !== null) {
      current = next;
    } else {
      return;
    }
  }
  current[lastKey] = value;
}
function getDefaultsFromSchema(schema = getSettingsSchema()) {
  const defaults = {};
  for (const key in schema) {
    const definition = schema[key];
    if (definition.properties) {
      defaults[key] = getDefaultsFromSchema(definition.properties);
    } else if (definition.default !== void 0) {
      defaults[key] = definition.default;
    }
  }
  return defaults;
}
function mergeSettings(system, systemDefaults, user, workspace, isTrusted) {
  const safeWorkspace = isTrusted ? workspace : {};
  const schemaDefaults = getDefaultsFromSchema();
  return customDeepMerge(
    getMergeStrategyForPath,
    schemaDefaults,
    systemDefaults,
    user,
    safeWorkspace,
    system
  );
}
var LoadedSettings = class {
  constructor(system, systemDefaults, user, workspace, isTrusted, errors = []) {
    this.system = system;
    this.systemDefaults = systemDefaults;
    this.user = user;
    this._workspaceFile = workspace;
    this.isTrusted = isTrusted;
    this.workspace = isTrusted ? workspace : this.createEmptyWorkspace(workspace);
    this.errors = errors;
    this._merged = this.computeMergedSettings();
    this._snapshot = this.computeSnapshot();
  }
  system;
  systemDefaults;
  user;
  workspace;
  isTrusted;
  errors;
  _workspaceFile;
  _merged;
  _snapshot;
  _remoteAdminSettings;
  get merged() {
    return this._merged;
  }
  /**
   * Returns a merged settings object as if the folder were trusted.
   * This is useful for commands like 'mcp list' that want to show
   * what's configured even if it's currently disabled for security reasons.
   */
  getMergedSettingsAsIfTrusted() {
    return this.computeMergedSettings(true);
  }
  setTrusted(isTrusted) {
    if (this.isTrusted === isTrusted) {
      return;
    }
    this.isTrusted = isTrusted;
    this.workspace = isTrusted ? this._workspaceFile : this.createEmptyWorkspace(this._workspaceFile);
    this._merged = this.computeMergedSettings();
    coreEvents.emitSettingsChanged();
  }
  createEmptyWorkspace(workspace) {
    return {
      ...workspace,
      settings: {},
      originalSettings: {}
    };
  }
  computeMergedSettings(forceTrusted = false) {
    const isTrusted = forceTrusted || this.isTrusted;
    const workspace = forceTrusted ? this._workspaceFile : this.workspace;
    const merged = mergeSettings(
      this.system.settings,
      this.systemDefaults.settings,
      this.user.settings,
      workspace.settings,
      isTrusted
    );
    const adminSettingSchema = getSettingsSchema().admin;
    if (adminSettingSchema?.properties) {
      const adminSchema = adminSettingSchema.properties;
      const adminDefaults = getDefaultsFromSchema(adminSchema);
      merged.admin = customDeepMerge(
        (path6) => getMergeStrategyForPath(["admin", ...path6]),
        adminDefaults,
        this._remoteAdminSettings?.admin ?? {}
      );
    }
    return merged;
  }
  computeSnapshot() {
    const cloneSettingsFile = (file) => ({
      ...file,
      settings: structuredClone(file.settings),
      originalSettings: structuredClone(file.originalSettings)
    });
    return {
      system: cloneSettingsFile(this.system),
      systemDefaults: cloneSettingsFile(this.systemDefaults),
      user: cloneSettingsFile(this.user),
      workspace: cloneSettingsFile(this.workspace),
      isTrusted: this.isTrusted,
      errors: [...this.errors],
      merged: structuredClone(this._merged)
    };
  }
  // Passing this along with getSnapshot to useSyncExternalStore allows for idiomatic reactivity on settings changes
  // React will pass a listener fn into this subscribe fn
  // that listener fn will perform an object identity check on the snapshot and trigger a React re render if the snapshot has changed
  subscribe(listener) {
    coreEvents.on("settings-changed" /* SettingsChanged */, listener);
    return () => coreEvents.off("settings-changed" /* SettingsChanged */, listener);
  }
  getSnapshot() {
    return this._snapshot;
  }
  forScope(scope) {
    switch (scope) {
      case "User" /* User */:
        return this.user;
      case "Workspace" /* Workspace */:
        return this.workspace;
      case "System" /* System */:
        return this.system;
      case "SystemDefaults" /* SystemDefaults */:
        return this.systemDefaults;
      default:
        throw new Error(`Invalid scope: ${scope}`);
    }
  }
  isPersistable(settingsFile) {
    return !settingsFile.readOnly;
  }
  setValue(scope, key, value) {
    const settingsFile = this.forScope(scope);
    const valueToSet = typeof value === "object" && value !== null ? structuredClone(value) : value;
    setNestedProperty(settingsFile.settings, key, valueToSet);
    if (this.isPersistable(settingsFile)) {
      setNestedProperty(
        settingsFile.originalSettings,
        key,
        structuredClone(valueToSet)
      );
      saveSettings(settingsFile);
    }
    this._merged = this.computeMergedSettings();
    this._snapshot = this.computeSnapshot();
    coreEvents.emitSettingsChanged();
  }
  setRemoteAdminSettings(remoteSettings) {
    const admin = {};
    const { strictModeDisabled, mcpSetting, cliFeatureSetting } = remoteSettings;
    if (Object.keys(remoteSettings).length === 0) {
      this._remoteAdminSettings = { admin };
      this._merged = this.computeMergedSettings();
      return;
    }
    admin.secureModeEnabled = !strictModeDisabled;
    admin.mcp = {
      enabled: mcpSetting?.mcpEnabled,
      config: mcpSetting?.mcpConfig?.mcpServers,
      requiredConfig: mcpSetting?.requiredMcpConfig
    };
    admin.extensions = {
      enabled: cliFeatureSetting?.extensionsSetting?.extensionsEnabled
    };
    admin.skills = {
      enabled: cliFeatureSetting?.unmanagedCapabilitiesEnabled
    };
    this._remoteAdminSettings = { admin };
    this._merged = this.computeMergedSettings();
  }
};
function findEnvFile(startDir, isTrusted, ignoreLocalEnv) {
  let currentDir = path3.resolve(startDir);
  while (true) {
    if (isTrusted) {
      const geminiEnvPath = path3.join(currentDir, GEMINI_DIR, ".env");
      if (fs4.existsSync(geminiEnvPath)) {
        return geminiEnvPath;
      }
    }
    const envPath = path3.join(currentDir, ".env");
    if (fs4.existsSync(envPath)) {
      if (!ignoreLocalEnv || currentDir === homedir()) {
        return envPath;
      }
    }
    const parentDir = path3.dirname(currentDir);
    if (parentDir === currentDir || !parentDir) {
      if (isTrusted) {
        const homeGeminiEnvPath = path3.join(homedir(), GEMINI_DIR, ".env");
        if (fs4.existsSync(homeGeminiEnvPath)) {
          return homeGeminiEnvPath;
        }
      }
      const homeEnvPath = path3.join(homedir(), ".env");
      if (fs4.existsSync(homeEnvPath)) {
        return homeEnvPath;
      }
      return null;
    }
    currentDir = parentDir;
  }
}
var USER_GCP_PROJECT = "_GEMINI_USER_GCP_PROJECT";
function setUpCloudShellEnvironment(envFilePath, isTrusted, isSandboxed, selectedAuthType) {
  if (!process2.env[USER_GCP_PROJECT]) {
    const current = process2.env["GOOGLE_CLOUD_PROJECT"];
    if (current && current !== "cloudshell-gca") {
      process2.env[USER_GCP_PROJECT] = current;
    }
  }
  let value = "cloudshell-gca";
  if (selectedAuthType === "vertex-ai" /* USE_VERTEX_AI */) {
    value = process2.env[USER_GCP_PROJECT];
  }
  if (envFilePath && fs4.existsSync(envFilePath)) {
    const envFileContent = fs4.readFileSync(envFilePath);
    const parsedEnv = dotenv.parse(envFileContent);
    if (parsedEnv["GOOGLE_CLOUD_PROJECT"]) {
      value = parsedEnv["GOOGLE_CLOUD_PROJECT"];
      if (!isTrusted && isSandboxed) {
        value = sanitizeEnvVar(value);
      }
    }
  }
  if (value !== void 0) {
    process2.env["GOOGLE_CLOUD_PROJECT"] = value;
  } else if (process2.env["GOOGLE_CLOUD_PROJECT"] === "cloudshell-gca") {
    delete process2.env["GOOGLE_CLOUD_PROJECT"];
  }
}
function loadEnvironment(settings, workspaceDir, isWorkspaceTrustedFn = isWorkspaceTrusted) {
  const trustResult = isWorkspaceTrustedFn(settings, workspaceDir);
  const isTrusted = trustResult.isTrusted ?? false;
  const args = process2.argv.slice(2);
  const doubleDashIndex = args.indexOf("--");
  const relevantArgs = doubleDashIndex === -1 ? args : args.slice(0, doubleDashIndex);
  const isSandboxed = !!settings.tools?.sandbox || relevantArgs.includes("-s") || relevantArgs.includes("--sandbox");
  const shouldIgnoreEnv = !!settings.advanced?.ignoreLocalEnv || relevantArgs.includes("--ignore-env");
  const envFilePath = findEnvFile(workspaceDir, isTrusted, shouldIgnoreEnv);
  if (process2.env["CLOUD_SHELL"] === "true") {
    const selectedAuthType = settings.security?.auth?.selectedType;
    setUpCloudShellEnvironment(
      envFilePath,
      isTrusted,
      isSandboxed,
      selectedAuthType
    );
  }
  if (envFilePath) {
    try {
      const envFileContent = fs4.readFileSync(envFilePath, "utf-8");
      const parsedEnv = dotenv.parse(envFileContent);
      const excludedVars = settings?.advanced?.excludedEnvVars || DEFAULT_EXCLUDED_ENV_VARS;
      const isProjectEnvFile = !envFilePath.includes(GEMINI_DIR);
      for (const key in parsedEnv) {
        if (Object.hasOwn(parsedEnv, key)) {
          let value = parsedEnv[key];
          if (!isTrusted) {
            if (!AUTH_ENV_VAR_WHITELIST.includes(key)) {
              continue;
            }
            value = sanitizeEnvVar(value);
          }
          if (isProjectEnvFile && excludedVars.includes(key)) {
            continue;
          }
          if (!Object.hasOwn(process2.env, key)) {
            process2.env[key] = value;
          }
        }
      }
    } catch {
    }
  }
}
var settingsCache = createCache({
  storage: "map",
  defaultTtl: 1e4
  // 10 seconds
});
function isWorktreeEnabled(settings) {
  return settings.merged.experimental.worktrees;
}
function loadSettings(workspaceDir = process2.cwd()) {
  const normalizedWorkspaceDir = path3.resolve(workspaceDir);
  return settingsCache.getOrCreate(
    normalizedWorkspaceDir,
    () => _doLoadSettings(normalizedWorkspaceDir)
  );
}
function _doLoadSettings(workspaceDir) {
  let systemSettings = {};
  let systemDefaultSettings = {};
  let userSettings = {};
  let workspaceSettings = {};
  const settingsErrors = [];
  const systemSettingsPath = getSystemSettingsPath();
  const systemDefaultsPath = getSystemDefaultsPath();
  const storage = new Storage(workspaceDir);
  const workspaceSettingsPath = storage.getWorkspaceSettingsPath();
  const load = (filePath) => {
    try {
      if (fs4.existsSync(filePath)) {
        const content = fs4.readFileSync(filePath, "utf-8");
        const rawSettings = JSON.parse((0, import_strip_json_comments.default)(content));
        if (typeof rawSettings !== "object" || rawSettings === null || Array.isArray(rawSettings)) {
          settingsErrors.push({
            message: "Settings file is not a valid JSON object.",
            path: filePath,
            severity: "error"
          });
          return { settings: {}, rawSettings: {} };
        }
        const settingsObject = rawSettings;
        const expandedSettings = resolveEnvVarsInObject(
          settingsObject
        );
        const validationResult = validateSettings(expandedSettings);
        if (!validationResult.success && validationResult.error) {
          const errorMessage = formatValidationError(
            validationResult.error,
            filePath
          );
          settingsErrors.push({
            message: errorMessage,
            path: filePath,
            severity: "warning"
          });
          return {
            settings: expandedSettings,
            rawSettings: settingsObject,
            rawJson: content
          };
        }
        return {
          // Since we've successfully validated expandedSettings against settingsZodSchema,
          // it's safe to cast the resulting data to the Settings type.
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          settings: validationResult.data ?? expandedSettings,
          rawSettings: settingsObject,
          rawJson: content
        };
      }
    } catch (error) {
      settingsErrors.push({
        message: getErrorMessage(error),
        path: filePath,
        severity: "error"
      });
    }
    return { settings: {}, rawSettings: {} };
  };
  const systemResult = load(systemSettingsPath);
  const systemDefaultsResult = load(systemDefaultsPath);
  const userResult = load(USER_SETTINGS_PATH);
  let workspaceResult = {
    settings: {},
    rawSettings: {},
    rawJson: void 0
  };
  if (!storage.isWorkspaceHomeDir()) {
    workspaceResult = load(workspaceSettingsPath);
  }
  const systemOriginalSettings = structuredClone(systemResult.rawSettings);
  const systemDefaultsOriginalSettings = structuredClone(
    systemDefaultsResult.rawSettings
  );
  const userOriginalSettings = structuredClone(userResult.rawSettings);
  const workspaceOriginalSettings = structuredClone(
    workspaceResult.rawSettings
  );
  systemSettings = systemResult.settings;
  systemDefaultSettings = systemDefaultsResult.settings;
  userSettings = userResult.settings;
  workspaceSettings = workspaceResult.settings;
  if (userSettings.ui?.theme === "VS") {
    userSettings.ui.theme = DefaultLight.name;
  } else if (userSettings.ui?.theme === "VS2015") {
    userSettings.ui.theme = DefaultDark.name;
  }
  if (workspaceSettings.ui?.theme === "VS") {
    workspaceSettings.ui.theme = DefaultLight.name;
  } else if (workspaceSettings.ui?.theme === "VS2015") {
    workspaceSettings.ui.theme = DefaultDark.name;
  }
  const initialTrustCheckSettings = customDeepMerge(
    getMergeStrategyForPath,
    getDefaultsFromSchema(),
    systemDefaultSettings,
    userSettings,
    systemSettings
  );
  const isTrusted = isWorkspaceTrusted(initialTrustCheckSettings, workspaceDir).isTrusted ?? false;
  const tempMergedSettings = mergeSettings(
    systemSettings,
    systemDefaultSettings,
    userSettings,
    workspaceSettings,
    isTrusted
  );
  loadEnvironment(tempMergedSettings, workspaceDir);
  const fatalErrors = settingsErrors.filter((e) => e.severity === "error");
  if (fatalErrors.length > 0) {
    const errorMessages = fatalErrors.map(
      (error) => `Error in ${error.path}: ${error.message}`
    );
    throw new FatalConfigError(
      `${errorMessages.join("\n")}
Please fix the configuration file(s) and try again.`
    );
  }
  const loadedSettings = new LoadedSettings(
    {
      path: systemSettingsPath,
      settings: systemSettings,
      originalSettings: systemOriginalSettings,
      rawJson: systemResult.rawJson,
      readOnly: true
    },
    {
      path: systemDefaultsPath,
      settings: systemDefaultSettings,
      originalSettings: systemDefaultsOriginalSettings,
      rawJson: systemDefaultsResult.rawJson,
      readOnly: true
    },
    {
      path: USER_SETTINGS_PATH,
      settings: userSettings,
      originalSettings: userOriginalSettings,
      rawJson: userResult.rawJson,
      readOnly: false
    },
    {
      path: storage.isWorkspaceHomeDir() ? "" : workspaceSettingsPath,
      settings: workspaceSettings,
      originalSettings: workspaceOriginalSettings,
      rawJson: workspaceResult.rawJson,
      readOnly: storage.isWorkspaceHomeDir()
    },
    isTrusted,
    settingsErrors
  );
  migrateDeprecatedSettings(loadedSettings);
  return loadedSettings;
}
function migrateDeprecatedSettings(loadedSettings, removeDeprecated = true) {
  let anyModified = false;
  const systemWarnings = /* @__PURE__ */ new Map();
  const migrateBoolean = (settings, oldKey, newKey, prefix, foundDeprecated) => {
    let modified = false;
    const oldValue = settings[oldKey];
    const newValue = settings[newKey];
    if (typeof oldValue === "boolean") {
      if (foundDeprecated) {
        foundDeprecated.push(prefix ? `${prefix}.${oldKey}` : oldKey);
      }
      if (typeof newValue === "boolean") {
        if (removeDeprecated) {
          delete settings[oldKey];
          modified = true;
        }
      } else {
        settings[newKey] = !oldValue;
        if (removeDeprecated) {
          delete settings[oldKey];
        }
        modified = true;
      }
    }
    return modified;
  };
  const processScope = (scope) => {
    const settingsFile = loadedSettings.forScope(scope);
    const settings = settingsFile.settings;
    const foundDeprecated = [];
    const generalSettings = settings.general;
    if (generalSettings) {
      const newGeneral = { ...generalSettings };
      let modified = false;
      modified = migrateBoolean(
        newGeneral,
        "disableAutoUpdate",
        "enableAutoUpdate",
        "general",
        foundDeprecated
      ) || modified;
      modified = migrateBoolean(
        newGeneral,
        "disableUpdateNag",
        "enableAutoUpdateNotification",
        "general",
        foundDeprecated
      ) || modified;
      if (modified) {
        loadedSettings.setValue(scope, "general", newGeneral);
        if (!settingsFile.readOnly) {
          anyModified = true;
        }
      }
    }
    const uiSettings = settings.ui;
    if (uiSettings) {
      const newUi = { ...uiSettings };
      const accessibilitySettings = newUi["accessibility"];
      if (accessibilitySettings) {
        const newAccessibility = { ...accessibilitySettings };
        if (migrateBoolean(
          newAccessibility,
          "disableLoadingPhrases",
          "enableLoadingPhrases",
          "ui.accessibility",
          foundDeprecated
        )) {
          newUi["accessibility"] = newAccessibility;
          loadedSettings.setValue(scope, "ui", newUi);
          if (!settingsFile.readOnly) {
            anyModified = true;
          }
        }
        const enableLP = newAccessibility["enableLoadingPhrases"];
        if (typeof enableLP === "boolean" && newUi["loadingPhrases"] === void 0) {
          if (!enableLP) {
            newUi["loadingPhrases"] = "off";
            loadedSettings.setValue(scope, "ui", newUi);
            if (!settingsFile.readOnly) {
              anyModified = true;
            }
          }
          foundDeprecated.push("ui.accessibility.enableLoadingPhrases");
        }
      }
    }
    const contextSettings = settings.context;
    if (contextSettings) {
      const newContext = { ...contextSettings };
      const fileFilteringSettings = newContext["fileFiltering"];
      if (fileFilteringSettings) {
        const newFileFiltering = { ...fileFilteringSettings };
        if (migrateBoolean(
          newFileFiltering,
          "disableFuzzySearch",
          "enableFuzzySearch",
          "context.fileFiltering",
          foundDeprecated
        )) {
          newContext["fileFiltering"] = newFileFiltering;
          loadedSettings.setValue(scope, "context", newContext);
          if (!settingsFile.readOnly) {
            anyModified = true;
          }
        }
      }
    }
    const toolsSettings = settings.tools;
    if (toolsSettings) {
      if (toolsSettings["approvalMode"] !== void 0) {
        foundDeprecated.push("tools.approvalMode");
        const generalSettings2 = settings.general || {};
        const newGeneral = { ...generalSettings2 };
        if (newGeneral["defaultApprovalMode"] === void 0) {
          newGeneral["defaultApprovalMode"] = toolsSettings["approvalMode"];
          loadedSettings.setValue(scope, "general", newGeneral);
          if (!settingsFile.readOnly) {
            anyModified = true;
          }
        }
        if (removeDeprecated) {
          const newTools = { ...toolsSettings };
          delete newTools["approvalMode"];
          loadedSettings.setValue(scope, "tools", newTools);
          if (!settingsFile.readOnly) {
            anyModified = true;
          }
        }
      }
    }
    const experimentalModified = migrateExperimentalSettings(
      settings,
      loadedSettings,
      scope,
      removeDeprecated,
      foundDeprecated
    );
    if (experimentalModified) {
      if (!settingsFile.readOnly) {
        anyModified = true;
      }
    }
    if (settingsFile.readOnly && foundDeprecated.length > 0) {
      systemWarnings.set(scope, foundDeprecated);
    }
  };
  processScope("User" /* User */);
  processScope("Workspace" /* Workspace */);
  processScope("System" /* System */);
  processScope("SystemDefaults" /* SystemDefaults */);
  if (systemWarnings.size > 0) {
    for (const [scope, flags] of systemWarnings) {
      const scopeName = scope === "SystemDefaults" /* SystemDefaults */ ? "system default" : scope.toLowerCase();
      coreEvents.emitFeedback(
        "warning",
        `The ${scopeName} configuration contains deprecated settings: [${flags.join(", ")}]. These could not be migrated automatically as system settings are read-only. Please update the system configuration manually.`
      );
    }
  }
  return anyModified;
}
function saveSettings(settingsFile) {
  settingsCache.clear();
  try {
    const dirPath = path3.dirname(settingsFile.path);
    if (!fs4.existsSync(dirPath)) {
      fs4.mkdirSync(dirPath, { recursive: true });
    }
    const settingsToSave = settingsFile.originalSettings;
    updateSettingsFilePreservingFormat(
      settingsFile.path,
      settingsToSave
    );
  } catch (error) {
    const detailedErrorMessage = getFsErrorMessage(error);
    coreEvents.emitFeedback(
      "error",
      `Failed to save settings: ${detailedErrorMessage}`,
      error
    );
  }
}
function saveModelChange(loadedSettings, model) {
  try {
    loadedSettings.setValue("User" /* User */, "model.name", model);
  } catch (error) {
    const detailedErrorMessage = getFsErrorMessage(error);
    coreEvents.emitFeedback(
      "error",
      `Failed to save preferred model: ${detailedErrorMessage}`,
      error
    );
  }
}
function migrateExperimentalSettings(settings, loadedSettings, scope, removeDeprecated, foundDeprecated) {
  const experimentalSettings = settings.experimental;
  if (experimentalSettings) {
    const agentsSettings = {
      ...settings.agents
    };
    const agentsOverrides = {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
      ...agentsSettings["overrides"] || {}
    };
    let modified = false;
    const migrateExperimental = (oldKey, migrateFn) => {
      const old = experimentalSettings[oldKey];
      if (old !== void 0) {
        foundDeprecated?.push(`experimental.${oldKey}`);
        migrateFn(old);
        modified = true;
      }
    };
    migrateExperimental("codebaseInvestigatorSettings", (old) => {
      const override = {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        ...agentsOverrides["codebase_investigator"]
      };
      if (old["enabled"] !== void 0) override["enabled"] = old["enabled"];
      const runConfig = {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        ...override["runConfig"]
      };
      if (old["maxNumTurns"] !== void 0)
        runConfig["maxTurns"] = old["maxNumTurns"];
      if (old["maxTimeMinutes"] !== void 0)
        runConfig["maxTimeMinutes"] = old["maxTimeMinutes"];
      if (Object.keys(runConfig).length > 0) override["runConfig"] = runConfig;
      if (old["model"] !== void 0 || old["thinkingBudget"] !== void 0) {
        const modelConfig = {
          // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
          ...override["modelConfig"]
        };
        if (old["model"] !== void 0) modelConfig["model"] = old["model"];
        if (old["thinkingBudget"] !== void 0) {
          const generateContentConfig = {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
            ...modelConfig["generateContentConfig"]
          };
          const thinkingConfig = {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
            ...generateContentConfig["thinkingConfig"]
          };
          thinkingConfig["thinkingBudget"] = old["thinkingBudget"];
          generateContentConfig["thinkingConfig"] = thinkingConfig;
          modelConfig["generateContentConfig"] = generateContentConfig;
        }
        override["modelConfig"] = modelConfig;
      }
      agentsOverrides["codebase_investigator"] = override;
    });
    migrateExperimental("cliHelpAgentSettings", (old) => {
      const override = {
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        ...agentsOverrides["cli_help"]
      };
      if (old["enabled"] !== void 0) override["enabled"] = old["enabled"];
      agentsOverrides["cli_help"] = override;
    });
    migrateExperimental("plan", (planValue) => {
      const generalSettings = settings.general || {};
      const newGeneral = { ...generalSettings };
      const planSettings = (
        // eslint-disable-next-line @typescript-eslint/no-unsafe-type-assertion
        newGeneral["plan"] || {}
      );
      const newPlan = { ...planSettings };
      if (newPlan["enabled"] === void 0) {
        newPlan["enabled"] = planValue;
        newGeneral["plan"] = newPlan;
        loadedSettings.setValue(scope, "general", newGeneral);
        modified = true;
      }
    });
    if (modified) {
      agentsSettings["overrides"] = agentsOverrides;
      loadedSettings.setValue(scope, "agents", agentsSettings);
      if (removeDeprecated) {
        const newExperimental = { ...experimentalSettings };
        delete newExperimental["codebaseInvestigatorSettings"];
        delete newExperimental["cliHelpAgentSettings"];
        delete newExperimental["plan"];
        loadedSettings.setValue(scope, "experimental", newExperimental);
      }
      return true;
    }
  }
  return false;
}

// packages/cli/src/commands/gemma/constants.ts
import path4 from "node:path";
var LITERT_RELEASE_VERSION = "v0.9.0-alpha03";
var LITERT_RELEASE_BASE_URL = "https://github.com/google-ai-edge/LiteRT-LM/releases/download";
var GEMMA_MODEL_NAME = "gemma3-1b-gpu-custom";
var DEFAULT_PORT = 9379;
var HEALTH_CHECK_TIMEOUT_MS = 5e3;
var LITERT_API_VERSION = "v1beta";
var SERVER_START_WAIT_MS = 3e3;
var PLATFORM_BINARY_MAP = {
  "darwin-arm64": "lit.macos_arm64",
  "linux-x64": "lit.linux_x86_64",
  "win32-x64": "lit.windows_x86_64.exe"
};
var PLATFORM_BINARY_SHA256 = {
  "lit.macos_arm64": "9e826a2634f2e8b220ad0f1e1b5c139e0b47cb172326e3b7d46d31382f49478e",
  "lit.linux_x86_64": "66601df8a07f08244b188e9fcab0bf4a16562fe76d8d47e49f40273d57541ee8",
  "lit.windows_x86_64.exe": "de82d2829d2fb1cbdb318e2d8a78dc2f9659ff14cb11b2894d1f30e0bfde2bf6"
};
function getLiteRtBinDir() {
  return path4.join(Storage.getGlobalGeminiDir(), "bin", "litert");
}
function getPidFilePath() {
  return path4.join(Storage.getGlobalTempDir(), "litert-server.pid");
}
function getLogFilePath() {
  return path4.join(Storage.getGlobalTempDir(), "litert-server.log");
}

// packages/cli/src/commands/gemma/platform.ts
import fs5 from "node:fs";
import path5 from "node:path";
import { execFileSync } from "node:child_process";
function getUserConfiguredBinaryPath(workspaceDir = process.cwd()) {
  try {
    const userGemmaSettings = loadSettings(workspaceDir).forScope(
      "User" /* User */
    ).settings.experimental?.gemmaModelRouter;
    return userGemmaSettings?.binaryPath?.trim() || void 0;
  } catch {
    return void 0;
  }
}
function parsePortFromHost(host, fallbackPort) {
  if (!host) {
    return fallbackPort;
  }
  try {
    const url = new URL(host);
    const port = Number(url.port);
    return Number.isFinite(port) && port > 0 ? port : fallbackPort;
  } catch {
    const match = host.match(/:(\d+)/);
    if (!match) {
      return fallbackPort;
    }
    const port = parseInt(match[1], 10);
    return Number.isFinite(port) && port > 0 ? port : fallbackPort;
  }
}
function resolveGemmaConfig(fallbackPort) {
  let settingsEnabled = false;
  let configuredPort = fallbackPort;
  const configuredBinaryPath = getUserConfiguredBinaryPath();
  try {
    const settings = loadSettings(process.cwd());
    const gemmaSettings = settings.merged.experimental?.gemmaModelRouter;
    settingsEnabled = gemmaSettings?.enabled === true;
    configuredPort = parsePortFromHost(
      gemmaSettings?.classifier?.host,
      fallbackPort
    );
  } catch {
  }
  return { settingsEnabled, configuredPort, configuredBinaryPath };
}
function detectPlatform() {
  const key = `${process.platform}-${process.arch}`;
  const binaryName = PLATFORM_BINARY_MAP[key];
  if (!binaryName) {
    return null;
  }
  return { key, binaryName };
}
function getBinaryPath(binaryName) {
  const configuredBinaryPath = getUserConfiguredBinaryPath();
  if (configuredBinaryPath) {
    return configuredBinaryPath;
  }
  const name = binaryName ?? detectPlatform()?.binaryName;
  if (!name) return null;
  return path5.join(getLiteRtBinDir(), name);
}
function getBinaryDownloadUrl(binaryName) {
  return `${LITERT_RELEASE_BASE_URL}/${LITERT_RELEASE_VERSION}/${binaryName}`;
}
function isBinaryInstalled(binaryPath = getBinaryPath()) {
  if (!binaryPath) return false;
  return fs5.existsSync(binaryPath);
}
function isModelDownloaded(binaryPath) {
  try {
    const output = execFileSync(binaryPath, ["list"], {
      encoding: "utf-8",
      timeout: 1e4
    });
    return output.includes(GEMMA_MODEL_NAME);
  } catch {
    return false;
  }
}
async function isServerRunning(port) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(),
      HEALTH_CHECK_TIMEOUT_MS
    );
    const response = await fetch(
      `http://localhost:${port}/${LITERT_API_VERSION}/models/${GEMMA_MODEL_NAME}:generateContent`,
      { method: "POST", signal: controller.signal }
    );
    clearTimeout(timeout);
    return response.status !== 404;
  } catch {
    return false;
  }
}
function isLiteRtServerProcessInfo(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const isPositiveInteger = (candidate) => typeof candidate === "number" && Number.isInteger(candidate) && candidate > 0;
  const isNonEmptyString = (candidate) => typeof candidate === "string" && candidate.length > 0;
  const pid = Object.getOwnPropertyDescriptor(value, "pid")?.value;
  if (!isPositiveInteger(pid)) {
    return false;
  }
  const binaryPath = Object.getOwnPropertyDescriptor(
    value,
    "binaryPath"
  )?.value;
  if (binaryPath !== void 0 && !isNonEmptyString(binaryPath)) {
    return false;
  }
  const port = Object.getOwnPropertyDescriptor(value, "port")?.value;
  if (port !== void 0 && !isPositiveInteger(port)) {
    return false;
  }
  return true;
}
function readServerProcessInfo() {
  const pidPath = getPidFilePath();
  try {
    const content = fs5.readFileSync(pidPath, "utf-8").trim();
    if (!content) {
      return null;
    }
    if (/^\d+$/.test(content)) {
      return { pid: parseInt(content, 10) };
    }
    const parsed = JSON.parse(content);
    return isLiteRtServerProcessInfo(parsed) ? parsed : null;
  } catch {
    return null;
  }
}
function writeServerProcessInfo(processInfo) {
  fs5.writeFileSync(getPidFilePath(), JSON.stringify(processInfo), "utf-8");
}
function readServerPid() {
  return readServerProcessInfo()?.pid ?? null;
}
function normalizeProcessValue(value) {
  const normalized = value.replace(/\0/g, " ").trim();
  if (process.platform === "win32") {
    return normalized.replace(/\\/g, "/").replace(/\s+/g, " ").toLowerCase();
  }
  return normalized.replace(/\s+/g, " ");
}
function readProcessCommandLine(pid) {
  try {
    if (process.platform === "linux") {
      const output2 = fs5.readFileSync(`/proc/${pid}/cmdline`, "utf-8");
      return output2.trim() ? output2 : null;
    }
    if (process.platform === "win32") {
      const output2 = execFileSync(
        "powershell.exe",
        [
          "-NoProfile",
          "-Command",
          `(Get-CimInstance Win32_Process -Filter "ProcessId = ${pid}").CommandLine`
        ],
        {
          encoding: "utf-8",
          timeout: 5e3
        }
      );
      return output2.trim() || null;
    }
    const output = execFileSync("ps", ["-p", String(pid), "-o", "command="], {
      encoding: "utf-8",
      timeout: 5e3
    });
    return output.trim() || null;
  } catch {
    return null;
  }
}
function isExpectedLiteRtServerCommand(commandLine, options) {
  const normalizedCommandLine = normalizeProcessValue(commandLine);
  if (!normalizedCommandLine) {
    return false;
  }
  if (!/(^|\s|")serve(\s|$)/.test(normalizedCommandLine)) {
    return false;
  }
  if (options.port !== void 0 && !normalizedCommandLine.includes(`--port=${options.port}`)) {
    return false;
  }
  if (!options.binaryPath) {
    return true;
  }
  const normalizedBinaryPath = normalizeProcessValue(options.binaryPath);
  const normalizedBinaryName = normalizeProcessValue(
    path5.basename(options.binaryPath)
  );
  return normalizedCommandLine.includes(normalizedBinaryPath) || normalizedCommandLine.includes(normalizedBinaryName);
}
function isExpectedLiteRtServerProcess(pid, options) {
  const commandLine = readProcessCommandLine(pid);
  if (!commandLine) {
    return false;
  }
  return isExpectedLiteRtServerCommand(commandLine, options);
}
function isProcessRunning(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export {
  require_main,
  SHELL_COMMAND_NAME,
  SHELL_NAME,
  MAX_GEMINI_MESSAGE_LINES,
  SHELL_FOCUS_HINT_DELAY_MS,
  TOOL_STATUS,
  MAX_MCP_RESOURCES_TO_SHOW,
  WARNING_PROMPT_DURATION_MS,
  QUEUE_ERROR_DISPLAY_DURATION_MS,
  SHELL_ACTION_REQUIRED_TITLE_DELAY_MS,
  SHELL_SILENT_WORKING_TITLE_DELAY_MS,
  EXPAND_HINT_DURATION_MS,
  DEFAULT_BACKGROUND_OPACITY,
  DEFAULT_INPUT_BACKGROUND_OPACITY,
  DEFAULT_SELECTION_OPACITY,
  DEFAULT_BORDER_OPACITY,
  KEYBOARD_SHORTCUTS_URL,
  LRU_BUFFER_PERF_CACHE_LIMIT,
  ACTIVE_SHELL_MAX_LINES,
  COMPLETED_SHELL_MAX_LINES,
  SUBAGENT_MAX_LINES,
  MIN_TERMINAL_WIDTH_FOR_FULL_LABEL,
  DEFAULT_COMPRESSION_THRESHOLD,
  SKILLS_DOCS_URL,
  COMPACT_TOOL_SUBVIEW_MAX_LINES,
  MAX_SHELL_OUTPUT_SIZE,
  SHELL_OUTPUT_TRUNCATION_BUFFER,
  require_tinygradient,
  INK_SUPPORTED_NAMES,
  INK_NAME_TO_HEX_MAP,
  getLuminance2 as getLuminance,
  resolveColor,
  interpolateColor,
  getThemeTypeFromBackgroundColor,
  lightTheme,
  darkTheme,
  Theme,
  createCustomTheme,
  validateCustomTheme,
  pickDefaultThemeName,
  DefaultLight,
  DefaultDark,
  isFolderTrustEnabled,
  loadTrustedFolders2 as loadTrustedFolders,
  isWorkspaceTrusted,
  isFullWidth,
  isWide,
  eastAsianWidth,
  stringWidth,
  getAsciiArtWidth,
  toCodePoints,
  cpLen,
  cpIndexToOffset,
  cpSlice,
  stripUnsafeCharacters,
  sanitizeForDisplay,
  normalizeEscapedNewlines,
  getCachedStringWidth,
  escapeAnsiCtrlCodes,
  RESUME_LATEST,
  SessionError,
  cleanMessage,
  formatRelativeTime,
  getSessionFiles,
  SessionSelector,
  convertSessionToHistoryFormats,
  cleanupExpiredSessions,
  cleanupToolOutputFiles,
  TOGGLE_TYPES,
  getSettingsSchema,
  resolveEnvVarsInObject,
  require_src2 as require_src,
  USER_SETTINGS_PATH,
  SettingScope,
  isLoadableSettingScope,
  isWorktreeEnabled,
  loadSettings,
  saveModelChange,
  GEMMA_MODEL_NAME,
  DEFAULT_PORT,
  SERVER_START_WAIT_MS,
  PLATFORM_BINARY_SHA256,
  getLiteRtBinDir,
  getPidFilePath,
  getLogFilePath,
  resolveGemmaConfig,
  detectPlatform,
  getBinaryPath,
  getBinaryDownloadUrl,
  isBinaryInstalled,
  isModelDownloaded,
  isServerRunning,
  readServerProcessInfo,
  writeServerProcessInfo,
  readServerPid,
  isExpectedLiteRtServerProcess,
  isProcessRunning
};
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
